/* 
 * File: Prob1Random.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:00 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std; 

#include "Prob1Random.h"  

Prob1Random::Prob1Random(const char n, const char*c) { 
    set=new char[n]; 
    for (int i=0; i<n; i++) { 
        set[i]=c[i]; 
    } 
    freq=new int[n]; 
    nset=n; 
    numRand=0; 
} 
Prob1Random::~Prob1Random(void) { 
    delete [] set; 
} 
char Prob1Random::randFromSet(void) { 
    int indx=rand()%nset; 
    freq[indx]++; 
    numRand++; 
    return set[indx]; 
} 
int *Prob1Random::getFreq() const { 
    return freq; 
} 
char *Prob1Random::getSet() const { 
    return set; 
} 
int Prob1Random::getNumRand() const { 
    return numRand; 
} 