/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:00 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std; 

#include "Prob1Random.h"  

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) { 
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Declare and initialize variables 
    char n=5;
    char rndseq[]={19,34,57,79,126};
    int ntimes=100000; 
    Prob1Random a(n,rndseq); //Class object with parameters 
    //Random selections from number set 
    for(int i=1;i<=ntimes;i++){
    a.randFromSet();
    } 
    //Pointers to frequency and which set used 
    int *x=a.getFreq();
    char *y=a.getSet(); 
    //Print output for frequency and num set 
    for(int i=0;i<n;i++){
    cout<<int(y[i])<<" occurred "<<x[i]<<" times"<<endl;
    }
    //Print output for total amt. of random nums used 
    cout<<"The total number of random numbers is "<<a.getNumRand()<<endl;
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 
