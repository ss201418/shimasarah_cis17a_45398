/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Prob1Random.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:00 PM 
 * Purpose: Final Exam 
 */ 

#ifndef PROB1RANDOM_H
#define PROB1RANDOM_H

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

//Class Declarations 
class Prob1Random { 
    private: 
        char *set;      //numbers to draw from 
        char nset;     //number variables in sequence 
        int *freq;       //freq. of random nums returned 
        int numRand; //total amt. random function called 
    public: 
        Prob1Random(const char,const char *);//Constructor
        ~Prob1Random(void); //Destructor
        char randFromSet(void); //Returns a random number from the set
        int *getFreq(void) const; //Returns the frequency histogram
        char *getSet(void) const; //Returns the set used
        int getNumRand(void) const; //Gets the number of times randFromSet
                                                     //has been called 
}; 
#endif /* PROB1RANDOM_H */

