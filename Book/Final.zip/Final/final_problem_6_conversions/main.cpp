/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 3:50 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Solution for Converting 5.75 Base 10 
    cout<<"5.75"<<endl; 
    cout<<"Binary = 101.11 Base 2"<<endl; 
    cout<<"Octal = 5.6 Base 8"<<endl; 
    cout<<"Hex = 5.C Base 16"<<endl; 
    cout<<"NASA Hex Float = 5C000003 Base 16"<<endl; 
    cout<<"Scaled int binary 1 unsigned byte = 5C x 16^-1"<<endl; 
    cout<<"Multiply by 1-byte 7 then back to integer = "<<endl; 
    //Solution for Converting 0.9 Base 10 
    cout<<"0.9"<<endl; 
    cout<<"Binary = 0.111001101 Base 2"<<endl; 
    cout<<"Octal = .72 Base 8"<<endl; 
    cout<<"Hex = .E7 Base 16"<<endl; 
    cout<<"NASA Hex Float =  Base 16"<<endl; 
    cout<<"Scaled int binary 2 unsigned byte = "<<endl; 
    cout<<"Multiply by 1-byte 7 then back to integer = "<<endl; 
    //Solution for Converting 99.7 Base 10 
    cout<<"99.7"<<endl; 
    cout<<"Binary =  Base 2"<<endl; 
    cout<<"Octal =  Base 8"<<endl; 
    cout<<"Hex =  Base 16"<<endl; 
    cout<<"NASA Hex Float =  Base 16"<<endl; 
    cout<<"Scaled int binary 3 unsigned byte = "<<endl; 
    cout<<"Multiply by 1-byte 7 then back to integer = "<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 
