/* 
 * File: Prob3Table.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:50 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std; 

#include "Prob3Table.h"  

Prob3Table::Prob3Table(char *file, int row, int col) { 
    rows=row; 
    cols=col; 
    rowSum=new T(row); 
    colSum=new T(col); 
    table=new T(row*col); 
} 
