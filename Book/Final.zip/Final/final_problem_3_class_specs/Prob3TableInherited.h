/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Prob3TableInherited.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:50 PM 
 * Purpose: Final Exam 
 */ 

#ifndef PROB3TABLEINHERITED_H
#define PROB3TABLEINHERITED_H

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std; 

#include "Prob3Table.h"  

//Class Template 
template<class T>
class Prob3TableInherited:public Prob3Table<T>{
    protected:
        T *augTable; //Augmented Table with sums
    public:
        Prob3TableInherited(char *,int,int); //Constructor
        ~Prob3TableInherited(){delete [] augTable;}; //Destructor
        const T *getAugTable(void){return augTable;};
};


#endif /* PROB3TABLEINHERITED_H */

