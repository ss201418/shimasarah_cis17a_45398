/* 
 * File: Prob3TableInherited.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:50 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std; 

#include <iostream> 
#include <string> 
#include "Prob3TableInherited.h"  

template<class T>
Prob3TableInherited<T>::Prob3TableInherited(char*f, int r, int c) {
    string file=f; 
    fstream txt; 
    txt.open(file,ios::in); 
    for (int i=0; i<rows; i++) {
        for (int j=0; j<cols; j++) { 
            
        } 
    } 
} 

