/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:50 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

#include "Prob3TableInherited.h"  

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Output for start of program 
    cout<<"Entering problem number 3"<<endl; 
    //Declare and initialize variables 
    int rows=5;
    int cols=6;
    Prob3TableInherited<int> tab("Problem3.txt",rows,cols);
    const int *naugT=tab.getTable();
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            cout<<naugT[i*cols+j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
    const int *augT=tab.getAugTable();
    for(int i=0;i<=rows;i++){
        for(int j=0;j<=cols;j++){
            cout<<augT[i*(cols+1)+j]<<" ";
        }
        cout<<endl;
    }
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 
