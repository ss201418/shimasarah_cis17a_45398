/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings 
#include <cstring>   //Char Arrays 
#include <cctype>    //Char Library 
#include <cmath>    //Math functions
using namespace std;

#include "Prob1Random.h" 
#include "Prob2Sort.h" 
#include "Prob3TableInherited.h" 
#include "SavingsAccount.h" 
#include "Employee.h" 

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes 
void prob1(); //Problem 1 
void prob2(); //Problem 2 
void prob3(); //Problem 3 
void prob4(); //Problem 4 
void prob5(); //Problem 5 
void prob6(); //Problem 6 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Declare and initialize variables 
    int option=0; 
    bool exit=false; 
    //Menu Functions Do-While Loop 
    do { 
        //Output for Main Menu options 
        cout<<"Main Menu"<<endl; 
        cout<<"1. Problem 1"<<endl; 
        cout<<"2. Problem 2"<<endl; 
        cout<<"3. Problem 3"<<endl; 
        cout<<"4. Problem 4"<<endl; 
        cout<<"5. Problem 5"<<endl; 
        cout<<"6. Problem 6"<<endl; 
        cout<<"7. Exit menu"<<endl; 
        //Get input for main menu option 
        cin>>option; 
        if (option==1) prob1(); 
        else if (option==2) prob2(); 
        else if (option==3) prob3(); 
        else if (option==4) prob4(); 
        else if (option==5) prob5(); 
        else if (option==6) prob6(); 
        else if (option==7) exit=true; 
        else cout<<"Invalid Input"<<endl; 
    //End of do-while Loop 
    } while (!exit); 
    //Output for exiting menu 
    cout<<"Now exiting the menu."<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 

//*****START OF FUNCTION DEFINITIONS***** 

//Function for Problem 1 
void prob1() { 
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Declare and initialize variables 
    char n=5;
    char rndseq[]={19,34,57,79,126};
    int ntimes=100000; 
    Prob1Random a(n,rndseq); //Class object with parameters 
    //Random selections from number set 
    for(int i=1;i<=ntimes;i++){
    a.randFromSet();
    } 
    //Pointers to frequency and which set used 
    int *x=a.getFreq();
    char *y=a.getSet(); 
    //Print output for frequency and num set 
    for(int i=0;i<n;i++){
    cout<<int(y[i])<<" occurred "<<x[i]<<" times"<<endl;
    }
    //Print output for total amt. of random nums used 
    cout<<"The total number of random numbers is "<<a.getNumRand()<<endl; 
} 
//Function for Problem 2 
void prob2() { 
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Output for start of program 
    cout<<"The start of Problem 2, the sorting problem"<<endl;
    //Declare and initialize variables 
    Prob2Sort<char> rc;
    bool ascending=true;
    ifstream infile;
    //Open file 
    infile.open("Problem2.txt",ios::in); 
    //Dynamically allocate memory 
    char *ch2=new char[10*16];
    char *ch2p=ch2; 
    //Output for new memory 
    while(infile.get(*ch2)){cout<<*ch2;ch2++;} 
    //Close file 
    infile.close(); 
    cout<<endl; 
    //Get input for a specific column 
    cout<<"Sorting on which column"<<endl;
    int column;
    cin>>column; 
    //Sort the column of characters 
    char *zc=rc.sortArray(ch2p,10,16,column,ascending);
    //Output for 2D array of characters 
    for(int i=0;i<10;i++){
        for(int j=0;j<16;j++){
            cout<<zc[i*16+j];
        }
    } 
    //Delete allocated memory 
    delete []zc;
    cout<<endl;
} 
//Function for Problem 3 
void prob3() { 
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Output for start of program 
    cout<<"Entering problem number 3"<<endl; 
    //Declare and initialize variables 
    int rows=5;
    int cols=6;
    Prob3TableInherited<int> tab("Problem3.txt",rows,cols);
    const int *naugT=tab.getTable();
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            cout<<naugT[i*cols+j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
    const int *augT=tab.getAugTable();
    for(int i=0;i<=rows;i++){
        for(int j=0;j<=cols;j++){
            cout<<augT[i*(cols+1)+j]<<" ";
        }
        cout<<endl;
    }
} 
//Function for Problem 4 
void prob4() { 
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Declare and initialize variables 
    SavingsAccount mine(-300);
    for(int i=1;i<=10;i++){
    mine.Transaction((float)(rand()%500)*(rand()%3-1));
    }
    mine.toString();
    cout<<"Balance after 7 years given 10% interest = "
        <<mine.Total((float)(0.10),7)<<endl;
    cout<<"Balance after 7 years given 10% interest = "
        <<mine.TotalRecursive((float)(0.10),7)
        <<" Recursive Calculation "<<endl;
} 
//Function for Problem 5 
void prob5() { 
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0))); 
    //Employee 1 and first set of values 
    Employee Mark("Mark","Boss",215.50); 
    Mark.setHoursWorked(-3); 
    //Output all values 
    Mark.toString(); 
    //Input for second set of values 
    Mark.CalculatePay(Mark.setHourlyRate(20.0),Mark.setHoursWorked(25)); 
    //Output all values 
    Mark.toString();
    //Input for three set of values 
    Mark.CalculatePay(Mark.setHourlyRate(40.0),Mark.setHoursWorked(25));
    //Output all values 
    Mark.toString();
    //Input for fourth set of values 
    Mark.CalculatePay(Mark.setHourlyRate(60.0),Mark.setHoursWorked(25));
    //Output all values 
    Mark.toString(); 
    //Employee 2 and first set of values 
    Employee Mary("Mary","VP",50.0);
    //Output all values 
    Mary.toString();
    //Input for second set of values 
    Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(40));
    //Output all values 
    Mary.toString();
    //Input for third set of values 
    Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(50));
    //Output all values 
    Mary.toString();
    //Input for fourth set of values 
    Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(60));
    //Output all values 
    Mary.toString(); 
    } 
} 
//Function for Problem 6 
void prob6() { 
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Solution for Converting 5.75 Base 10 
    cout<<"5.75"<<endl; 
    cout<<"Binary = 101.11 Base 2"<<endl; 
    cout<<"Octal = 5.6 Base 8"<<endl; 
    cout<<"Hex = 5.C Base 16"<<endl; 
    cout<<"NASA Hex Float = 5C000003 Base 16"<<endl; 
    cout<<"Scaled int binary 1 unsigned byte = 5C x 16^-1"<<endl; 
    cout<<"Multiply by 1-byte 7 then back to integer = "<<endl; 
    //Solution for Converting 0.9 Base 10 
    cout<<"0.9"<<endl; 
    cout<<"Binary = 0.111001101 Base 2"<<endl; 
    cout<<"Octal = .72 Base 8"<<endl; 
    cout<<"Hex = .E7 Base 16"<<endl; 
    cout<<"NASA Hex Float =  Base 16"<<endl; 
    cout<<"Scaled int binary 2 unsigned byte = "<<endl; 
    cout<<"Multiply by 1-byte 7 then back to integer = "<<endl; 
    //Solution for Converting 99.7 Base 10 
    cout<<"99.7"<<endl; 
    cout<<"Binary =  Base 2"<<endl; 
    cout<<"Octal =  Base 8"<<endl; 
    cout<<"Hex =  Base 16"<<endl; 
    cout<<"NASA Hex Float =  Base 16"<<endl; 
    cout<<"Scaled int binary 3 unsigned byte = "<<endl; 
    cout<<"Multiply by 1-byte 7 then back to integer = "<<endl; 
} 