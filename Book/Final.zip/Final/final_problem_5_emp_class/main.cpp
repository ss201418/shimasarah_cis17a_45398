/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 3:20 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output 
#include <string>     //Strings 
#include <cctype>    //Char Library 
#include <cmath>     //Math functions
using namespace std;

#include "Employee.h"  

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0))); 
    
    //Employee 1 and first set of values 
    Employee Mark("Mark","Boss",215.50); 
    Mark.setHoursWorked(-3); 
    //Output all values 
    Mark.toString(); 
    //Input for second set of values 
    Mark.CalculatePay(Mark.setHourlyRate(20.0),Mark.setHoursWorked(25)); 
    //Output all values 
    Mark.toString();
    //Input for three set of values 
    Mark.CalculatePay(Mark.setHourlyRate(40.0),Mark.setHoursWorked(25));
    //Output all values 
    Mark.toString();
    //Input for fourth set of values 
    Mark.CalculatePay(Mark.setHourlyRate(60.0),Mark.setHoursWorked(25));
    //Output all values 
    Mark.toString(); 
    
    //Employee 2 and first set of values 
    Employee Mary("Mary","VP",50.0);
    //Output all values 
    Mary.toString();
    //Input for second set of values 
    Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(40));
    //Output all values 
    Mary.toString();
    //Input for third set of values 
    Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(50));
    //Output all values 
    Mary.toString();
    //Input for fourth set of values 
    Mary.CalculatePay(Mary.setHourlyRate(50.0),Mary.setHoursWorked(60));
    //Output all values 
    Mary.toString();
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 
