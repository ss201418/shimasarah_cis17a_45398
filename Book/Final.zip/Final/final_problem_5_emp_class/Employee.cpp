/* 
 * File: Employee.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 3:20 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output 
#include <string>     //Strings 
#include <cctype>    //Char Library 
#include <cmath>    //Math functions
using namespace std;

#include "Employee.h"  

Employee::Employee(char name[],char title[],float pay) { 
    int size=0, i=0; 
    while(name[i]) { 
        size++; 
        i++; 
    } 
    for (int i=0; i<size; i++) { 
        MyName[i]=name[i]; 
    } 
    size=0, i=0; 
    while (title[i]) { 
        size++; 
        i++; 
    } 
    for (int i=0; i<size; i++) { 
        JobTitle[i]=title[i]; 
    } 
    HourlyRate=pay; 
    HoursWorked=0; 
    GrossPay=0.0; 
    NetPay=0.0; 
} 
float Employee::CalculatePay(float rate,int hrs) { 
    if (hrs<0 || hrs>200) { GrossPay=0; NetPay=0; } 
    else { 
        GrossPay=Employee::getGrossPay(rate,hrs); 
        double tax1=0,tax2=0,tax3=0,taxDed=0; 
        //For first tax level only 
        if (GrossPay<=500) { 
            tax1=Employee::Tax(GrossPay); 
            taxDed+=GrossPay*tax1; 
        } 
        //For first and second tax levels 
        else if (GrossPay>500 && GrossPay<=1000) { 
            tax1=Employee::Tax(500); 
            taxDed+=500*tax1; 
            tax2=Employee::Tax(GrossPay); 
            taxDed+=((GrossPay-500)*tax2); 
        } 
        //For first, second, and third tax levels 
        else if (GrossPay>1000) { 
            tax1=Employee::Tax(500); 
            taxDed+=500*tax1; 
            tax2=Employee::Tax(1000); 
            taxDed+=500*tax2; 
            tax3=Employee::Tax(GrossPay); 
            taxDed+=((GrossPay-1000)*tax3); 
        } 
        //Calculate net pay based on tax levels 
        NetPay=GrossPay-taxDed; 
    } 
    return NetPay; 
} 
double Employee::Tax(float GrossPay) { 
    double tax=0; 
    (GrossPay<=500) ? tax=.1: 
        (GrossPay>500 && GrossPay<=1000) ? tax=.2: 
            (GrossPay>1000) ? tax=.3: tax; 
    return tax; 
} 
float Employee::getGrossPay(float rate,int hrs) { 
    if (hrs<=40) { 
        GrossPay=rate*hrs; 
    } 
    else if (hrs>40 && hrs<=50) { 
        GrossPay=rate*40; 
        GrossPay+=((rate*1.5)*(hrs-40)); 
    } 
    else if (hrs>50) { 
        GrossPay=rate*40; 
        GrossPay+=((rate*1.5)*10); 
        GrossPay+=((rate*2)*(hrs-50)); 
    }
    return GrossPay; 
} 
float Employee::getNetPay(float netPay) { 
    NetPay=netPay; 
    return NetPay; 
} 
void Employee::toString() { 
    bool invalid=false; 
    int temp=0; 
    if (HourlyRate<0 || HourlyRate>84) { 
        invalid=true; 
        cout<<"Unacceptable Hourly Rate"<<endl; 
    } 
    if (HoursWorked<0 || HoursWorked>200) { 
        invalid=true; 
        cout<<"Unacceptable Hours Worked"<<endl; 
    } 
    if (invalid) { 
        cout<<"Name = "<<MyName<<" "; 
        cout<<"Job Title = "<<JobTitle<<endl; 
        cout<<"  Hourly Rate = "<<temp<<" "; 
        cout<<"Hours Worked = "<<temp<<" "; 
        cout<<"Gross Pay = "<<temp<<" "; 
        cout<<"Net Pay = "<<temp<<endl; 
    } 
    else if (!invalid) { 
    cout<<"Name = "<<MyName<<" "; 
    cout<<"Job Title = "<<JobTitle<<endl; 
    cout<<"  Hourly Rate = "<<HourlyRate<<" "; 
    cout<<"Hours Worked = "<<HoursWorked<<" "; 
    cout<<"Gross Pay = "<<GrossPay<<" "; 
    cout<<"Net Pay = "<<NetPay<<endl; 
    } 
} 
int Employee::setHoursWorked(int n) { 
    HoursWorked=n; 
    return HoursWorked; 
} 
float Employee::setHourlyRate(float hrRate) { 
    HourlyRate=hrRate; 
    return HourlyRate; 
} 
