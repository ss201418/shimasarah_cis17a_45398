/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Employee.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 3:20 PM 
 * Purpose: Final Exam 
 */ 

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand 
#include <cstdlib>    //Srand to set the seed 
#include <fstream>  //File I/O 
#include <iomanip>  //Format the output 
#include <string>     //Strings 
#include <cctype>    //Char Library 
#include <cmath>     //Math functions
using namespace std;

//Class Declarations 
class Employee { 
    public:
        Employee(char[],char[],float); //Constructor
        float CalculatePay(float,int); //Procedure
        float getGrossPay(float,int); //Procedure
        float getNetPay(float); //Procedure
        void toString(); //Procedure
        int setHoursWorked(int); //Procedure
        float setHourlyRate(float); //Procedure
    private:
        double Tax(float); //Utility Procedure
        char MyName[20]; //Property
        char JobTitle[20]; //Property
        float HourlyRate; //Property
        int HoursWorked; //Property
        float GrossPay; //Property
        float NetPay; //Property
}; 
#endif /* EMPLOYEE_H */

