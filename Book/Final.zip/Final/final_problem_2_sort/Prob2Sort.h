/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Prob2Sort.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:40 PM 
 * Purpose: Final Exam 
 */ 

#ifndef PROB2SORT_H
#define PROB2SORT_H

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std; 

//Class Template 
template<class T>
class Prob2Sort{
    private:
        int *index; //Index that is utilized
                        //in the sort
    public:
        Prob2Sort(){index=NULL;}; //Constructor
        ~Prob2Sort(){delete []index;}; //Destructor
        T * sortArray(const T*,int,bool); //Sorts a single column array
        T * sortArray(const T*,int,int,int,bool);//Sorts a 2 dimensional array
                                                                 //represented as a 1 dim array
}; 
#endif /* PROB2SORT_H */

