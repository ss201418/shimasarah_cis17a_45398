/* 
 * File: Prob2Sort.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:40 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std; 

#include "Prob2Sort.h" 

T *Prob2Sort::sortArray(const T*ch2p,int c,bool a) { 
    char temp=''; 
    int i=0; 
    while (ch2p) {
        if (i%c==0) index[i/c]=ch2p[i]; 
        i++; 
    } 
    //Reset counter 
    i=0; 
    while (index) { 
        //Sorting ascending 
        if (a) {
            if (i>0 && index[i]>index[i-1]) { 
                temp=index[i]; 
                index[i]=index[i-1]; 
                index[i-1]=temp; 
            } 
        } 
        //Sorting descending 
        else if (!a) { 
            if (i>0 && index[i]<index[i-1]) { 
                temp=index[i]; 
                index[i]=index[i-1]; 
                index[i-1]=temp; 
            } 
        } 
    } 
} 
T *Prob2Sort::sortArray(const T*ch2p,int n1,int n2,int c,bool a) { 
    char temp=''; 
    for(int i=0; i<n1; i++){ 
        for(int j=0; j<n2; j++){ 
            int k=i*j+j, idx=0; 
            //Sorting ascending 
            if (a) { 
                if (j==c && ch2p[k]>ch2p[k-n2]) { 
                    for (int swap=0; swap<n2; swap++) { 
                        idx=i*swap+swap; 
                        temp=ch2p[k]; 
                        ch2p[k]=ch2p[k-n2]; 
                        ch2p[k-n2]=temp; 
                    } 
                } 
            } 
            //Sorting descending 
            else if (!a) { 
                if (j==c && ch2p[k]<ch2p[k-n2]) { 
                    idx=i*swap+swap; 
                    temp=ch2p[k]; 
                    ch2p[k]=ch2p[k-n2]; 
                    ch2p[k-n2]=temp; 
                } 
            } 
        } 
    } 
} 
