/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 2:40 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Output for start of program 
    cout<<"The start of Problem 2, the sorting problem"<<endl;
    //Declare and initialize variables 
    Prob2Sort<char> rc;
    bool ascending=true;
    ifstream infile;
    //Open file 
    infile.open("Problem2.txt",ios::in); 
    //Dynamically allocate memory 
    char *ch2=new char[10*16];
    char *ch2p=ch2; 
    //Output for new memory 
    while(infile.get(*ch2)){cout<<*ch2;ch2++;} 
    //Close file 
    infile.close(); 
    cout<<endl; 
    //Get input for a specific column 
    cout<<"Sorting on which column"<<endl;
    int column;
    cin>>column; 
    //Sort the column of characters 
    char *zc=rc.sortArray(ch2p,10,16,column,ascending);
    //Output for 2D array of characters 
    for(int i=0;i<10;i++){
        for(int j=0;j<16;j++){
            cout<<zc[i*16+j];
        }
    } 
    //Delete allocated memory 
    delete []zc;
    cout<<endl;
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 
