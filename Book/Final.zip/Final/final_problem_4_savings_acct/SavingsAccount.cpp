/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 3:00 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

#include "SavingsAccount.h"  

SavingsAccount::SavingsAccount(float bal) { 
    if (bal>0) Balance=0; 
    FreqWithDraw=0; 
    FreqDeposit=0; 
} 
void SavingsAccount::Transaction(float amt) { 
    if (amt>0) SavingsAccount::Deposit(amt); 
    else if (amt<0) SavingsAccount::Withdraw(amt); 
} 
float SavingsAccount::Total(float savint,int time) { 
    int savings=0; 
    for (int i=0; i<time; i++) { 
        savings+=Balance*savint; 
    } 
    return savings; 
} 
float SavingsAccount::TotalRecursive(float savint,int time) { 
    int savings=0; 
    for (int i=0; i<time; i++) { 
        savings+=Balance*savint; 
    } 
    return savings; 
} 
void SavingsAccount::toString() { 
    cout<<"Balance="<<Balance<<endl; 
    cout<<"WithDraws="<<FreqWithDraw<<endl; 
    cout<<"Deposit="<<FreqDeposit<<endl; 
} 
float SavingsAccount::Withdraw(float amt) { 
    if (Balance<=0 || Balance<amt) { 
        cout<<"WithDraw not Allowed"<<endl; 
    } 
    else { 
        Balance-=amt; 
    } 
    FreqWithDraw++; 
    return FreqWithDraw; 
} 
float SavingsAccount::Deposit(float amt) { 
    Balance+=amt; 
    FreqDeposit++; 
    return FreqDeposit; 
} 
