/* 
 * File: main.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 3:00 PM 
 * Purpose: Final Exam 
 */ 

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

#include "SavingsAccount.h"  

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Declare and initialize variables 
    SavingsAccount mine(-300);
    for(int i=1;i<=10;i++){
    mine.Transaction((float)(rand()%500)*(rand()%3-1));
    }
    mine.toString();
    cout<<"Balance after 7 years given 10% interest = "
        <<mine.Total((float)(0.10),7)<<endl;
    cout<<"Balance after 7 years given 10% interest = "
        <<mine.TotalRecursive((float)(0.10),7)
        <<" Recursive Calculation "<<endl;
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 
