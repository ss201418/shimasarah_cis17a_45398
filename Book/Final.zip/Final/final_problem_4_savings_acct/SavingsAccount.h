/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: SavingsAccount.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 3:00 PM 
 * Purpose: Final Exam 
 */ 

#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

//Class Declarations 
class SavingsAccount { 
    public:
        SavingsAccount(float); //Constructor
        void Transaction(float); //Procedure
        float Total(float=0,int=0); //Savings Procedure
        float TotalRecursive(float=0,int=0);
        void toString(); //Output Properties
    private:
        float Withdraw(float); //Utility Procedure
        float Deposit(float); //Utility Procedure
        float Balance; //Property
        int FreqWithDraw; //Property
        int FreqDeposit; //Property
}; 
#endif /* SAVINGSACCOUNT_H */

