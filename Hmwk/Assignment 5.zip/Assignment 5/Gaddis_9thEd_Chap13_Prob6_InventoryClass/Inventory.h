/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Inventory.h 
 * Author: Sarah Shima 
 * Created on June 22, 2021, 11:00 PM
 * Purpose: Retail Item Class Header File for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library
#include <cctype>    //Char Library
using namespace std;

#ifndef INVENTORY_H
#define INVENTORY_H

//Class Declarations 
class Invntry { 
    private: 
        int itemNum,Qty;
        float cost,Ttl; 
    public: 
        Invntry() //default constructor 
            { itemNum=0; 
            Qty=0; 
            cost=0; } 
        Invntry(int i,int q,float c) //constructor #2 
            { itemNum=i; 
            Qty=q; 
            cost=c; 
            setTtl(); } 
        void setItmN(int i) 
            { itemNum=i; } 
        void setQty(int q) 
            { Qty=q; } 
        void setCost(float c) 
            { cost=c; }  
        void setTtl() 
            { Ttl=Qty*cost; } 
        int getItmN() const 
            { return itemNum; }  
        int getQty() const 
            { return Qty; } 
        int getCost() const 
            { return cost; } 
        float getTtl() const 
            { return Ttl; } 
}; 

#endif /* INVENTORY_H */

