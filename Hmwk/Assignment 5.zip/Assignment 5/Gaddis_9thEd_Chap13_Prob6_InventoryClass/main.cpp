/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on June 22, 2021, 11:00 PM
 * Purpose: Retail Item Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream>      //I/O Library
#include <iomanip>       //Format Library
#include <string>          //String Library
#include <cctype>         //Char Library
#include "Inventory.h" //Class Library 
using namespace std; 

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants


//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare Inventory class objects 
    Invntry Items1(),Items2; 
    int i,q; 
    float c; 
    //Get input for item num, qty, and cost 
    do { 
        cout<<"Input an item number: "<<endl; 
        cin>>i; 
    } while (i<0); 
    do { 
        cout<<"Input a quantity: "<<endl; 
        cin>>q; 
    } while (i<0); 
    do { 
        cout<<"Input the cost per item: "<<endl; 
        cin>>c; 
    } while (i<0); 
    //Store values in constructor #2 variables 
    Items2.setItmN(i); 
    Items2.setQty(q); 
    Items2.setCost(c); 
    //Display output for items stats and total cost 
    cout<<"Item Details"<<endl; 
    cout<<"Number: "<<Items2.getItmN()<<endl; 
    cout<<"Quantity: "<<Items2.getQty()<<endl; 
    cout<<"Cost per Item: "<<setprecision(2)<<fixed; 
    cout<<Items2.getCost()<<endl; 
    cout<<"Total Cost: "<<setprecision(2)<<fixed; 
    cout<<Items2.getTtl()<<endl<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}