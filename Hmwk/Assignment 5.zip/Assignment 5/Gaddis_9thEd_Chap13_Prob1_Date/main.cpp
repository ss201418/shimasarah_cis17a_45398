/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 21, 2021, 3:00 PM
 * Purpose: Date Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std; 

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Class Declarations 
class Date { 
    private: 
        string mnthNm; 
        int month; 
        int day; 
        int year; 
    public: 
        void setMnth(int); 
        void setDay(int); 
        void setYear(int); 
        void prntDgt(int,int,int); 
        void prntUSA(string,int,int); 
        void prntEur(string,int,int); 
}; 

//Set Month Member Function 
void Date::setMnth(int m) { 
    month=m; 
} 
//Set Day Member Function 
void Date::setDay(int d) { 
    day=d; 
} 
//Set Year Member Function 
void Date::setYear(int y) { 
    year=y; 
} 
//Set Month Member Function 
void Date::prntDgt(int m, int d, int y) { 
    cout<<m<<"/"<<d<<"/"<<y<<endl; 
} 
//Set Month Member Function 
void Date::prntUSA(string mnthNm, int d, int y) { 
    cout<<mnthNm<<" "<<d<<", "<<y<<endl; 
} 
//Set Month Member Function 
void Date::prntEur(string mnthNm, int d, int y) { 
    cout<<d<<" "<<mnthNm<<" "<<y<<endl; 
} 

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare all variables for this function
    Date dsply; 
    int m=0,d=0,y=0; 
    string month; 
    //Get input for month 
    while (m<1 || m>12) { 
    cout<<"Input a month value between 1 and 12: "<<endl; 
    cin>>m; 
    dsply.setMnth(m); 
    } 
    //Get input for day 
    while (d<1 || d>31) { 
    cout<<"Input a day value between 1 and 31: "<<endl; 
    cin>>d; 
    dsply.setDay(d); 
    } 
    //Get input for year 
    while (y<1900 || y>2021) { 
    cout<<"Input a four-digit year between"; 
    cout<<" 1900 and 2021: "<<endl; 
    cin>>y; 
    dsply.setYear(y); 
    } 
    //Determine month written format 
    switch (m) { 
        case 1: month="January"; 
        break; 
        case 2: month="February"; 
        break; 
        case 3: month="March"; 
        break; 
        case 4: month="April"; 
        break; 
        case 5: month="May"; 
        break; 
        case 6: month="June"; 
        break; 
        case 7: month="July"; 
        break; 
        case 8: month="August"; 
        break; 
        case 9: month="September"; 
        break; 
        case 10: month="October"; 
        break; 
        case 11: month="November"; 
        break; 
        case 12: month="December"; 
        break; 
    } 
    //Display the date in digital format 
    dsply.prntDgt(m,d,y); 
    //Display the date in US format 
    dsply.prntUSA(month,d,y); 
    //Display the date in European format 
    dsply.prntEur(month,d,y); 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
} 