/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: DayofYr.h 
 * Author: Sarah Shima 
 * Created on July 23, 2021, 1:30 PM
 * Purpose: Day of the Year Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library
#include <cctype>    //Char Library
using namespace std;

#ifndef DAYOFYR_H
#define DAYOFYR_H
//Class Declarations 
class DayOfYr { 
    private: 
        int day=0; 
        int days[13]={1,32,60,91,121,152,182,213,244,274,305,335,365}; 
        string month[12]={"January","February","March","April",
                                   "May","June","July","August","September",
                                   "October","November","December"}; 
    public: 
        DayOfYr(int d) //constructor 
            { day=d; } 
        void print(); 
}; 
//Class Member Functions 
void DayOfYr::print() { 
    for (int i=0; i<13; i++) { 
        if (day>days[i] && day<days[i+1]) { 
            cout<<month[i]<<" "; 
            cout<<day-days[i]<<endl; 
        } 
    } 
} 

#endif /* DAYOFYR_H */

