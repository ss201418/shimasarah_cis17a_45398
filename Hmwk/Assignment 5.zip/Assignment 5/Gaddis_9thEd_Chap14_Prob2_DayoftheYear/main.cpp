/* 
 * File: main.cpp
 * Author: Sarah Shima 
 * Created on July 23, 2021, 1:30 PM
 * Purpose: Day of the Year Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library
#include <cctype>

#include "DayofYr.h"    //Char Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants


//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare all variables for this function 
    int d=0; 
    //Get input for day of the year 
    cout<<"Input a day of the year: "<<endl; 
    cin>>d; 
    DayOfYr Day(d); 
    //Display the Inputs/Outputs 
    Day.print(); 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}