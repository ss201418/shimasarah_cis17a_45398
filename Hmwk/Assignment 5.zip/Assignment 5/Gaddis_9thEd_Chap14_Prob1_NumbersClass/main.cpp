/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 23, 2021, 9:15 AM
 * Purpose: Numbers Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>

#include "Numbers.h"    //Char Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants


//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize all variables 
    int n; 
    //Get input for number value 
    do { 
    cout<<"Enter a positive integer value: "<<endl; 
    cin>>n; 
    } while(n<0); 
    //Display the Inputs/Outputs 
   Numbers Num(n); 
   Num.print(); 
    
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}