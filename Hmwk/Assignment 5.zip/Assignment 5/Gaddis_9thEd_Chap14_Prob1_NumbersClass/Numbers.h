/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Numbers.h 
 * Author: Sarah Shima 
 * Created on July 23, 2021, 9:15 AM
 * Purpose: Numbers Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std;

#ifndef NUMBERS_H
#define NUMBERS_H
//Class Declarations 
class Numbers { 
    private: 
        int number, nums[20]; 
        string under20[20]={"zero","one","two","three","four","five",
                                       "six","seven","eight","nine","ten","eleven",
                                       "twelve","thirteen","fourteen","fifteen",
                                       "sixteen","seventeen","eighteen","nineteen"}; 
        string twntyUp[10]={"","","twenty","thirty","forty","fifty","sixty",
                                   "seventy","eighty","ninety"}; 
        string hundred="hundred"; 
        string thousand="thousand"; 
    public: 
        Numbers(int n) //constructor 
            { number=n; } 
        void print(); 
}; 

//Class Member Functions 
void Numbers::print() { 
    //Declare and initialize variables 
    int ones,tens,hndrds,thsnds; 
    thsnds=number/1000; 
    number-=thsnds*1000; 
    hndrds=number/100; 
    number-=hndrds*100; 
    tens=number/10; 
    number-=tens*10; 
    ones=number; 
    //Print number value written out 
    for (int i=0; i<20; i++) { 
        //Print thousands place 
        if(thsnds>0 && thsnds==nums[i]) { 
            cout<<under20[i]<<" "; 
            cout<<thousand<<" "; 
        } 
    } 
    for (int i=0; i<20; i++) { 
        //Print hundreds place 
        if(hndrds==0 && hndrds==nums[i]) { 
            cout<<under20[i]<<" "; 
            cout<<hundred<<" "; 
        } 
    } 
    for (int i=0; i<20; i++) { 
        //Print out tens place for 20 up 
        if(tens>1 && tens==nums[i]) { 
            cout<<twntyUp[i]<<"-"; 
        } 
        //Print out tens and ones for teen value 
        else if(tens==1 && ones==nums[i]) { 
            cout<<under20[i+10]<<endl; 
        } 
    } 
    for (int i=0; i<20; i++) { 
        //Print out ones for 20 up and under 10 
        if (tens>0 && ones==nums[i]) { 
            cout<<under20[i]<<endl; 
        } 
    } 
} 

#endif /* NUMBERS_H */

