/* 
 * File: main.cpp
 * Author: Sarah Shima 
 * Created on July 23, 2021, 4:30 PM
 * Purpose: Month Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 

#include "Month.h"  //Char Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare and initialize all variables 
    string m=""; 
    int n=0; 
    Month mVals; 
    //Get input for name and num value of a month 
    cin>>mVals; 
    m=mVals.getMnth(); 
    n=mVals.getMNum(); 
    //Store and display values through constructor #2 
    Month mName(m); 
    cout<<"Displaying values through constructor #2: "; 
    cout<<mName.getMnth()<<", "<<mName.getMNum()<<endl; 
    //Store and display values through constructor #3 
    Month mNum(n); 
    cout<<"Displaying values through constructor #3: "; 
    cout<<mName.getMnth()<<", "<<mName.getMNum()<<endl; 
    //Declare and initialize third Month object 
    Month oprtr(m); 
    //Print prefix inc. operator values for first Month object 
    cout<<"Prefix increment operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        cout<<"First: "<<oprtr<<"   "; 
        oprtr=++mName; 
        cout<<"Second: "<<oprtr<<endl; 
    } 
    //Print postfix inc. operator values for first Month object 
    cout<<"Postfix increment operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        cout<<"First: "<<oprtr<<"   "; 
        oprtr=mName++; 
        cout<<"Second: "<<oprtr<<endl; 
    } 
    //Print prefix dec. operator values for first Month object 
    cout<<"Prefix decrement operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        cout<<"First: "<<oprtr<<"   "; 
        oprtr=--mName; 
        cout<<"Second: "<<oprtr<<endl; 
    } 
    //Print postfix dec. operator values for first Month object 
    cout<<"Postfix decrement operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        cout<<"First: "<<oprtr<<"   "; 
        oprtr=mName--; 
        cout<<"Second: "<<oprtr<<endl; 
    }     
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}