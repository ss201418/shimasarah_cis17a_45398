/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Month.h 
 * Author: Sarah Shima 
 * Created on July 23, 2021, 4:30 PM
 * Purpose: Month Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream>  //I/O Library 
#include <iomanip>  //Format Library 
#include <string>  //String Library 
#include <cctype>  //Char Library 
using namespace std;

#ifndef MONTH_H
#define MONTH_H
//Class Declarations 
class Month { 
    private: 
        string name="",
                  names[12]={"January","February","March", 
                                    "April","May","June","July",
                                    "August","September","October",
                                    "November","December"}; 
        int mnthNum=0,
             nums[12]={1,2,3,4,5,6,7,8,9,10,11,12}; 
    public: 
        Month() //default constructor 
        { name="January"; 
          mnthNum=1; } 
        Month(string m); //constructor #2 
        Month(int n); //constructor #3 
        void setMnth(string m) 
            { name=m; } 
        void setMNum(int n) 
            { mnthNum=n; } 
        string getMnth() const 
            { return name; } 
        int getMNum() const 
            { return mnthNum; } 
        Month operator++(); 
        Month operator++(int); 
        Month operator--(); 
        Month operator--(int); 
        friend ostream &operator << (ostream &, const Month &); 
        friend istream &operator >> (istream &, const Month &); 
}; 
//Class Member Functions 
Month::Month(string m) { 
    name=m; 
    for (int i=0; i<12; i++) { 
        if (name==names[i]) { 
            Month::setMNum(nums[i]); 
        } 
    } 
} 
Month::Month(int n) { 
    mnthNum=n; 
    for (int i=0; i<12; i++) { 
        if (mnthNum==nums[i]) { 
            Month::setMnth(names[i]); 
        }
    } 
} 
Month Month::operator ++() { 
    int n=mnthNum; 
    (n==12) ? 
        n=1, mnthNum=1: 
        n=++mnthNum; 
    for (int i=0; i<12; i++) { 
        if (n==nums[i]) { 
            Month::setMnth(names[i]); 
        }
    } 
    return *this; 
} 
Month Month::operator ++(int) { 
    Month temp(mnthNum); 
    int n=mnthNum; 
    (n==12) ? 
        n=1, mnthNum=1: 
        n=mnthNum++; 
    for (int i=0; i<12; i++) { 
        if (n==nums[i]) { 
            Month::setMnth(names[i]); 
        }
    } 
    return temp; 
} 
Month Month::operator --() { 
    int n=mnthNum; 
    (n==1) ? 
        n=12, mnthNum=12: 
        n=--mnthNum; 
    for (int i=0; i<12; i++) { 
        if (n==nums[i]) { 
            Month::setMnth(names[i]); 
        }
    } 
    return *this; 
} 
Month Month::operator --(int) { 
    Month temp(mnthNum); 
    int n=mnthNum; 
    (n==1) ? 
        n=12, mnthNum=12: 
        n=mnthNum--; 
    for (int i=0; i<12; i++) { 
        if (n==nums[i]) { 
            Month::setMnth(names[i]); 
        }
    } 
    return temp; 
} 
ostream &operator << (ostream &dsply, const Month &obj) { 
    dsply<<obj.mnthNum<<" = "<<obj.name; 
    return dsply; 
} 
istream &operator >> (istream &inpt, Month &obj) { 
    cout<<"Enter a month both written out and "; 
    cout<<"by number value (range of 1 to 12): "<<endl; 
    string m; 
    int n; 
    inpt>>m>>n; 
    obj.setMnth(m); 
    obj.setMNum(n); 
    return inpt; 
} 

#endif /* MONTH_H */

