/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 22, 2021, 11:30 PM
 * Purpose: Test Scores Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream>       //I/O Library 
#include <iomanip>        //Format Library 
#include <string>           //String Library 
#include <cctype>          //Char Library 
#include "TestScores.h" //Class Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants


//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare all variables for this function 
    Scores TestScr; 
    int sc1,sc2,sc3; 
    //Get input for Test Score 1 
    cout<<"Input Test Score 1: "<<endl; 
    cin>>sc1; 
    TestScr.setScr1(sc1); 
    //Get input for Test Score 2 
    cout<<"Input Test Score 2: "<<endl; 
    cin>>sc2; 
    TestScr.setScr2(sc2); 
    //Get input for Test Score 3 
    cout<<"Input Test Score 3: "<<endl; 
    cin>>sc3; 
    TestScr.setScr3(sc3); 
    //Display the Inputs/Outputs 
    cout<<"Test Scores"<<endl; 
    cout<<"Score 1: "<<TestScr.prntSc1()<<endl; 
    cout<<"Score 2: "<<TestScr.prntSc2()<<endl; 
    cout<<"Score 3: "<<TestScr.prntSc3()<<endl; 
    cout<<"Average Score: "<<TestScr.prntAvg(); 
    cout<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}