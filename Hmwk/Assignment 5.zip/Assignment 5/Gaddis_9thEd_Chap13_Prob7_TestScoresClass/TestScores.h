/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: TestScores.h 
 * Author: Sarah Shima 
 * Created on July 22, 2021, 11:30 PM
 * Purpose: Test Scores Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std;

#ifndef TESTSCORES_H
#define TESTSCORES_H

//Class Declarations 
class Scores { 
    private: 
        int Score1,Score2,Score3; 
    public: 
        Scores(); //constructor 
        void setScr1(int); 
        void setScr2(int); 
        void setScr3(int); 
        int prntSc1() const; 
        int prntSc2() const; 
        int prntSc3() const; 
        int prntAvg() const; 
}; 

//Class Member Functions 
Scores::Scores() { 
    Score1=0; 
    Score2=0; 
    Score3=0; 
} 
void Scores::setScr1(int sc1) { 
    Score1=sc1; 
} 
void Scores::setScr2(int sc2) { 
    Score2=sc2; 
} 
void Scores::setScr3(int sc3) { 
    Score3=sc3; 
} 
int Scores::prntSc1() const { 
    return Score1; 
} 
int Scores::prntSc2() const { 
    return Score2; 
} 
int Scores::prntSc3() const { 
    return Score3; 
} 
int Scores::prntAvg() const { 
    return (Score1+Score2+Score3)/3; 
} 

#endif /* TESTSCORES_H */

