/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 22, 2021, 10:30 PM
 * Purpose:  Patient Charges Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants 

//Class Declarations 
class Patient { 
    private: 
        string nmFirst,nmMid,nmLast; 
        string address,city,state; 
        string phone,eName,ePhone; 
        int zipCode;  
    public: 
        Patient(string,string,string, //constructor 
                    string,string,string,
                    string,string,string,int); 
}; 
class Procdr { 
    private: 
        string prName,drName; 
        string prDate; 
        float fees; 
    public: 
        Procdr(); //constructor 
        void setPrNm(string); 
        void setDrNm(string); 
        void setPrDt(string); 
        void setFees(float); 
        void prntPNm(string); 
        void prntDNm(string); 
        void prntPDt(string); 
        void prntFee(float); 
}; 

//Patient Class Member Functions 
Patient::Patient(string fNm,string mNm,string lNm, 
                         string addr,string cty,string stNm, 
                         string phn,string eNm,string ePhn, int zip) { 
    cout<<"Patient Name: "; 
    cout<<(nmFirst=fNm)<<" "; 
    cout<<(nmMid=mNm)<<" "; 
    cout<<(nmLast=lNm)<<endl; 
    cout<<"Address: "; 
    cout<<(address=addr)<<" "; 
    cout<<(city=cty)<<", "; 
    cout<<(state=stNm)<<" "; 
    cout<<(zipCode=zip)<<endl; 
    cout<<"Phone Number: "; 
    cout<<(phone=phn)<<endl; 
    cout<<"Emergency Contact Info: "; 
    cout<<(eName=eNm)<<", "; 
    cout<<(ePhone=ePhn)<<endl<<endl; 
} 

//Procedure Class Member Functions 
Procdr::Procdr() { 
    prName=""; 
    drName=""; 
    prDate=""; 
    fees=0; 
} 
void Procdr::setPrNm(string prNm) { 
    prName=prNm; 
} 
void Procdr::setDrNm(string drNm) { 
    drName=drNm; 
} 
void Procdr::setPrDt(string prDt) { 
    prDate=prDt; 
} 
void Procdr::setFees(float Fee) { 
    fees=Fee; 
} 
void Procdr::prntPNm(string prNm) { 
    cout<<"Procedure Name: "; 
    cout<<prName<<endl; 
} 
void Procdr::prntPDt(string drNm) { 
    cout<<"Date: "; 
    cout<<prDate<<endl; 
} 
void Procdr::prntDNm(string prDt) { 
    cout<<"Practitioner: "; 
    cout<<drName<<endl; 
} 
void Procdr::prntFee(float Fee) { 
    cout<<"Charge: "; 
    cout<<setprecision(2)<<fixed; 
    cout<<fees<<endl<<endl; 
} 

//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize all variables 
    Procdr prNum1,prNum2,prNum3; 
    string prNm,drNm,prDt; 
    float fee; 
    //Declare Class and Print with Constructor 
    Patient("John","Kent","Smith","1234 ABC St.",
                "Lois","CA","951-555-1234","Jane Smith",
                "951-555-5678",12345); 
    //Call mutators for Procedure #1 
    prNm="Physical Exam"; 
    prNum1.setPrNm(prNm); 
    drNm="07/22/21"; 
    prNum1.setDrNm(drNm); 
    prDt="Dr. Irvine"; 
    prNum1.setPrDt(prDt); 
    fee=250.00; 
    prNum1.setFees(fee); 
    //Call mutators for Procedure #2 
    prNm="X-ray"; 
    prNum2.setPrNm(prNm); 
    drNm="07/22/21"; 
    prNum2.setDrNm(drNm); 
    prDt="Dr. Jamison"; 
    prNum2.setPrDt(prDt); 
    fee=500.00; 
    prNum2.setFees(fee); 
    //Call mutators for Procedure #3 
    prNm="Blood test"; 
    prNum3.setDrNm(prNm); 
    drNm="07/22/21"; 
    prNum3.setDrNm(drNm); 
    prDt="Dr. Smith"; 
    prNum3.setPrDt(prDt); 
    fee=200.00; 
    prNum3.setFees(fee); 
    //Display output for Procedure #1 
    prNum1.prntPNm(prNm); 
    prNum1.prntDNm(drNm); 
    prNum1.prntPDt(prDt); 
    prNum1.prntFee(fee); 
    //Display output for Procedure #2 
    prNum2.prntPNm(prNm); 
    prNum2.prntDNm(drNm); 
    prNum2.prntPDt(prDt); 
    prNum2.prntFee(fee); 
    //Display output for Procedure #3 
    prNum3.prntPNm(prNm); 
    prNum3.prntDNm(drNm); 
    prNum3.prntPDt(prDt); 
    prNum3.prntFee(fee); 
    //Clean up the code, close files, deallocate memory, etc.... 
    //Exit stage right 
    return 0; 
} 