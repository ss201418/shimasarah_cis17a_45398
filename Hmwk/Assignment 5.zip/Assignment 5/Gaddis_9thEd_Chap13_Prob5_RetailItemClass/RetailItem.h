/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: RetailItem.h 
 * Author: Sarah Shima 
 * Created on June 22, 2021, 11:00 PM
 * Purpose: Retail Item Class Header File for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library
#include <cctype>    //Char Library
using namespace std;

#ifndef RETAILITEM_H
#define RETAILITEM_H

//Class Declarations 
class RtlItem { 
    private: 
        string dscrpt; 
        int units; 
        float price; 
    public: 
        RtlItem(); //constructor 
        void setDscr(string); 
        void setUnit(int); 
        void setPrce(float); 
        string prntDsr() const; 
        int prntUnt() const; 
        float prntPrc() const; 
}; 

//Retail Item Member Functions 
RtlItem::RtlItem() { 
    dscrpt=""; 
    units=0; 
    price=0; 
} 
void RtlItem::setDscr(string d) { 
    dscrpt=d; 
} 
void RtlItem::setUnit(int u) { 
    units=u; 
} 
void RtlItem::setPrce(float p) { 
    price=p; 
} 
string RtlItem::prntDsr() const { 
    return dscrpt; 
} 
int RtlItem::prntUnt() const { 
    return units; 
} 
float RtlItem::prntPrc() const { 
    return price; 
} 

#endif /* RETAILITEM_H */

