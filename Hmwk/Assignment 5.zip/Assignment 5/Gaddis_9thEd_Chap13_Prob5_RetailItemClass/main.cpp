/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on June 22, 2021, 11:00 PM
 * Purpose: Retail Item Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream>      //I/O Library
#include <iomanip>       //Format Library
#include <string>          //String Library
#include <cctype>         //Char Library
#include "RetailItem.h" //Class Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants


//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare Retail Item class objects 
    RtlItem Item1,Item2,Item3; 
    //Input data for Retail Item 1 
    Item1.setDscr("Jacket"); 
    Item1.setUnit(12); 
    Item1.setPrce(59.95); 
    //Input data for Retail Item 2 
    Item2.setDscr("Designer Jeans"); 
    Item2.setUnit(40); 
    Item2.setPrce(34.95); 
    //Input data for Retail Item 3 
    Item3.setDscr("Shirt"); 
    Item3.setUnit(20); 
    Item3.setPrce(24.95); 
    //Output data for Retail Item 1 
    cout<<"Item #1"<<endl; 
    cout<<"Description: "; 
    cout<<Item1.prntDsr()<<endl; 
    cout<<"Units on Hand: "; 
    cout<<Item1.prntUnt()<<endl; 
    cout<<"Price: "<<setprecision(2)<<fixed; 
    cout<<Item1.prntPrc()<<endl<<endl; 
    //Output data for Retail Item 2 
    cout<<"Item #2"<<endl; 
    cout<<"Description: "; 
    cout<<Item2.prntDsr()<<endl; 
    cout<<"Units on Hand: "; 
    cout<<Item2.prntUnt()<<endl; 
    cout<<"Price: "<<setprecision(2)<<fixed; 
    cout<<Item2.prntPrc()<<endl<<endl; 
    //Output data for Retail Item 3 
    cout<<"Item #3"<<endl; 
    cout<<"Description: "; 
    cout<<Item3.prntDsr()<<endl; 
    cout<<"Units on Hand: "; 
    cout<<Item3.prntUnt()<<endl; 
    cout<<"Price: "<<setprecision(2)<<fixed; 
    cout<<Item3.prntPrc()<<endl<<endl;  
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}