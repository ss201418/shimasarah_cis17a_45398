/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 23, 2021, 4:00 PM
 * Purpose: Num Days Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream>  //I/O Library 
#include <iomanip>  //Format Library 
#include <string>  //String Library 
#include <cctype>

#include "NumDays.h"  //Char Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants


//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare and initialize all variables 
    float h=0; 
    //Get input for first set of hours worked 
    cout<<"Input first set of hours worked: "<<endl; 
    cin>>h; 
    //Store hours in first NumDays object 
    NumDays days1(h); 
    //Get input for second set of hours worked 
    cout<<"Input second set of hours worked: "<<endl; 
    cin>>h; 
    //Store hours in second NumDays object 
    NumDays days2(h); 
    //Reset hours value for third NumDays object 
    h=0; 
    NumDays total(h); 
    //Display output for addition operator 
    total=days1+days2; 
    cout<<"Total hours worked: "; 
    cout<<total.getHrs()<<endl; 
    cout<<"Sum of all days worked: "; 
    cout<<total.getDays()<<endl; 
    //Reset hours value for fourth NumDays object 
    h=0; 
    NumDays diff(h); 
    //Display output for subtraction operator 
    diff=days1-days2; 
    cout<<"Difference between sets of days worked: "; 
    cout<<diff.getDays()<<endl; 
    //Reset hours value for fifth NumDays object 
    h=0; 
    NumDays oprtr(h); 
    //Display output for prefix increment operator 
    cout<<"Prefix increment operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        oprtr=++total; 
        cout<<"First: "<<oprtr.getHrs()<<" hours = "; 
        cout<<oprtr.getDays()<<" days"<<"   "; 
        cout<<"Second: "<<total.getHrs()<<" hours = "; 
        cout<<total.getDays()<<" days"<<endl; 
    } 
    //Display output for postfix increment operator 
    cout<<"Postfix increment operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        oprtr=total++; 
        cout<<"First: "<<oprtr.getHrs()<<" hours = "; 
        cout<<oprtr.getDays()<<" days"<<"   "; 
        cout<<"Second: "<<total.getHrs()<<" hours = "; 
        cout<<total.getDays()<<" days"<<endl; 
    } 
    //Display output for prefix decrement operator 
    cout<<"Prefix decrement operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        oprtr=--total; 
        cout<<"First: "<<oprtr.getHrs()<<" hours = "; 
        cout<<oprtr.getDays()<<" days"<<"   "; 
        cout<<"Second: "<<total.getHrs()<<" hours = "; 
        cout<<total.getDays()<<" days"<<endl; 
    } 
    //Display output for postfix decrement operator 
    cout<<"Postfix decrement operator: "<<endl; 
    for (int i=0; i<3; i++) { 
        oprtr=total--; 
        cout<<"First: "<<oprtr.getHrs()<<" hours = "; 
        cout<<oprtr.getDays()<<" days"<<"   "; 
        cout<<"Second: "<<total.getHrs()<<" hours = "; 
        cout<<total.getDays()<<" days"<<endl; 
    } 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}