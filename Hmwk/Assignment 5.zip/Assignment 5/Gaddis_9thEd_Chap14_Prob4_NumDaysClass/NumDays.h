/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: NumDays.h 
 * Author: Sarah Shima 
 * Created on July 23, 2021, 4:00 PM
 * Purpose: Num Days Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream>  //I/O Library 
#include <iomanip>  //Format Library 
#include <string>  //String Library 
#include <cctype>  //Char Library 
using namespace std;


#ifndef NUMDAYS_H
#define NUMDAYS_H
//Class Declarations 
class NumDays { 
    private: 
        float hours=0, days=0; 
    public: 
        NumDays(float); //constructor 
        void setHrs(float h) 
            { hours=h; } 
        void setDays(float d) 
            { days=d; } 
        int getHrs() const 
            { return hours; } 
        float getDays() const 
            { return days; } 
        NumDays operator+(const NumDays &); 
        NumDays operator-(const NumDays &); 
        NumDays operator++(); 
        NumDays operator++(int); 
        NumDays operator--(); 
        NumDays operator--(int); 
}; 
//Class Member Functions 
NumDays::NumDays(float h) { 
    NumDays::setHrs(h); 
    float d=h/8; //hours div. into days 
    NumDays::setDays(d); 
} 
NumDays NumDays::operator +(const NumDays &right) { 
    NumDays temp(0); 
    temp.hours=hours+right.hours; 
    temp.days=days+right.days; 
    return temp; 
} 
NumDays NumDays::operator -(const NumDays &right) { 
    NumDays temp(0); 
    temp.hours=hours+right.hours; 
    temp.days=days-right.days; 
    return temp; 
} 
NumDays NumDays::operator ++() { 
    ++hours; 
    days=hours/8; 
    return *this; 
} 
NumDays NumDays::operator ++(int) { 
    NumDays temp(hours); 
    hours++; 
    days=hours/8; 
    return temp; 
} 
NumDays NumDays::operator --() { 
    --hours; 
    days=hours/8;  
    return *this; 
} 
NumDays NumDays::operator --(int) { 
    NumDays temp(hours); 
    hours--; 
    days=hours/8; 
    return temp; 
} 

#endif /* NUMDAYS_H */
