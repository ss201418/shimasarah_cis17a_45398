/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: DayOfYearMod.h
 * Author: Sarah Shima 
 * Created on July 23, 2021, 1:50 PM
 * Purpose: Day of Year Mod Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library
#include <cctype>    //Char Library
using namespace std;

#ifndef DAYOFYRMOD_H
#define DAYOFYRMOD_H
//Class Declarations 
class DayofYr { 
    private: 
        int day=0; 
        int days[13]={1,32,60,91,121,152,182,213,244,274,305,335,365}; 
        string month[12]={"January","February","March","April",
                                   "May","June","July","August","September",
                                   "October","November","December"}; 
    public: 
        DayofYr(int d) //default constructor 
            { day=d; } 
        DayofYr(string m, int d); //constructor #2 
        void print(); //output day of year 
        DayofYr operator++(); //overloaded Prefix++ 
        DayofYr operator++(int); //overloaded Postfix++ 
        DayofYr operator--(); //overloaded Prefix-- 
        DayofYr operator--(int); //overloaded Postfix-- 
}; 
//Class Member Functions 
DayofYr::DayofYr(string m, int d) { 
    for (int i=0; i<13; i++) { 
        if (m==month[i]) { 
            if (d<1 || d>(days[i+1]-days[i])) { 
                cout<<"Day outside range of days for the"; 
                cout<<" chosen month."<<endl; 
            } 
            else if (d>1 && d<(days[i+1]-days[i])) { 
                day=days[i]+d-1; 
                DayofYr::print(); 
            } 
        } 
    } 
} 
void DayofYr::print() { 
    cout<<"Day of the Year: "<<day<<endl; 
} 
DayofYr DayofYr::operator++() { 
    ++day; 
    return *this; 
} 
DayofYr DayofYr::operator++(int) { 
    DayofYr temp=day; 
    day++; 
    return temp; 
} 
DayofYr DayofYr::operator--() { 
    --day; 
    return *this; 
} 
DayofYr DayofYr::operator--(int) { 
    DayofYr temp=day; 
    day--; 
    return temp; 
} 

#endif /* DAYOFYRMOD_H */

