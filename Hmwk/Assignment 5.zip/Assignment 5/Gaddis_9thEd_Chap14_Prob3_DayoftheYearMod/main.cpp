/* 
 * File: main.cpp
 * Author: Sarah Shima 
 * Created on July 23, 2021, 1:50 PM
 * Purpose: Day of Year Mod Class Problem for Assignment 5 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library
#include <cctype>    //Char Library 
#include "DayofYrMod.h" 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants


//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare all variables for this function 
    string m=""; 
    int d=0; 
    //Get input for month string value 
    cout<<"Input a month written out: "<<endl; 
    cin>>m; 
    //Get input for day of the month 
    cout<<"Input an integer for a day of the month: "<<endl; 
    cin>>d; 
    DayofYr Test(d);
    DayofYr Day(m,d); 
    //Output value with Prefix ++ operator 
    cout<<"Testing the Prefix ++ operator: "; 
    Test=++Day; 
    Test.print(); 
    //Output value with Postfix ++ operator 
    cout<<"Testing the Postfix ++ operator: "; 
    Test=Test++; 
    Test.print(); 
    //Output value with Prefix -- operator 
    cout<<"Testing the Prefix -- operator: "; 
    Test=--Test; 
    Test.print(); 
    //Output value with Postfix -- operator 
    cout<<"Testing the Postfix -- operator: "; 
    Test=Test--; 
    Test.print(); 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}