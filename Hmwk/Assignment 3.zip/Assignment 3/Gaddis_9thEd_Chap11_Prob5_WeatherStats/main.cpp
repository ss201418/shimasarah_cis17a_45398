/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 2:40 PM 
 * Purpose: Structure Weather Statistics 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <string>     //String Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions


//Enumerated Data Types 
enum MthName {JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE}; 

//Structure Declarations 
struct Month { 
    float ttlRain,       //total rainfall in inches 
          highTmp,       //high temp in degrees Fahrenheit 
          lowTmp,        //low temp in degrees Fahrenheit 
          avgTmp;        //avg temp in degrees Fahrenheit 
}; 

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {     
    //Declare and initialize variables 
    const int MONTHS=6;    //6 months for half a year 
    Month mthInfo[MONTHS]; //array of 6 structures, one for each month 
    float avgRain=0,       //average rainfall for the year 
          yearTmp=0,       //average temperature for the year 
          rainCtr=0,     //counter for sum of total rainfall 
          tmpCtr=0;      //counter for sum of total temperature 
    int lwstTmp,         //lowest temperature of the year 
        hgstTmp=0;       //highest temperature of the year 
    string lowMth,       //month with the lowest temperature 
           highMth;      //month with the highest temperature 
    
    //Read in weather info for each month 
    for (int i=JANUARY; i<=JUNE; static_cast<int>(i++)) { 
        cout<<"Enter the total rainfall for the month:"<<endl; 
        cin>>mthInfo[i].ttlRain; 
        cout<<"Enter the high temp:"<<endl;
        cin>>mthInfo[i].highTmp; 
        cout<<"Enter the low temp:"<<endl; 
        cin>>mthInfo[i].lowTmp; 
    } 
    
    //Calculate average rainfall for the year 
    for (int i=JANUARY; i<=JUNE; static_cast<int>(i++)) { 
        rainCtr+=mthInfo[i].ttlRain; 
        if (i==JUNE) { 
          avgRain=rainCtr/MONTHS; 
        } 
    } 
    
    //Determine month with the highest temperature 
    for (int i=JANUARY; i<=JUNE; static_cast<int>(i++)) { 
        if (mthInfo[i].highTmp>hgstTmp) { 
            hgstTmp=mthInfo[i].highTmp; 
        } 
    } 
    
    //Determine month with the lowest temperature 
    for (int i=JANUARY; i<=JUNE; static_cast<int>(i++)) { 
        if (mthInfo[i].lowTmp<lwstTmp) { 
            lwstTmp=mthInfo[i].lowTmp; 
        } 
    } 
    
    //Calculate average temperature for the year 
    for (int i=JANUARY; i<=JUNE; static_cast<int>(i++)) { 
        mthInfo[i].avgTmp=(mthInfo[i].highTmp+mthInfo[i].lowTmp)/2; 
        tmpCtr+=mthInfo[i].avgTmp; 
        if (i==JUNE) { 
            yearTmp=tmpCtr/MONTHS; 
        } 
    } 
    
    //Display outputs for each month 
    cout<<"Average monthly rainfall:"<<setprecision(2); 
    cout<<fixed<<avgRain<<endl; 
    cout<<"High Temp:"<<setprecision(0)<<fixed<<hgstTmp<<endl; 
    cout<<"Low Temp:"<<setprecision(0)<<fixed<<lwstTmp<<endl; 
    cout<<"Average Temp:"<<setprecision(1); 
    cout<<fixed<<yearTmp; 
    
    //Exit stage right!
    return 0;
} 
