/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 3:00 PM 
 * Purpose: Structures Movie Data 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <string>     //String Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 
struct MvieDat { 
    string Title,   //title of movie 
              Dirctr; //name of director 
    int YrRlsd,     //year movie released 
         RunTime; //movie run time, in minutes 
}; 

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare and initialize variables 
    int nMovies=5; //number of movies for array of structures 
    MvieDat movies[nMovies]; //array of movie data structures 
    
    //Output prompt and get info for number of movies 
    cout<<"This program reviews structures"<<endl; 
    cout<<"Input how many movies, the Title of the Movie, Director, "; 
    cout<<"Year Released, and the Running Time in (minutes)."<<endl; 
    cout<<endl; 
    cin>>nMovies; 
    
    //Use for Loop to get movie data for array of structures 
    for (int i=0; i<nMovies; i++) { 
        cin.ignore(); 
        getline(cin, movies[i].Title); 
        getline(cin, movies[i].Dirctr); 
        cin>>movies[i].YrRlsd; 
        cin>>movies[i].RunTime; 
    } 
    
    //Use a for Loop to display data for each movie 
    for (int i=0; i<nMovies; i++) { 
        //Display title, director, year released, and run time 
        cout<<setw(11)<<left<<"Title:"; 
        cout<<movies[i].Title<<endl; 
        cout<<setw(11)<<left<<"Director:"; 
        cout<<movies[i].Dirctr<<endl; 
        cout<<setw(11)<<left<<"Year:"; 
        cout<<movies[i].YrRlsd<<endl; 
        cout<<setw(11)<<left<<"Length:"; 
        cout<<movies[i].RunTime<<endl; 
        //Separate movies with a blank line 
        if (i<nMovies-1) cout<<endl; 
    } 
   
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
} 