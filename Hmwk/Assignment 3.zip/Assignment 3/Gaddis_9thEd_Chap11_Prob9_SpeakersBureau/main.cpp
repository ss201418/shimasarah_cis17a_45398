/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 8, 2021, 4:40 PM 
 * Purpose: Gaddis 9th Ed. Ch.11 Prob.9 - Speakers' Bureau 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <cstring>   //String Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structure Declaration 
struct Speaker { //structure for speaker's bureau 
    string Name,    //Name of speaker 
              TelNum, //Speaker's telephone number 
              Topic;    //Speaker topic 
    int FeeRqd; //Fee required 
}; 

//Function Prototypes 


//Execution Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize variables 
    const int SIZE=10; //number of speaker structures 
    Speaker speakrs[SIZE]; //array of speaker structures 
    int option; //selected menu option 
    
    //Read in values and select menu options 
    do { 
        //Display speaker info menu options 
        for (int i=0, j=1; i<SIZE; i++, j++) { 
            //Display speaker info menu heading 
            if (i==0) { 
            cout<<"Speaker's Bureau Main Menu"<<endl; 
            } 
            //Array of structures for speaker info 
            cout<<"Type "<<j<<" to see info for "; 
            cout<<"Speaker "<<j<<endl; 
            //Quit menu option 
            if (i==SIZE-1) { 
                cout<<"Or Type 11 to exit the menu"; 
                cout<<endl; 
            } 
        } 
        //Get input for speaker info menu options 
        cin>>option; 
        
        //Use if statement to filter out quit menu option 
        if (option!=11) { 
            
            //Display output for editing menu 
            cout<<"Speaker Info"<<endl; 
            cout<<"Type 1 to edit speaker name."<<endl; 
            cout<<"Type 2 to edit speaker phone number."<<endl; 
            cout<<"Type 3 to edit speaker topic."<<endl; 
            cout<<"Type 4 to edit fee required."<<endl; 
            cout<<"Or Type 5 to return to main menu"<<endl; 
            
            //Get input for editing menu options 
            cin>>option; 
            
            //Edit speaker info selected 
            if (option==1) { 
                cout<<"Enter new info for speaker name."<<endl; 
                cin>>speakrs[option].Name; 
            }  
            else if (option==2) { 
                cout<<"Enter new info for speaker phone "; 
                cout<<"number."<<endl; 
                cin>>speakrs[option].TelNum; 
            } 
            else if (option==3) { 
                cout<<"Enter new info for speaker topic."<<endl; 
                cin>>speakrs[option].Topic; 
            } 
            else if (option==4) { 
                cout<<"Enter new info for fee required."<<endl; 
                cin>>speakrs[option].FeeRqd; 
            } 
            else if (option==5) { 
                cout<<"Returning to main menu."<<endl; 
            } 
           
            //Confirm info edited and return to main menu 
            if (option!=5) { 
            cout<<"Speaker info has been edited, "; 
            cout<<"returning to main menu."<<endl; 
            } 
            
        //End of if statement to filter quit menu option 
        } 
        
    //End of do-while loop 
    } while(option!=11); 

    //Exit stage right!
    return 0;
} 
