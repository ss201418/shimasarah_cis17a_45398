/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 2:40 PM 
 * Purpose: Gaddis 9th Ed. Ch.11 Prob.3 - Sales Data 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <cstring>  //String Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes 

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Create structure template with data type Sales 
    struct Sales {         //structure to hold sales values 
        float q1,q2,q3,q4, //sales for each quarter 
              ttlAnn,      //total annual sales  
              avgQtr;      //average quarterly sales 
    }; 
    
    //Declare structures for data type Sales 
    Sales N,W,E,S;               //structures for each division  
    const int nDivs=4;           //number of sales divisions 
    string divs[nDivs]={"North", //division names 
                        "West", 
                        "East", 
                        "South"}; 
                        
    //Read in sales values for each division 
    for (int i=0; i<nDivs; i++) { 
        //Output name of a division 
        cout<<divs[i]<<endl; 
        //Read in sales values for quarter one 
        cout<<"Enter first-quarter sales:"<<endl; 
        switch (i) { 
          case 0: cin>>N.q1; 
                       break; 
          case 1: cin>>W.q1; 
                       break;
          case 2: cin>>E.q1; 
                       break;
          case 3: cin>>S.q1; 
                       break; 
        } 
        //Read in sales values for quarter two 
        cout<<"Enter second-quarter sales:"<<endl; 
        switch (i) { 
          case 0: cin>>N.q2; 
                       break; 
          case 1: cin>>W.q2; 
                       break;
          case 2: cin>>E.q2; 
                       break;
          case 3: cin>>S.q2; 
                       break; 
        } 
        //Read in sales values for quarter three 
        cout<<"Enter third-quarter sales:"<<endl; 
        switch (i) { 
          case 0: cin>>N.q3; 
                       break; 
          case 1: cin>>W.q3; 
                       break;
          case 2: cin>>E.q3; 
                       break;
          case 3: cin>>S.q3; 
                       break; 
        } 
        //Read in sales values for quarter four 
        cout<<"Enter fourth-quarter sales:"<<endl; 
        switch (i) { 
          case 0: cin>>N.q4; 
                       break; 
          case 1: cin>>W.q4; 
                       break;
          case 2: cin>>E.q4; 
                       break;
          case 3: cin>>S.q4; 
                       break; 
        }  
    
        //Display total annual sales for each division 
        cout<<"Total Annual sales:$"; 
        cout<<setprecision(2)<<fixed; 
        switch (i) { 
          case 0: N.ttlAnn=N.q1+N.q2+N.q3+N.q4,
                  cout<<N.ttlAnn;
                  break; 
          case 1: W.ttlAnn=W.q1+W.q2+W.q3+W.q4, 
                  cout<<W.ttlAnn;
                  break;
          case 2: E.ttlAnn=E.q1+E.q2+E.q3+E.q4, 
                  cout<<E.ttlAnn;
                  break;
          case 3: S.ttlAnn=S.q1+S.q2+S.q3+S.q4, 
                  cout<<S.ttlAnn;
                  break; 
        } 
        cout<<endl;
        
        //Display average quarterly sales for each division 
        cout<<"Average Quarterly Sales:$"; 
        cout<<setprecision(2)<<fixed; 
        switch (i) { 
          case 0: N.avgQtr=N.ttlAnn/nDivs, 
                  cout<<N.avgQtr; 
                  break; 
          case 1: W.avgQtr=W.ttlAnn/nDivs, 
                  cout<<W.avgQtr; 
                  break;
          case 2: E.avgQtr=E.ttlAnn/nDivs, 
                  cout<<E.avgQtr; 
                  break;
          case 3: S.avgQtr=S.ttlAnn/nDivs, 
                  cout<<S.avgQtr; 
                  break; 
        } 
        
        //Leave out endl for last line of output 
        if (i<nDivs-1) { 
            cout<<endl; 
        } 
    } 

    //Exit stage right!
    return 0;
} 
