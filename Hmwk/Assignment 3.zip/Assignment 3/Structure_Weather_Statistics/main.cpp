/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 3:00 PM 
 * Purpose: Structure Weather Statistics 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <string>     //String Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structure Declarations 
struct Month { 
    string mthName; //name of the month 
    float ttlRain,       //total rainfall in inches 
          highTmp,       //high temp in degrees Fahrenheit 
          lowTmp,        //low temp in degrees Fahrenheit 
          avgTmp;        //avg temp in degrees Fahrenheit 
}; 

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {     
    //Declare and initialize variables 
    const int MONTHS=12; //12 months in a year 
    Month mthInfo[12];   //array of 12 structures, one for each month 
    float avgRain=0,     //average rainfall for the year 
          yearTmp=0,       //average temperature for the year 
          rainCtr=0,     //counter for sum of total rainfall 
          tmpCtr=0;      //counter for sum of total temperature 
    int lwstTmp,         //lowest temperature of the year 
        hgstTmp=0;       //highest temperature of the year 
    string lowMth,       //month with the lowest temperature 
           highMth;      //month with the highest temperature 
    
    //Read in weather info for each month 
    for (int i=0; i<MONTHS; i++) {  
        cin>>mthInfo[i].mthName; 
        cin>>mthInfo[i].ttlRain; 
        cin>>mthInfo[i].lowTmp;
        cin>>mthInfo[i].highTmp; 
    } 
    
    //Calculate average rainfall for the year 
    for (int i=0; i<MONTHS; i++) { 
        rainCtr+=mthInfo[i].ttlRain; 
        if (i==MONTHS-1) { 
          avgRain=rainCtr/MONTHS; 
        } 
    } 
    
    //Determine month with the lowest temperature 
    for (int i=0; i<MONTHS; i++) { 
        if (mthInfo[i].lowTmp<lwstTmp) { 
            lowMth=mthInfo[i].mthName; 
            lwstTmp=mthInfo[i].lowTmp; 
        } 
    } 
    
    //Determine month with the highest temperature 
    for (int i=0; i<MONTHS; i++) { 
        if (mthInfo[i].highTmp>hgstTmp) { 
            highMth=mthInfo[i].mthName; 
            hgstTmp=mthInfo[i].highTmp; 
        } 
    } 
    
    //Calculate average temperature for the year 
    for (int i=0; i<MONTHS; i++) { 
        mthInfo[i].avgTmp=(mthInfo[i].highTmp+mthInfo[i].lowTmp)/2; 
        tmpCtr+=mthInfo[i].avgTmp; 
        if (i==MONTHS-1) { 
            yearTmp=tmpCtr/MONTHS; 
        } 
    } 
    
    //Display outputs for each month 
    cout<<"Average Rainfall "<<setprecision(2); 
    cout<<avgRain<<" inches/month"<<endl; 
    cout<<"Lowest  Temperature "<<lowMth<<"  "; 
    cout<<lwstTmp<<" Degrees Fahrenheit"<<endl; 
    cout<<"Highest Temperature "<<highMth<<"  "; 
    cout<<hgstTmp<<" Degrees Fahrenheit"<<endl; 
    cout<<"Average Temperature for the year "; 
    cout<<yearTmp<<" Degrees Fahrenheit"<<endl; 
    
    //Exit stage right!
    return 0;
} 