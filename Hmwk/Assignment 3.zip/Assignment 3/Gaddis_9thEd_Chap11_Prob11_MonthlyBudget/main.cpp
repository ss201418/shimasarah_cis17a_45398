/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 2:50 PM 
 * Purpose: Gaddis 9th Ed. Ch.11 Prob.11 - Monthly Sales 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <cstring>   //String Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structure Declaration 
struct MthBdgt { //monthly budget structure 
   float house,     //housing expenses 
           utilty,      //utilities expenses 
           hshold,    //household expenses 
           trnsprt,   //transportation expenses 
           food,       //food expenses 
           medical, //medical expenses 
           insrnce,  //insurance expenses 
           entrtn,    //entertainment expenses 
           clothes,  //clothing expenses 
           misc;      //miscellaneous expenses 
}; 

//Function Prototypes 
void getAmts(const int, MthBdgt&, MthBdgt&); //function to get amounts 
void compare(const int, MthBdgt&, MthBdgt&); //function to compare amounts 

//Execution Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize variables 
    const int SIZE=10; //number of budget categories 
    MthBdgt Goal={500.00, 150.00, 65.00, //goal amounts 
                           50.00, 250.00, 30.00, 
                           100.00, 150.00, 75.00, 50.00}, 
                 Actual; //actual amounts spent 
    
    //Function to get input values 
    getAmts(SIZE, Goal, Actual); 
    
    //Function to compare amounts 
    compare(SIZE, Goal, Actual); 

    //Exit stage right!
    return 0;
} 

//Function Implementations 

//Function to Get Amounts 
void getAmts(const int size, MthBdgt& goal, MthBdgt& actual) { 
    cout<<"Enter housing cost for the month:$"<<endl; 
    cin>>actual.house; 
    cout<<"Enter utilities cost for the month:$"<<endl; 
    cin>>actual.utilty; 
    cout<<"Enter household expenses cost for the month:$"<<endl; 
    cin>>actual.hshold; 
    cout<<"Enter transportation cost for the month:$"<<endl; 
    cin>>actual.trnsprt; 
    cout<<"Enter food cost for the month:$"<<endl; 
    cin>>actual.food; 
    cout<<"Enter medical cost for the month:$"<<endl; 
    cin>>actual.medical; 
    cout<<"Enter insurance cost for the month:$"<<endl; 
    cin>>actual.insrnce; 
    cout<<"Enter entertainment cost for the month:$"<<endl; 
    cin>>actual.entrtn; 
    cout<<"Enter clothing cost for the month:$"<<endl; 
    cin>>actual.clothes; 
    cout<<"Enter miscellaneous cost for the month:$"<<endl; 
    cin>>actual.misc; 
} 

//Function to Compare Amounts 
void compare(const int size, MthBdgt& goal, MthBdgt& actual) { 
    string temp,               //variable to hold comparison result 
              even="Even",    //actual amount equal to goal amount 
              over="Over",     //actual amount more than goal amount 
              under="Under"; //actual amount less than goal amount 
    float amtDiff=0,           //overall difference between actual and goal amounts 
            ttlGoal=1420.00,  //total amount of goal spending 
            ttlActl=0;             //total amount of actual spending 
    
    //Output Housing Comparison 
    if (actual.house!=goal.house) { 
      (actual.house>goal.house) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.house; 
    cout<<"Housing "<<temp<<endl; 
    
    //Output Utilities Comparison 
    if (actual.utilty!=goal.utilty) { 
      (actual.utilty>goal.utilty) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.utilty; 
    cout<<"Utilities "<<temp<<endl; 
    
    //Output Household Expenses Comparison 
    if (actual.hshold!=goal.hshold) { 
      (actual.hshold>goal.hshold) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.hshold; 
    cout<<"Household Expenses "<<temp<<endl; 
    
    //Output Transportation Expenses Comparison 
    if (actual.trnsprt!=goal.trnsprt) { 
      (actual.trnsprt>goal.trnsprt) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.trnsprt; 
    cout<<"Transportation "<<temp<<endl; 
    
    //Output Food Expenses Comparison 
    if (actual.food!=goal.food) { 
      (actual.food>goal.food) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.food; 
    cout<<"Food "<<temp<<endl; 
    
    //Output Medical Expenses Comparison 
    if (actual.medical!=goal.medical) { 
      (actual.medical>goal.medical) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.medical; 
    cout<<"Medical "<<temp<<endl; 
    
    //Output Insurance Expenses Comparison 
    if (actual.insrnce!=goal.insrnce) { 
      (actual.insrnce>goal.insrnce) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.insrnce; 
    cout<<"Insurance "<<temp<<endl; 
    
    //Output Entertainment Expenses Comparison 
    if (actual.entrtn!=goal.entrtn) { 
      (actual.entrtn>goal.entrtn) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.entrtn; 
    cout<<"Entertainment "<<temp<<endl; 
    
    //Output Clothing Expenses Comparison 
    if (actual.clothes!=goal.clothes) { 
      (actual.clothes>goal.clothes) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.clothes; 
    cout<<"Clothing "<<temp<<endl; 
    
    //Output Miscellaneous Expenses Comparison 
    if (actual.misc!=goal.misc) { 
      (actual.misc>goal.misc) ? temp=over: temp=under; 
    } 
    else temp=even;  
    ttlActl+=actual.misc; 
    cout<<"Miscellaneous "<<temp<<endl; 
    
    //Output overall result of comparisons 
    if (ttlActl!=ttlGoal) { 
        if (ttlActl>ttlGoal) { 
            temp="over"; 
            amtDiff=ttlActl-ttlGoal; 
        } 
        else { 
          temp="under";   
          amtDiff=ttlGoal-ttlActl; 
        } 
    } 
    else temp="over"; 
    cout<<"You were $"<<setprecision(2)<<fixed<<amtDiff; 
    cout<<" "<<temp<<" budget"; 
} 
