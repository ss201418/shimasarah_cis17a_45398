/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 2:50 PM 
 * Purpose: Structure Drink Machine Simulator 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <string>   //String Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structure Declarations 
struct Drink { 
    string Name; //name of the drink 
    int Cost,        //cost of the drink 
         nDrinks;   //number of drinks in machine 
};

//Function Prototypes 

//Execution Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize variables 
    const int SIZE=5; //number of drink info structures 
    Drink drinks[SIZE]={"Cola", 75, 20, 
                                       "Root Beer", 75, 20, 
                                       "Lemon-Lime", 75, 20, 
                                       "Grape Soda", 80, 20, 
                                       "Cream Soda", 80, 20}; 
    bool soldOut=false; //boolean variable for sold out drinks 
    string optName; //drink option name 
    int amtPaid=0,  //amount paid by user 
         change=0,    //change for amount paid 
         amtErnd=0; //amount earned by machine 
    
    //Read in values and select menu options 
    do { 
        //Display output for drink menu 
        for (int i=0; i<SIZE; i++) { 
            //Array of structures for drink info 
            cout<<setw(11)<<left<<drinks[i].Name; 
            cout<<setw(3)<<left<<drinks[i].Cost; 
            cout<<setw(3)<<right<<drinks[i].nDrinks<<endl; 
            //Quit menu option 
            if (i==SIZE-1) cout<<"Quit"<<endl; 
        } 

        //Read in drink options 
        getline(cin,optName); 
        
        //Output message if drink option sold out 
        for (int i=0; i<SIZE; i++) { 
            if (optName==drinks[i].Name) { 
                if (drinks[i].nDrinks==0) { 
                    cout<<"That drink is sold out."<<endl; 
                } 
            } 
        } 
        
        //Use if statement to filter out quit menu option 
        if (optName!="Quit") { 
        
            //Use do-while Loop to read in amount paid 
            do { 
                cin>>amtPaid; 
            } while (amtPaid<0 || amtPaid>100); 

            //Increment counter for amount earned by machine 
            amtErnd+=amtPaid; 

            //Output change for amount paid 
            for (int i=0; i<SIZE; i++) { 
                if (optName==drinks[i].Name) { 
                    (drinks[i].Cost==75) ? 
                        change=amtPaid-75: change=amtPaid-80; 
                } 
            } 
            cout<<change<<endl; 
            
             //Decrement counter for amount earned by machine 
            amtErnd-=change; 

            //Decrement number of drinks 
            for (int i=0; i<SIZE; i++) { 
                if (optName==drinks[i].Name) drinks[i].nDrinks--; 
            } 

            //Clear buffer for next loop iteration 
            cin.ignore(); 
            } 
    
    //End of do-while loop 
    } while(optName!="Quit"); 
    
    //Display output for amount earned by machine 
    cout<<amtErnd<<endl; 
    
    //Exit stage right!
    return 0;
} 
