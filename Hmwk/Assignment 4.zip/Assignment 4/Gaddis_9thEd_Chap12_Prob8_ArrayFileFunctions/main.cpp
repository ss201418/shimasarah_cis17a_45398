/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 9, 2021, 8:00 PM 
 * Purpose: Gaddis 9th Ed. Ch.12 Prob.8 - Array File Functions 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <cstring>   //String Library 
#include <fstream>  //Stream Library
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes 
void toFile(string,int *,const int); //function to write to file 
void toAry(string,int *,const int);     //function to read from file 

//Execution Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize variables 
    const int SIZE=10; //size of int array 
    int array[SIZE]={1,2,3,4,5, //array of int values 
                            6,7,8,9,10}; 
    
    //Function to write to text file in binary 
    toFile("binary_test_file.txt",array,SIZE); 
    
    //Function to read from text file in binary 
    toAry("binary_test_file.txt",array,SIZE); 
    
    //Display output for array int values 
    for (int i=0; i<SIZE; i++) { 
        cout<<array[i]<<" "; 
    } 
    cout<<endl; 
    
    //Exit stage right!
    return 0;
} 

//Function Implementations 

//Function to write to file 
void toFile(string fileNm,int *array,const int size) { 
    //Declare fstream variable 
    fstream file; 
    
    //Open the text file in binary mode 
    file.open(fileNm,ios::out|ios::trunc|ios::binary); 
    
    //Write array values to file in binary 
    file.write(reinterpret_cast<char *>(array), sizeof(array));  
    
    //Close the text file 
    file.close(); 
} 

//Function to read from file 
void toAry(string fileNm,int *array,const int size) { 
    //Declare fstream variable 
    fstream file; 
    
    //Open the text file in binary mode 
    file.open(fileNm,ios::in|ios::binary); 
    
    //Read array values from file in binary 
    file.read(reinterpret_cast<char *>(array), sizeof(array));  
    
    //Close the text file 
    file.close(); 
} 
