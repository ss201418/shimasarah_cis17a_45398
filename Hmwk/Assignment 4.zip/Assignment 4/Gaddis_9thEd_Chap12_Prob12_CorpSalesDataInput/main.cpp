/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 9, 2021, 10:00 PM 
 * Purpose: Gaddis 9th Ed. Ch.12 Prob.12 - Corp. Sales Data Input 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>   //Formatting Library 
#include <cstring>    //String Library 
#include <fstream>   //Stream Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structure Declarations 
struct Sales {    //structure to hold qtr sales for a division 
    string Name; //div name - East, West, North, or South 
    int Qtr;          //sales qtr - 1, 2, 3, or 4 
    float qSales; //sales info for the div qtr 
}; 

//Function Prototypes 
void stats(string,Sales *,int,int); 

//Execution Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize variables 
    const int SIZE=16; 
    Sales arr[SIZE]; //N,S,E,W 4 qtrs 
    float cQtr1=0, cQtr2=0, cQtr3=0, cQtr4=1500.00, 
            corpYr=0, //corp qtrs and yrly sales 
            year, avg, hiQtr, lwQtr; //div sales 
    int j=0, ctr=0; //subscript counters 
    string file="sales_file.txt", //file name 
              div; //div name for sales stats 
    fstream in; 
    //Open file 
    in.open(file,ios::in|ios::binary); 
    //Test read in file 
    while (!in.eof()) { 
        in.read(reinterpret_cast<char *>(&arr[ctr]),sizeof(arr[ctr])); 
        ctr++; 
    } 
    //Reset counter 
    ctr=0; 
    //Close file 
    in.close(); 
    //Use for Loop to calculate corp sales 
    for (int i=0; i<SIZE; i++) { 
        //Calculate corp sales for each qtr 
        if (arr[i].Qtr==1) cQtr1+=arr[i].qSales; 
        else if (arr[i].Qtr==2) cQtr2+=arr[i].qSales; 
        else if (arr[i].Qtr==3) cQtr3+=arr[i].qSales; 
        else if (arr[i].Qtr==4) cQtr3+=arr[i].qSales; 
        //Calculate yearly corp sales 
        corpYr=cQtr1+cQtr2+cQtr3+cQtr4; 
    } 
    //Display output for corp sales stats 
    cout<<"Corporate Sales Stats: "<<endl;  
    cout<<setprecision(2)<<fixed; 
    cout<<"Quarter 1 Sales = $"<<cQtr1<<endl;  
    cout<<setprecision(2)<<fixed; 
    cout<<"Quarter 2 Sales = $"<<cQtr2<<endl;  
    cout<<setprecision(2)<<fixed; 
    cout<<"Quarter 3 Sales = $"<<cQtr3<<endl;  
    cout<<setprecision(2)<<fixed; 
    cout<<"Quarter 4 Sales = $"<<cQtr4<<endl;  
    cout<<setprecision(2)<<fixed; 
    cout<<"Yearly Sales = $"<<corpYr<<endl; 
    cout<<endl; 
    //Calculate and display div sales stats 
    for (int i=0; i<SIZE; i++) { 
        //Initialize div name variable 
        if (i<=3) div="North"; 
        else if (i>=4 && i<=7) div="South"; 
        else if (i>=8 && i<=11) div="East"; 
        else if (i>=12) div="West"; 
        //Initialize variables if first qtr of div 
        if (j==0) year=0, avg=0, hiQtr=0, lwQtr=1500.00; 
        //Calculate div sales stats 
        if (j<4) { 
            //Div yearly sales 
            year+=arr[i].qSales; 
            //Div average sales 
            if (j==3) avg=year/4; 
            //Div high qtrly sales 
            if (arr[i].qSales>hiQtr) 
                hiQtr=arr[i].qSales; 
            //Div low qtrly sales 
            if (arr[i].qSales<lwQtr) 
                lwQtr=arr[i].qSales; 
        } 
        //Display output and reset stats for next div 
        if (j==3) { 
            //Display output for div sales stats 
            cout<<div<<" Sales Stats: "<<endl; 
            cout<<setprecision(2)<<fixed; 
            cout<<"Yearly Sales = $"<<year<<endl;  
            cout<<setprecision(2)<<fixed; 
            cout<<"Average Quarter Sales = $"<<avg<<endl;  
            cout<<setprecision(2)<<fixed; 
            cout<<"High Quarter Sales = $"<<hiQtr<<endl;  
            cout<<setprecision(2)<<fixed; 
            cout<<"Low Quarter Sales = $"<<lwQtr<<endl;  
            cout<<setprecision(2)<<fixed; 
            cout<<endl; 
        } 
        //Update or reset qtr subscript counter 
        (j==3) ? j=0: j++;  
    } 
    //Exit stage right!
    return 0; 
} 

//Function Implementations 

//Function to calculate sales stats 
void stats(string div, Sales *arr, int i, int max) { 
    //Declare sales stats variables 
    float year, avg, hiQtr, lwQtr; 
    //Initialize variables if first qtr of div 
    if (i==(max-3)) year=0, avg=0, hiQtr=0, lwQtr=1500.00; 
    //Div yearly sales 
    year+=arr[i].qSales; 
    //Div average sales 
    if (i==max) avg=year/4; 
    //Div high qtrly sales 
    if (arr[i].qSales>hiQtr) 
        hiQtr=arr[i].qSales; 
    //Div low qtrly sales 
    if (arr[i].qSales<lwQtr) 
        lwQtr=arr[i].qSales; 
    //Display output and reset stats for next div 
    if (i==max) { 
        //Display output for div sales stats 
        cout<<div<<" Sales Stats: "<<endl; 
        cout<<setprecision(2)<<fixed; 
        cout<<"Yearly Sales = $"<<year<<endl;  
        cout<<setprecision(2)<<fixed; 
        cout<<"Average Quarter Sales = $"<<avg<<endl;  
        cout<<setprecision(2)<<fixed; 
        cout<<"High Quarter Sales = $"<<hiQtr<<endl;  
        cout<<setprecision(2)<<fixed; 
        cout<<"Low Quarter Sales = $"<<lwQtr<<endl;  
        cout<<setprecision(2)<<fixed; 
        cout<<endl; 
    } 
} 
