/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 2:40 PM 
 * Purpose: Gaddis 9th Ed. Ch.12 Prob.7 - Sentence Filter 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <string>     //String Library 
#include <cctype>    //Character Library 
#include <fstream>  //Stream Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes 

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables 
    char ch; //temp char holders 
    int fileSze=0; //cntr and file size 
    bool match=0; //bool to match cases 
    fstream txtFile; 
    string file="test_read_from_file.txt", 
              text; //string read in from file 
    //Open file for input 
    txtFile.open(file,ios::in); 
    //Read in first char and confirm uppercase 
    txtFile.get(ch); 
    //Add first char value to string 
    text+=toupper(ch); 
    //Read in rest of file and compare cases 
    while (txtFile.get(ch)) { 
        //Convert to lowercase if uppercase 
        if (ch>='A' && ch<='Z') text+=tolower(ch); 
        //Leave as is if lowercase 
        else if (ch>='a' && ch<='z') text+=tolower(ch); 
        //Capitalize next letter if end of sentence 
        else if (ch=='!' || ch=='.' || ch=='?') { 
            //Store symbol in string 
            text+=ch; 
            //Use while Loop to find next letter 
            while (!match) { 
                //Get next char value to compare 
                txtFile.get(ch); 
                //Convert to uppercase if lowercase 
                if (ch>='a' && ch<='z') { 
                    text+=toupper(ch); 
                    match=true; 
                } 
                //Leave as is if uppercase 
                else if (ch>='A' && ch<='Z') { 
                    text+=toupper(ch); 
                    match=true; 
                } 
                //Skip to next char if not a letter 
                else { 
                    //Add char value to string 
                    text+=ch; 
                    //End loop if end of file 
                    (!txtFile.eof()) ? 
                        match=false: match=true; 
                } 
            } 
            //Reset bool value for matching 
            match=false; 
        } 
        //Skip to next char if no conditions met 
        else text+=ch; 
    } 
    //Close file 
    txtFile.close(); 
    //Reopen file for output 
    txtFile.open(file,ios::out|ios::trunc); 
    //Rewrite edited text to file 
    txtFile<<text; 
    //Close file 
    txtFile.close(); 
    //Exit stage right!
    return 0;
} 
