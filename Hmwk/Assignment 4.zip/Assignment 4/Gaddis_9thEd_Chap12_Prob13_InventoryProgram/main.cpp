/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7, 2021, 2:40 PM 
 * Purpose: Gaddis 9th Ed. Ch.12 Prob.13 - Inventory Program 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <cstring>   //String Library 
#include <fstream>  //Stream Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions


//Structure Declarations 
struct Item { 
    string Info;     //item description 
    int Qty;           //item quantity 
    float retail,     //retail price 
            whlsale; //wholesale price 
}; 

//Function Prototypes 
void addItem(Item &); 
void toFile(Item &,fstream &,string &); 
void readIn(Item &,fstream &,string &); 
void display(Item &); 
void edit(Item &); 

//Execution Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize variables 
    Item tmpItem; //array to hold temp item 
    int option=0;    
    bool optExit=false; //bool to exit menu 
    string itemNm,  
              fileNm="items_text_file.txt"; 
    fstream txtFile;      
    
    //Use while Loop for menu options 
    while (!optExit) { 
        //Display output for main menu options 
        cout<<"Inventory Main Menu"<<endl; 
        cout<<"Type 1 to add a record."<<endl; 
        cout<<"Type 2 to view a record."<<endl; 
        cout<<"Type 3 to edit a record."<<endl; 
        cout<<"Type 4 to exit the menu."<<endl; 
        cin>>option; 

        //Add a record and store in file 
        if (option==1) { 
            //Add record in temp struct 
            addItem(tmpItem); 
            //Write temp struct to file 
            toFile(tmpItem,txtFile,fileNm); 
        } 
        
        //View a record from file 
        else if (option==2) { 
            //Read in record from file 
            readIn(tmpItem,txtFile,fileNm); 
            //Display output for item values 
            display(tmpItem); 
            //Store record back in file 
            toFile(tmpItem,txtFile,fileNm); 
        } 
        
        //Edit a record from file 
        else if (option==3) { 
            //Read in record from file 
            readIn(tmpItem,txtFile,fileNm); 
            //Display output for item values 
            display(tmpItem); 
            //Edit item values 
            edit(tmpItem); 
            //Store record back in file 
            toFile(tmpItem,txtFile,fileNm); 
        } 
        
        //Exit main menu 
        else if (option==4) { 
            cout<<"Now exiting main menu."<<endl; 
            optExit=true; 
        } 
        
        //Restart if input value invalid 
        else { 
            cout<<"Please select a menu option and "; 
            cout<<"type in a value between 1 and 4."<<endl; 
        } 
    //End of while Loop 
    } 
    
    //Exit stage right!
    return 0;
} 

//Function Implementations 

//Function to Add an Item 
void addItem(Item &temp) { 
    //Declare and initialize variables 
    float whlPrce, //wholesale price 
            rtlPrce;   //retail price 
    int itemQty;    //item quantity 
    //Get input for item struct 
    cout<<"Add a Record"<<endl; 
    cout<<"Enter the item name: "<<endl; 
    cin>>temp.Info; 
    cout<<"Item Quantity: "<<endl; 
    cin>>temp.Qty; 
    cout<<"Wholesale price: "<<endl; 
    cin>>temp.whlsale; 
    cout<<"Retail price: "<<endl; 
    cin>>temp.retail; 
    cout<<endl<<endl; 
} 

//Function to Write an item to File 
void toFile(Item &temp, fstream &txtFile, string &file) { 
    //Open file 
    txtFile.open(file,ios::out|ios::app); 
    //Write struct values to file 
    txtFile<<temp.Info<<" "; 
    txtFile<<temp.Qty<<" "; 
    txtFile<<setprecision(2)<<fixed; 
    txtFile<<temp.whlsale<<" "; 
    txtFile<<setprecision(2)<<fixed; 
    txtFile<<temp.retail<<endl; 
    txtFile<<endl; 
    //Close file 
    txtFile.close(); 
} 

//Function to Read in an Item from File 
void readIn(Item &temp, fstream &txtFile, string &file) { 
    //Declare and initialize variables 
    bool match=false; //bool for matching  
    string itemNm;     //name of item to match 
    Item *tmpArry=nullptr; //ptr for struct array 
    int i=0; //subscript counter for temp struct array 
    //Dynamically allocate ptr for struct array 
    tmpArry=new Item[80]; 
    //Get input for name of item 
    cout<<"Enter name of item: "<<endl; 
    cin>>itemNm; 
    //Open file for input and output 
    txtFile.open(file,ios::in|ios::out); 
    //Search file for name of the item 
    while (!match) { 
        //Get all info for temp struct 
        txtFile>>temp.Info; 
        txtFile>>temp.Qty; 
        txtFile>>temp.whlsale;  
        txtFile>>temp.retail; 
        //Bool variable for matching 
        (itemNm==temp.Info) ? 
            match=true: match=false; 
        //Store in temp array if no match 
        if (match==false) { 
            tmpArry[i].Info=temp.Info; 
            tmpArry[i].Qty=temp.Qty; 
            tmpArry[i].whlsale=temp.whlsale; 
            tmpArry[i].retail=temp.retail; 
        } 
        //Increment subscript counter 
        i++; 
    } 
    //Store rest of file in temp array 
    while (!txtFile.eof()) { 
        //Get all info for each struct 
        txtFile>>tmpArry[i].Info; 
        txtFile>>tmpArry[i].Qty; 
        txtFile>>tmpArry[i].whlsale;  
        txtFile>>tmpArry[i].retail; 
        //Increment subscript counter 
        i++; 
    } 
    //Rewrite non-matching structs to file 
    for (int j=0; j<=i; j++) { 
        txtFile<<tmpArry[i].Info<<" "; 
        txtFile<<tmpArry[i].Qty<<" "; 
        txtFile<<setprecision(2)<<fixed; 
        txtFile<<tmpArry[i].whlsale<<" "; 
        txtFile<<setprecision(2)<<fixed; 
        txtFile<<tmpArry[i].retail<<endl; 
        txtFile<<endl; 
    } 
    //Delete memory allocation 
    delete [ ] tmpArry; 
    tmpArry=nullptr; 
    //Close file 
    txtFile.close(); 
} 

//Function to Display Item Values 
void display(Item &temp) { 
    //Display output for record values 
    cout<<"Item Name: "; 
    cout<<temp.Info<<endl; 
    cout<<"Item Quantity: "; 
    cout<<temp.Qty<<endl; 
    cout<<"Wholesale Price: "; 
    cout<<setprecision(2)<<fixed; 
    cout<<temp.whlsale<<endl; 
    cout<<"Retail Price: "; 
    cout<<setprecision(2)<<fixed; 
    cout<<temp.retail<<endl; 
    cout<<endl<<endl; 
} 

//Function to Edit Item Values  
void edit(Item &temp) { 
    //Declare and initialize variables 
    int editOpt=0; 
    while (editOpt!=5) { 
        //Display output for edit menu options 
        cout<<"Choose an entry to edit: "<<endl; 
        cout<<"Type 1 to edit item name."<<endl; 
        cout<<"Type 2 to edit item quantity."<<endl; 
        cout<<"Type 3 to edit wholesale price."<<endl; 
        cout<<"Type 4 to edit retail price."<<endl; 
        cout<<"Type 5 to return to main menu."<<endl; 
        cout<<endl; 
        cin>>editOpt; 
        //Get info for entry to be edited 
        if (editOpt==1) { 
            cout<<"Enter the item name: "<<endl; 
            cin>>temp.Info; 
        } 
        else if (editOpt==2) { 
            cout<<"Enter a quantity: "<<endl; 
            cin>>temp.Qty; 
        } 
        else if  (editOpt==3) { 
            cout<<"Enter item's wholesale price: "<<endl; 
            cin>>temp.whlsale; 
        } 
        else if  (editOpt==4) { 
            cout<<"Enter item's retail price: "<<endl; 
            cin>>temp.retail; 
        } 
        else if  (editOpt==5) { 
            cout<<"Now returning to main menu."<<endl; 
            cout<<endl; 
        } 
        else { 
            cout<<"Please select a menu option and "; 
            cout<<"type in a value between 1 and 5."<<endl; 
        } 
        //Display edited item values 
        display(temp); 
    //End of while Loop 
    } 
} 
