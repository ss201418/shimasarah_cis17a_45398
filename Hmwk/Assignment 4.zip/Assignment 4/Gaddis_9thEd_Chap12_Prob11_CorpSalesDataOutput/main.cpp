/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 9, 2021, 9:00 PM 
 * Purpose: Gaddis 9th Ed. Ch.12 Prob.11 - Corp. Sales Data Output 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Formatting Library 
#include <cstring>     //String Library 
#include <fstream>  //Stream Library 
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Structure Declarations 
struct Sales {    //structure to hold qtr sales for a division 
    string Name; //div name - East, West, North, or South 
    int Qtr;          //sales qtr - 1, 2, 3, or 4 
    float qSales; //sales info for the div qtr 
}; 

//Function Prototypes 
void inSales(Sales *,const int); 
void toFile(string,Sales *,const int); 

//Execution Begins Here
int main(int argc, char** argv) { 
    //Declare and initialize variables 
    const int SIZE=16; 
    Sales array[SIZE]; //N,S,E,W 4 qtrs 
    int i=0; //subscript counter 
    string fileNm="sales_test_file.txt"; //file name 
    //Store sales info in struct for each div qtr 
    inSales(array,SIZE); 
    //Write sales info to binary file 
    toFile(fileNm,array,SIZE); 
    //Exit stage right!
    return 0; 
} 

//Function Implementations 

//Function to store sales info in struct arrays 
void inSales(Sales *div, const int size) { 
    //Use for Loop to store info for each div qtr 
    for (int i=0; i<size; i++) { 
        //Separate structs in array by div qtr 
        if (i<=3) { 
            div[i].Name="North"; 
            div[i].Qtr=i+1; 
            div[i].qSales=(static_cast<float>(i+1)*100.00); 
        } 
        else if (i>=4 && i<=7) { 
            div[i].Name="South"; 
            div[i].Qtr=i-3; 
            div[i].qSales=(static_cast<float>(i+1)*100.00); 
        } 
        else if (i>=8 && i<=11) { 
            div[i].Name="East"; 
            div[i].Qtr=i-7; 
            div[i].qSales=(static_cast<float>(i+1)*100.00/2); 
        } 
        else if (i>=12) { 
            div[i].Name="West"; 
            div[i].Qtr=i-11; 
            div[i].qSales=(static_cast<float>(i+1)*100.00/2); 
        } 
    } 
} 

//Function to write sales info to binary file 
void toFile(string file, Sales *div, const int size) { 
    //Declare fstream variable 
    fstream out; 
    //Open binary file 
    out.open(file,ios::out|ios::trunc|ios::binary); 
    //Use for Loop to write info for each div qtr 
    for (int i=0; i<size; i++) { 
        out.write(reinterpret_cast<char *>(&div[i]),sizeof(div[i])); 
    } 
    //Close binary file 
    out.close(); 
} 
