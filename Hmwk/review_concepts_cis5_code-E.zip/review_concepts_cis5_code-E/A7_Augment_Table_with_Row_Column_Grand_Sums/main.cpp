/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on June 28, 2021, 5:10 PM 
 * Purpose:  Sum Rows, Sum Columns, Grand Sum of an integer array
 */

//System Libraries Here
#include <iostream>//cin,cout
#include <iomanip> //setw(10)
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Allowed like PI, e, Gravity, conversions, array dimensions necessary
const int COLMAX=80;  //Max Columns much larger than needed.

//Function Prototypes Here
void readArr(int [][COLMAX],int &,int &);//Prompt for size then table
void sumArr(const int [][COLMAX],int,int,int[][COLMAX]);//Sum rows,col,grand total
void prntArr(const int [][COLMAX],int,int,int);//Either table can be printed

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int ROW=80;           //Max Rows much larger than needed
    int array[ROW][COLMAX]={};  //Declare original array
    int augArr[ROW][COLMAX]={}; //Actual augmented table row+1, col+1
    int row,col;                
    
    //Input the original table
    readArr(array,row,col);
    
    //Augment the original table by the sums
    sumArr(array,row,col,augArr);
    
    //Output the original array
    cout<<endl<<"The Original Array"<<endl;
    prntArr(array,row,col,10);//setw(10)
    
    //Output the augmented array
    cout<<endl<<"The Augmented Array"<<endl;
    prntArr(augArr,row+1,col+1,10);//setw(10)
    
    //Exit
    return 0;
} 

void readArr(int arrRead[][COLMAX],int &inptRow,int &inptCol) { 
    
    //Describe purpose of augmented array program 
    cout<<"Input a table and output the Augment row,"; 
    cout<<"col and total sums."<<endl; 
    //Output prompt for number of rows and columns 
    do { 
    cout<<"First input the number of rows and cols. <20 "; 
    cout<<"for each"<<endl; 
    //Read in number of rows and columns 
    cin>>inptRow>>inptCol; 
    } while (inptRow>=20 || inptCol>=20); 
    //Output prompt for table values 
    cout<<"Now input the table."<<endl; 
    //Count rows and columns to read in original array 
    for (int row=0; row<inptRow; row++) { 
        for (int col=0; col<inptCol; col++) { 
            //Read in original array values 
            cin>>arrRead[row][col]; 
        } 
    } 
} 


void sumArr(const int arr[][COLMAX],int rows,int cols,int aug[][COLMAX]) { 
    //Declare and initialize variables 
    int max=0, sumRow=0, sumCol=0, total=0; 
    //Create augmented array with original array values 
    for (int row=0; row<rows; row++) { 
        for (int col=0; col<cols; col++) { 
            //Copy array values to augmented array 
            aug[row][col]=arr[row][col]; 
        } 
    } 
    //Determine max count of each for Loop 
    rows>cols ? max=rows: max=cols; 
    //Use a for Loop to count rows and columns 
    for (int i=0; i<max; i++) { 
        for (int j=0; j<max; j++) { 
            //Add up values for each row and column 
            sumRow+=aug[i][j]; 
            sumCol+=aug[j][i]; 
            //Store subtotals in augmented array 
            if (j==max-1) { 
                aug[i][cols]=sumRow; 
                aug[rows][i]=sumCol; 
            } 
        } 
        //Add up subtotals to find total of all values 
        total+=sumRow; 
        //Reset sum values for next row 
        sumRow=0; sumCol=0; 
        //Store total at bottom right of augmented array 
        i==max-1 ? aug[rows][cols]=total: aug[rows][cols]=0; 
    } 
} 


void prntArr(const int arrPrnt[][COLMAX],int rowPrnt,int colPrnt,int wdthVal) { 
    //Count rows and columns to print the array 
    for (int row=0; row<rowPrnt; row++) { 
        //Print out spacing before values 
        cout<<setw(wdthVal)<<right; 
        //Print out row and column values of array 
        for (int col=0; col<colPrnt; col++) { 
            //Print out spacing between values 
            cout<<setw(wdthVal)<<right; 
            //Print out array values 
            cout<<arrPrnt[row][col]; 
        } 
        //Start a new line for each row 
        cout<<endl; 
    } 
} 
