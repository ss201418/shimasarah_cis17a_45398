/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on June 28, 2021, 5:30 PM 
 * Purpose:  Input something, output it reversed with some modifications
 * Note:Range should be 5 digits -> 321 = 00321 
 * -> reverse = 12300 before subtraction 
 * -> 12300 - 999 = 11301 after subtraction 
 * -> 12300 = 00321 = 321 after reversal and no subtraction 
 */ 

//System Libraries Here
#include <iostream>//cin,cout,endl
#include <cstring> //strlen( ) 
#include <cmath>   //exponents 
using namespace std;
//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
bool  inRange(const char [ ], unsigned short &); //Output true,unsigned or false 
bool  reverse(unsigned short, signed short &);  //Output true,short or false 
short subtrct(signed short, int); 

//Program Execution Begins Here 
int main(int argc, char** argv) { 
    //Declare all Variables Here 
    const int SIZE=80;   //More than enough 
    char  digits[SIZE];    //Character digits or not 
    unsigned short unShort; //Unsigned short 
    short snShort;         //Signed short 
    
    //Input or initialize values Here 
    cout<<"Reverse a number and subtract if possible."<<endl; 
    cout<<"Input a number in the range of an unsigned short"<<endl; 
    cin>>digits; 
    
    //Test if it is in the Range of an unsigned short 
    if (!inRange(digits, unShort)) { 
        cout<<"No Conversion Possible"<<endl; 
        return 0; 
    } 
    
    //Reverse and see if it falls in the range of an signed short 
    if (!reverse(unShort, snShort)) { 
        cout<<"No Conversion Possible"<<endl; 
        return 0; 
    } 
    
    //Now subtract if the result is not negative else don't subtract 
    snShort=subtrct(snShort, 999); 
    
    //Output the result 
    cout<<snShort<<endl; 
    
    //Exit 
    return 0; 
} 

//Function Definition for Unsigned in Range 
bool  inRange(const char num[ ], unsigned short &unsnNum) { 
    //Declare bool and int variables 
    bool  cnvPoss, range; 
    int length=strlen(num), noCnvrt=0, multVal, numVal; 
    //Determine if conversion possible 
    for (int i=0; i<length; i++) { 
        //Cannot convert if not all numbers in string  
        (num[i]<48 || num[i]>57)? noCnvrt++: noCnvrt; 
    } 
    //Conversion not possible if noCnvrt value greater than 0 
    (noCnvrt>0)? cnvPoss=false: cnvPoss=true; 
    //Range is false if conversion not possible 
    if (cnvPoss==false) { 
        range=false; 
    } 
    //Otherwise convert value and determine if in range 
    else if (cnvPoss==true) { 
        //Initialize multVal to max. digit level of string 
        multVal=1*pow(10,(length-1)); 
        //Convert array elements to unsigned short int 
        for (int j=0; j<length; j++) {  
            //Convert array elements to integer values 
            switch (num[j]) { 
                case '0': numVal=0; break; 
                case '1': numVal=1; break;  
                case '2': numVal=2; break; 
                case '3': numVal=3; break; 
                case '4': numVal=4; break; 
                case '5': numVal=5; break; 
                case '6': numVal=6; break; 
                case '7': numVal=7; break; 
                case '8': numVal=8; break; 
                case '9': numVal=9; break; 
            } 
            //Find digit levels, add together for unsnNum value 
            unsnNum+=(numVal*multVal); 
            //Update multVal to reflect next digit level 
            multVal/=10; 
        } 
        //Test unsigned short int against range values 
        (unsnNum>=0 && unsnNum<=65535)? range=true: range=false; 
    } 
    //Return result to function main 
    return range; 
} 

//Function Definition for Signed in Range 
bool  reverse(unsigned short unsnNum, signed short &snNum) { 
    //Declare variables 
    bool snRange; 
    //Create for Loop to reverse digits 
    for (int oNum=0; oNum<5; oNum++) { 
        for (int nwNum=4; nwNum>=0; nwNum--) { 
            
        } 
    } 
    int tnThns, thns, hnds, tens, ones, 
        nwTnTh, rTnTh, nwThns, rThns, nwHnds, 
        rHnds, nwTens, nwOnes; 
    //Isolate digits for reversal 
    tnThns=unsnNum/10000; 
     rTnTh=unsnNum%10000; 
      thns=rTnTh/1000; 
     rThns=rTnTh%1000; 
      hnds=rThns/100; 
     rHnds=rThns%100; 
      tens=hnds/10; 
      ones=hnds%10; 
    //Reverse digits from unsigned short 
    nwTnTh=ones;   //ones is now ten thousands 
    nwThns=tens;   //tens is now thousands 
    nwHnds=hnds;   //hundreds stays the same 
    nwTens=thns;   //thousands is now tens 
    nwOnes=tnThns; //ten thousands is now ones 
    //Add new digits together to get signed short 
    snNum=nwTnTh+nwThns+nwHnds+nwTens+nwOnes; 
    //Test signed short int against range values 
    (snNum>=-32768 && snNum<=32767)? snRange=true: snRange=false; 
    //Return range result to function main 
    return snRange; 
} 

//Function Definition for Subtraction Result 
short subtrct(signed short signNum, int toSubt) { 
     //Declare variables 
    int newNum, subtNum; 
    //Determine value to subtract 
    if (signNum>=0) { 
        (signNum>=1000)? 
            subtNum=toSubt: 
            subtNum=(signNum-1); 
    } 
    else 
        subtNum=0; 
    //Subtract value from signed short 
    newNum=signNum-subtNum; 
    //Return new value to function main 
    return newNum; 
} 

