/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on June 28th, 2021, 4:30 PM 
 * Purpose:  Sorting an array of characters if specified correctly
 */

//System Libraries Here
#include <iostream>//cout, cin 
#include <cstring> //strlen( ) 
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
int  readArr(char [ ]); 
void sortArr(char [ ], int); 
void prntArr(const char [ ], int); 

//Program Execution Begins Here
int main(int argc, char** argv) { 
    //Declare all Variables Here
    const int SIZE=80; //Larger than needed
    char array[SIZE];   //Character array larger than needed
    int sizeIn, sizeDet; //Number of characters to be read, check against length
    
    //Input the size of the array you are sorting
    cout<<"Read in a 1 dimensional array of characters and sort"<<endl;
    cout<<"Input the array size where size <= 20"<<endl;
    cin>>sizeIn; 
    
    //Now read in the array of characters and determine it's size
    cout<<"Now read the Array"<<endl;
    sizeDet=readArr(array); //Determine its size 
    
    //Compare the size input vs. size detected and sort if same 
    //Else output different size to sort 
    if (sizeDet==sizeIn){ 
        sortArr(array, sizeIn); //Sort the array 
        prntArr(array, sizeIn); //Print the array 
    } 
    else { 
        (sizeDet<sizeIn)? 
            cout<<"Input size less than specified."<<endl: 
            cout<<"Input size greater than specified."<<endl;
    } 
    
    //Exit
    return 0;
} 

//Function Definition for Reading Array 
int readArr(char arrRead[ ]) { 
    //Read in character array 
    for (int i=0; i<20; i++) { 
        cin>>arrRead[i]; 
    } 
    //Determine array size 
    int arrSze=strlen(arrRead); 
    //Return array size to function main 
    return arrSze; 
}  

//Function Definition for Selection Sort 
void sortArr(char arrSort[ ], int sortSze) { 
    //Declare subscript and min. variables 
    int sub, min; 
    //Create for Loop to sort the array 
    for (int j=0; j<(sortSze-1); j++) { 
        //Initialize subscript and min. variables 
        sub=j, min=arrSort[j]; 
        //Create for Loop to compare array elements 
        for (int k=1; k<sortSze; k++) { 
            //Compare and swap array elements 
            if (arrSort[k]<min) { 
                //Update subscript and min. values 
                min=arrSort[k]; 
                sub=k; 
                //Declare and initialize swap variables 
                int temp=min, //temp placeholder to swap values 
                    a=arrSort[j], //old first value to be second 
                    b=arrSort[k]; //old second value to be first 
                //Complete swap of array elements 
                temp=a; 
                a=b; 
                b=temp; 
            } 
        } 
    }  
} 

//Function Definition for Array Output 
void prntArr(const char arrPrnt[ ], int prntSze) { 
   //Print out character array 
    for (int prnt=prntSze-1; prnt>=0; prnt--) { 
        cout<<arrPrnt[prnt]; 
    } 
    cout<<endl; 
} 



