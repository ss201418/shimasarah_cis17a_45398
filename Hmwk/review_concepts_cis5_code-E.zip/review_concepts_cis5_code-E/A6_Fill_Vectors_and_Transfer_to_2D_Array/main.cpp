/* 
 * File:   main.cpp 
 * Author: Sarah Shima 
 * Created on June 28, 2021, 5:00 PM 
 * Purpose:  Even, Odd Vectors and Array Columns Even, Odd 
 * Note:  Check out content of Sample conditions in Hacker Rank 
 * Input size of integer array, then array, output columns of Even, Odd 
 * Vectors then Even, Odd 2-D Array 
 */

//System Libraries Here 
#include <iostream>//cin,cout 
#include <vector>  //vectors<> 
#include <iomanip> //Format setw(),right 
using namespace std; 

//User Libraries Here 

//Global Constants Only, No Global Variables 
//Allowed like PI, e, Gravity, conversions, array dimensions necessary 
const int COLMAX=2;//Only 2 columns needed, even and odd 

//Function Prototypes Here 
void readVal(vector<int> &, vector<int> &); 
void copyArr(vector<int>, vector<int>,int [][COLMAX]); 
void prntVec(vector<int>, vector<int>,int);//int n is the format setw(n) 
void prntArr(const int [][COLMAX],int,int,int); 

//Program Execution Begins Here 
int main(int argc, char** argv) { 
    //Declare all Variables Here 
    const int ROW=80;            //No more than 80 rows 
    int array[ROW][COLMAX];      //Really, just an 80x2 array, even vs. odd 
    vector<int> even(0), odd(0); //Declare even,odd vectors 
    
    //Input data and place even in one vector odd in the other 
    readVal(even,odd); 
    
    //Now output the content of the vectors, setw(10) 
    prntVec(even,odd,10);//Input even, odd vectors with setw(10); 
    
    //Copy the vectors into the 2 dimensional array 
    copyArr(even,odd,array); 
    
    //Now output the content of the array, setw(10) 
    prntArr(array,even.size(),odd.size(),10);//Same format as even/odd vectors 
    
    //Exit 
    return 0; 
} 

void readVal(vector<int> &evnVals, vector<int> &oddVals){ 
    //Declare and initialize variables 
    int value, max; 
    //Output prompt for input values 
    cout<<"Input the number of integers to input."<<endl; 
    cout<<"Input each number."<<endl; 
    //Get number of integers to input 
    cin>>max; 
    //Get values for even and odd vectors 
    for (int i=0; i<=max; i++) { 
        cin>>value; 
        (value%2==0)? 
            evnVals.push_back(value): 
            oddVals.push_back(value); 
    } 
} 


void copyArr(vector<int> evnCopy, vector<int> oddCopy,int arrCopy[][COLMAX]){ 
    //Declare and initialize variables 
    int str1, str2; 
    //Count number rows 
    for (int row=0; row<80; row++) { 
        //Count number columns 
        for (int col=0; col<COLMAX; col++) { 
            //Copy vector values into 2D array 
            col==0 ? arrCopy[row][col]=evnCopy[row]: //even in left column 
                     arrCopy[row][col]=oddCopy[row]; //odd in right column 
        } 
    } 
} 


void prntVec(vector<int> evnPrnt, vector<int> oddPrnt,int wdthVal) { 
    //Declare and initialize max rows to print  
    int rows, evnRows, oddRows; 
    evnRows=evnPrnt.size(); 
    oddRows=oddPrnt.size(); 
    evnRows>oddRows ? //minus 1 to leave out null terminator 
        rows=evnRows-1: 
        rows=oddRows-1; 
    //Print out headings for table 
    cout<<setw(wdthVal)<<right<<"Vector"; 
    cout<<setw(wdthVal)<<right<<"Even"; 
    cout<<setw(wdthVal)<<right<<"Odd"<<endl; 
    //Print out values of table 
    for (int j=0; j<rows; j++) { 
        //Print out spacing before values 
        cout<<setw(wdthVal)<<right<<" "; 
        //Print out vector values 
        if (evnPrnt[j]==33) { 
            cout<<setw(wdthVal)<<right<<" ";
            cout<<setw(wdthVal)<<right<<oddPrnt[j]; 
        } 
        else if (oddPrnt[j]==33) { 
            cout<<setw(wdthVal)<<right<<evnPrnt[j];
            cout<<setw(wdthVal)<<right<<" ";
        } 
        else { 
            cout<<setw(wdthVal)<<right<<evnPrnt[j]; 
            cout<<setw(wdthVal)<<right<<oddPrnt[j]; 
        } 
        //Start a new line for each row 
        cout<<endl; 
    } 
} 


void prntArr(const int arrPrnt[][COLMAX],int evnRows,int oddRows,int wdthVal) { 
    //Declare and initialize max rows to print 
    int rows; 
    evnRows>oddRows ? //minus 1 to leave out null terminator 
        rows=evnRows-1: 
        rows=oddRows-1; 
    //Print out headings for table 
    cout<<setw(wdthVal)<<right<<"Array"; 
    cout<<setw(wdthVal)<<right<<"Even"; 
    cout<<setw(wdthVal)<<right<<"Odd"<<endl; 
    //Count rows of table 
    for (int row=0; row<rows; row++) { 
        //Print out spacing before values 
        cout<<setw(wdthVal)<<" ";
        //Count columns of table 
        for (int col=0; col<COLMAX; col++) { 
            //Print out spacing between values 
            cout<<setw(wdthVal)<<right; 
            //Print out array values 
            arrPrnt[row][col]==33 ? 
                cout<<" ": 
                cout<<arrPrnt[row][col]; 
        } 
        //Print out endl for next row 
        cout<<endl; 
    } 
} 


