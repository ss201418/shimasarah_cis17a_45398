/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 04, 2021, 3:10 PM
 */

//Libraries
#include <cstdlib>//Random number seed
#include <iostream>//I/O Library
#include <cmath>   //Math Library
using namespace std;

//No Global Constants

//Function Prototypes 
int *getData(int &);      //Return the array size and the array 
float *median(int *,int); //Fill medArr with float, med, and int data  
void prntMed(float *);    //Print the median Array 
void prntDat(int *,int);  //Print the integer array 

//Execution begins here 
int main(int argc, char*argv[]) { 
    //Declare and initialize variables 
    int arrSze, *intArr=new int[arrSze]; 
    float medVal, *medArr=new float[arrSze+2]; 

    //Read in values and get size of array 
    arrSze=*getData(&intArr); 
    
    //Find median value and create median array 
    medVal=*median(*intArr,arrSze); 
    
    //Print out integer array size 
    cout<<size<<" "; 
    
    //Print out median array data 
    prntMed(*medArr); 
    
    //Print out integer array data 
    prntDat(*intArr);  
	
	return 0; 
} 

int *getData(int &intData) { 
    //Declare and initialize variables 
    int arrSze=0, i=0; 
    //Read in size of the array 
    cin>>arrSze; 
    //Read in dynamic array values 
    while(cin>>*(array+i)) { 
        //Increment to find array size  
        arrSze++; 
        //Increment subscript variable 
        i++; 
    } 
    //Return array size 
    return arrSze; 
} 

float *median(int *array,int size) { 
    //Declare and initialize variables 
    int outer, medSub; 
    float medVal; 
    //Find number of values around median 
    outer=size/2; 
    //Find median for odd number of values 
    if (size%2!=0) { 
        medSub=size-outer; 
        medVal=array[medSub]; 
    } 
    //Find median for even number of values 
    else if (size%2==0) { 
        medVal=(size-outer)+0.5; 
    } 
    //
    
    //Create float array with median value 
    
    //Return medium value 
    return medVal; 
} 

void prntMed(float *prntMed) { 
    
} 

void prntDat(int *prntArr,int size) { 
    //Print out array values 
    for(int i=0;i<size;i++) { 
        cout<<*(prntArr+i)<<" "; 
    } 
} 
