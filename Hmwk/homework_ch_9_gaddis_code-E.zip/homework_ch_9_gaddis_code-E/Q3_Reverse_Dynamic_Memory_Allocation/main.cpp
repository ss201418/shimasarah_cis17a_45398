/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 04, 2021, 3:20 PM
 */

//Libraries
#include <cstdlib>//Random number seed
#include <iostream>//I/O Library
#include <cmath>   //Math Library
using namespace std;

//No Global Constants

//Function Prototypes 
int *getData(int &);           //Fill the array
int *sort(const int *,int)     //Sort smallest to largest
int *reverse(const int *,int); //Sort in reverse order
void prntDat(const int *,int); //Print the array

//Execution begins here 
int main() { 
    //Declare and initialize variables 
	int arrSze, *array=new int[arrSze]; 
	//Read in array data and get size of the array 
	arrSze=*getData(&array); 
    //Sort the array from smallest to largest  
    *sort(*array,arrSze); 
    //Sort the array in reverse order   
    *reverse(*array,arrSze); 
    //Print out the values of the array 
    prntDat(*array,arrSze); 
    //Exit function 
	return 0;
} 

int *getData(int &arrData) { 
    //Declare array size variable 
    int arrSze, i=0; 
    //Read in dynamic array values 
    while(cin>>*(array+i)) { 
        //Increment to find array size  
        arrSze++; 
        //Increment subscript variable 
        i++; 
    } 
    //Return array size 
    return arrSze; 
} 

int *sort(const int *a,int n) { 
    bool swap;
    do{
        swap=false;
        for(int i=0;i<n-1;i++){     //Loop to swap with first in List
            if(a[i]>a[i+1]){        //Put the smallest at top of List
                a[i]=a[i]^a[i+1];   //In place Swap
                a[i+1]=a[i]^a[i+1]; //In place Swap
                a[i]=a[i]^a[i+1];   //In place Swap
                swap=true;
            }
        }
    } while(swap);
} 

int *reverse(const int *a,int n) { 
    bool swap;
    do{
        swap=false;
        for(int i=0,j=size;i<n-1;i++,j--){ //Loop to swap with last in List
            if(a[j]>a[j+1]){        //Put the smallest at top of List
                a[j]=a[j]^a[j+1];   //In place Swap
                a[j+1]=a[j]^a[j+1]; //In place Swap
                a[j]=a[j]^a[j+1];   //In place Swap
                swap=true;
            }
        }
    } while(swap); 
} 

void prntDat(const int *,int) { 
    //Print out array values 
    for(int i=0;i<size;i++) { 
        cout<<*(prntArr+i)<<" "; 
    } 
} 
