/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 04, 2021, 3:00 PM
 */

//Libraries
#include <cstdlib>//Random number seed
#include <iostream>//I/O Library
#include <cmath>   //Math Library
using namespace std;

//No Global Constants

//Function Prototypes
int *fillAry(int,int);           //Fill array
void prntAry(int *,int,int); //Print array
void shuffle(int *,int,int);  //Shuffle array
int *mode(const int *,int); //Find mode set 
void prntMod(int *);          //Print mode set 
void GR(unsigned int&);    //Gen Random Number
unsigned int GRB();          //Gen Random Bit
int *copy(const int *,int);  //Copy array
void mrkSort(int *,int);     //Mark Sort
void minPos(int *,int,int); //Find min position 
void swap(int *,int *);       //Swap

//START OF FUNCTION MAIN 

//Execution begins here
int main(int argc, char*argv[]) {
    //Declare variables and fill
    int arySize,//The array/set size
         modNum,//Unique numbers in the array
           *ary;//Pointer to the array
    
    //Step 1: Input num unique values and array size 
    cout<<"The program finds the mode of a set"<<endl;
    cout<<"Input the size of the array and ";
    cout<<"quantity of unique numbers"<<endl;
    cin>>arySize>>modNum;
    ary=fillAry(arySize,modNum);
    
    //Step 2: Print the initial array
    cout<<"The Array before shuffling"<<endl;
    prntAry(ary,arySize,modNum);
    
    //Step 3: Shuffle array 7 times
    shuffle(ary,arySize,7);
    
    //Step 4: Calculate mode array
    int *modeAry=mode(ary,arySize);
    
    //Step 5: Print initial array
    cout<<"The Array after shuffling"<<endl;
    prntAry(ary,arySize,modNum);
    
    //Step 6: Print modal info of array
    cout<<"The Modal Information"<<endl;
    prntMod(modeAry);
    
    //Step 7: Delete allocated memory
    delete []ary;
    delete []modeAry;
    
    //Exit stage right
    return 0;
}

//START OF ADDITIONAL FUNCTIONS 

//FUNCTION CALLS from main 

//First call from main 
int *fillAry(int n, int modNum){
    //Allocate memory
    int *array=new int[n];
    
    //Fill the array with 2 digit numbers
    for(int i=0;i<n;i++){
        *(array+i)=i%modNum;
        //*(array+i)=rand()%modNum;
    }
    
    //Exit function
    return array;
} 

//Second and fifth calls from main
void prntAry(int *array,int n,int perLine){
    //Output the array
    for(int i=0;i<n;i++){
        cout<<*(array+i)<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

//Third call from main
void shuffle(int *a,int n,int nShuf){
    unsigned int temp;
    for(int shuf=1;shuf<=nShuf;shuf++){
        for(int i=0;i<n;i++){
            GR(temp);
            temp%=n;
            if(i!=temp)swap(a[i],a[temp]);
        }
    }
}

//Fourth call from main
int *mode(const int *array,int arySize){ 
    //Declare and initialize count variables 
    int count=1, maxFreq=1, nModes=0; 
    //Copy the array
    int *ary=copy(array,arySize); 
    //Sort the copy
    mrkSort(ary,arySize); 
    //Find max frequency 
    for (int i=0; i<arySize; i++) { 
        //Begin comparison after first element 
        if (i>0) { 
            //Update counter if values match 
            (ary[i]==ary[i-1]) ? 
                count++: count; 
            //Update max frequency 
            (count>maxFreq) ? 
                maxFreq=count: maxFreq; 
            //Reset counter for new matches 
            (ary[i]!=ary[i-1]) ? 
                count=1: count; 
        } 
    } 
    //Reset counter at end of array 
    count=1; 
    //Find number of modes 
    for (int i=0; i<arySize; i++) { 
        //Begin comparison after first element 
        if (i>0) { 
            //Update counter if values match 
            (ary[i]==ary[i-1]) ? 
                count++: count;
            //Reset counter for new matches 
            (ary[i]!=ary[i-1]) ? 
                count=1: count; 
            //Update number of modes 
            (count==maxFreq) ? 
                nModes++: nModes; 
        } 
    } 
    //Reset counter at end of array 
    count=1; 
    //Allocate mode array 
    int *modeAry=new int[nModes+2]; 
    //Read in max freq. and number of modes 
    modeAry[0]=nModes;
    modeAry[1]=maxFreq; 
    //Fill mode array 
    for (int i=0, j=2; i<arySize; i++) { 
        //Begin comparison after first element 
        if (i>0) { 
            //Update counter if values match 
            (ary[i]==ary[i-1]) ? 
                count++: count; 
            //Reset counter 
            (ary[i]!=ary[i-1]) ? 
                count=1: count; 
            //Read in values for mode array 
            (count==maxFreq) ?  
                modeAry[j]=ary[i], j++: modeAry[j]; 
        } 
    } 
    //Reset counter at end of array 
    count=1; 
    //Delete the allocated copy and return
    delete []ary;
    return modeAry;
} 

//Fifth call from main, back to prntAry 

//Sixth call from main
void prntMod(int *ary){
    cout<<"The number of modes = "<<
            ary[0]<<endl;
    cout<<"The max Frequency = "<<
            ary[1]<<endl;
    if(ary[0]==0){
        cout<<"The mode set = {null}"<<endl;
        return;
    }
    cout<<"The mode set = {";
    for(int i=2;i<ary[0]+1;i++){
        cout<<ary[i]<<",";
    }
    cout<<ary[ary[0]+1]<<"}"<<endl;
}

//FUNCTION CALLS from Addt'l Functions 

//Function call from shuffle 
void GR(unsigned int& value){ 
    //Declare and initialize all values 
    const unsigned int numBits = sizeof(int) * 8;
    unsigned int *dataPntr = (unsigned int *)&value, 
                 indx, pntrIndx, mask; 
    //Initialize temporary variable 
    value=0; 
    //Use a for Loop to count index values 
    for (indx = 0; indx < numBits; ++indx) { 
        if(GRB()) { 
            pntrIndx = indx / 32;
            mask = 1 << indx % 32;
            dataPntr[pntrIndx] |= mask;
        } 
    } 
} 

//Function call from GR 
unsigned int GRB(){
    static unsigned int seed=0;
    seed += (seed * seed) | 5;
    return seed & 0x80000000;
}

//Function call from mode, first of two 
int *copy(const int *a,int n){
    //Declare and allocate an array
    int *b=new int[n];
    //Fill with passed array
    for(int i=0;i<n;i++){
        b[i]=a[i];
    }
    //Return the copy
    return b;
}

//Function call from mode, sec. of two 
void mrkSort(int *array,int n){
    for(int i=0;i<n-1;i++){
        minPos(array,n,i);
    }
}

//Function call from mrkSort 
void minPos(int *array,int n,int pos){
    for(int i=pos+1;i<n;i++){
        if(*(array+pos)>*(array+i))
            swap(array+pos,array+i);
    }
}

//Function calls from shuffle and minPos 
void swap(int *a,int *b){
    //Swap in place
    *a=*a^*b;
    *b=*a^*b;
    *a=*a^*b;
}
