/* 
 * File: main.cpp
 * Author: Sarah Shima 
 * Created on July 26, 2021, 3:50 PM
 * Purpose: Essay Class Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
#include "Essay.h" 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare and initialize all variables 
    int g=0,s=0,l=0,c=0,ttl=0, 
         maxG=30, maxS=20, maxL=20, 
         maxC=30, maxTtl=100; 
    Essay grade; 
    //Get input for individual categories 
    cout<<"Enter essay scores for the following categories "; 
    cout<<"up to the listed max scores: "<<endl; 
    cout<<"Grammar(30), Spelling(20), Correct Length(20) "; 
    cout<<"Content(30)."<<endl; 
    cin>>g>>s>>l>>c; 
    //Store values in Essay class object 
    grade.setGram(g); 
    grade.setSpll(s); 
    grade.setLgth(l); 
    grade.setCnt(c); 
    //Display values for essay letter grade and scores 
    cout<<"Here is the letter grade and score breakdown: "<<endl; 
    char ltrGrde=grade.getLtrs(); 
    cout<<"Letter Grade = "<<ltrGrde<<endl; 
    float score=grade.getScor(); 
    cout<<"Final Score = "<<score<<endl; 
    cout<<"Grammar = "<<grade.getGram()<<"/"<<maxG<<endl; 
    cout<<"Spelling = "<<grade.getSpll()<<"/"<<maxS<<endl; 
    cout<<"Correct Length = "<<grade.getLgth()<<"/"<<maxL<<endl; 
    cout<<"Content = "<<grade.getCnt()<<"/"<<maxC<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}