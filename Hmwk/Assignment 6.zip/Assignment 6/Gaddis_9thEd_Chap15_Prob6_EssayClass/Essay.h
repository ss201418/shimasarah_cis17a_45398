/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Essay.h 
 * Author: Sarah Shima 
 * Created on July 26, 2021, 3:50 PM
 * Purpose: Essay Class Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
#include "GrdActv.h" 
using namespace std;

#ifndef ESSAY_H
#define ESSAY_H
//Class Declarations 
class Essay : public GrdActv { 
    private: 
        int gram,spell,len,cntnt; 
    public: 
        Essay() //default constructor 
            { gram=0, spell=0, len=0, cntnt=0; } 
        void setGram(int g) 
            { gram=g, score+=g; } 
        void setSpll(int s) 
            { spell=s, score+=s; } 
        void setLgth(int l) 
            { len=l, score+=l; } 
        void setCnt(int c) 
            { cntnt=c, score+=c; } 
        int getGram() const 
            { return gram; } 
        int getSpll() const 
            { return spell; } 
        int getLgth() const 
            { return len; } 
        int getCnt() const 
            { return cntnt; } 
}; 
#endif /* ESSAY_H */

