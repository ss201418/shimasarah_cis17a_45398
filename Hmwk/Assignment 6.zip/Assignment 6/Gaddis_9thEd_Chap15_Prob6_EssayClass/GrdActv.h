/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: GrdActv.h 
 * Author: Sarah Shima 
 * Created on July 26, 2021, 3:50 PM
 * Purpose: Essay Class Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std;

#ifndef GRADEACT_H
#define GRADEACT_H
//Class Declarations 
class GrdActv { 
protected: 
    float score; 
public: 
    GrdActv() //default constructor 
        { score=0.0; } 
    GrdActv(float s) //constructor #2 
        { score=s; } 
    void setScor(float s) 
        { score=s; } 
    float getScor() const 
        { return score; } 
    char getLtrs() const; 
}; 
//Class Member Functions 
char GrdActv::getLtrs() const { 
    char ltrGrde; 
    if (score>89) ltrGrde='A'; 
    else if (score>79) ltrGrde='B'; 
    else if (score>69) ltrGrde='C'; 
    else if (score>59) ltrGrde='D'; 
    else ltrGrde='F'; 
    return ltrGrde; 
} 
#endif /* GRADEACT_H */

