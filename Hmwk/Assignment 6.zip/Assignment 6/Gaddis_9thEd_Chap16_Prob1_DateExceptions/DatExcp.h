/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: DatExcp.h 
 * Author: Sarah Shima 
 * Created on July 25, 2021, 7:00 PM
 * Purpose: Date Exceptions Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std;

#ifndef DATEXCP_H
#define DATEXCP_H
//Class Declarations 
class DatExcp { 
    private: 
        string mnthNm; 
        int month; 
        int day; 
        int year; 
    public: 
        //Exception classes 
        class NoDay //invalid day 
            { }; 
        class NoMnth //invalid month 
            { }; 
        //Member functions 
        void setMnth(int m) { 
            if (m>=1 && m<=12) month=m; 
            else throw NoDay(); 
        } 
        void setDay(int d) { 
            if (d>=1 && d<=31) day=d; 
            else throw NoMnth(); 
        } 
        void setYear(int y) 
            { year=y; } 
        void prntDgt(int m,int d,int y) 
            { cout<<m<<"/"<<d<<"/"<<y<<endl; } 
        void prntUSA(string m, int d, int y)  
            { cout<<m<<" "<<d<<", "<<y<<endl; } 
        void prntEur(string m, int d, int y)  
            { cout<<d<<" "<<m<<" "<<y<<endl; } 
}; 
#endif /* DATEXCP_H */

