/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 25, 2021, 7:00 PM
 * Purpose: Date Exceptions Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
#include "DatExcp.h"  
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare all variables for this function
    DatExcp dsply; 
    int m=0,d=0,y=0; 
    string month; 
    bool badDay=true,badMnth=true; 
    //Get input for month value 
    cout<<"Input a month value between 1 and 12: "<<endl; 
    cin>>m; 
    //Validate month value with try and catch blocks 
    while (badMnth) { 
        try { 
            dsply.setMnth(m); 
            badMnth=false; //ends loop if no excpt. thrown 
        } 
        catch (DatExcp::NoMnth) { 
            cout<<"Error: Invalid month value given."<<endl; 
            cin>>m; 
        } 
    } 
    //Get input for day value 
    cout<<"Input a day value between 1 and 31: "<<endl; 
    cin>>d; 
    //Validate day value with try and catch blocks 
    while (badDay) { 
        try { 
            dsply.setDay(d); 
            badDay=false; //ends loop if no excpt. thrown 
        } 
        catch (DatExcp::NoDay) { 
            cout<<"Error: Invalid day value given."<<endl; 
            cin>>d; 
        } 
    } 
    //Get input for year 
    while (y<1900 || y>2021) { 
    cout<<"Input a four-digit year between"; 
    cout<<" 1900 and 2021: "<<endl; 
    cin>>y; 
    dsply.setYear(y); 
    } 
    //Determine month written format 
    if (m==1) month="January"; 
    else if (m==2) month="February"; 
    else if (m==3) month="March"; 
    else if (m==4) month="April"; 
    else if (m==5) month="May"; 
    else if (m==6) month="June"; 
    else if (m==7) month="July"; 
    else if (m==8) month="August"; 
    else if (m==9) month="September"; 
    else if (m==10) month="October"; 
    else if (m==11) month="November"; 
    else if (m==12) month="December"; 
    //Display the date in digital format 
    dsply.prntDgt(m,d,y); 
    //Display the date in US format 
    dsply.prntUSA(month,d,y); 
    //Display the date in European format 
    dsply.prntEur(month,d,y); 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}