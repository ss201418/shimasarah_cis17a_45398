/* 
 * File: main.cpp
 * Author: Sarah Shima 
 * Created on July 25, 2021, 9:00 PM
 * Purpose: Total Template Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library
#include <cctype>    //Char Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Template Definitions 
template <class T> 
T total (T max) { 
    T num, total; 
    for (int i=0; i<max; i++) { 
        cin>>num; 
        (i==0) ? 
            total=num: total+=num; 
    } 
    return total; 
} 

//Function Prototypes 

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare and initialize all variables 
    int max=0,nTtl=0; 
    float fltTtl=0.0; 
    string strTtl=""; 
    //Get input for max values to enter per test 
    cout<<"Enter the number of values to list "; 
    cout<<"for each template test: "<<endl; 
    cin>>max; 
    //Test total template with integer values 
    cout<<"Enter a list of integer values: "<<endl; 
    nTtl=total(max); 
    cout<<"Here is the total of those values: "; 
    cout<<nTtl<<endl<<endl; 
    //Test total template with float values 
    cout<<"Enter a list of float values: "<<endl; 
    fltTtl=total(max); 
    cout<<"Here is the total of those values: "; 
    cout<<setprecision(2)<<fixed; 
    cout<<fltTtl<<endl<<endl; 
    //Test total template with string values 
    cout<<"Enter a list of string values: "<<endl; 
    strTtl=total(max); 
    cout<<"Here is the total of those values: "; 
    cout<<strTtl<<endl<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}