/* 
 * File: main.cpp
 * Author: Sarah Shima 
 * Created on July 25, 2021, 7:45 PM
 * Purpose: Min Max Templates Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Template Definitions 
template <class T> 
T min(T &n1, T &n2) { 
    T temp; 
    (n1<n2) ? 
        temp=n1: 
        temp=n2; 
    return temp; 
} 
template <class T> 
T max(T &n1, T &n2) { 
    T temp; 
    (n1>n2) ? 
        temp=n1: 
        temp=n2; 
    return temp; 
} 

//Function Prototypes 

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare all variables for this function 
    int intMin1,intMin2,intMax1,intMax2; 
    float fltMin1,fltMin2,fltMax1,fltMax2; 
    string strMin1,strMin2,strMax1,strMax2; 
    //Get input values for integer data type 
    cout<<"Enter four integer values: "<<endl; 
    cin>>intMin1>>intMin2>>intMax1>>intMax2; 
    //Get input values for float data type 
    cout<<"Enter four float values: "<<endl; 
    cin>>fltMin1>>fltMin2>>fltMax1>>fltMax2; 
    //Get input values for string data type 
    cout<<"Enter four string values: "<<endl; 
    cin>>strMin1>>strMin2>>strMax1>>strMax2; 
    //Test minimum template with different data types 
    cout<<endl; 
    cout<<"Minimum Template Results: "<<endl; 
    cout<<"Minimum Integer: "<<min(intMin1,intMin2)<<endl; 
    cout<<"Minimum Float: "<<min(fltMin1,fltMin2)<<endl; 
    cout<<"Minimum String: "<<min(strMin1,strMin2)<<endl; 
    cout<<endl; 
    //Test maximum template with different data types 
    cout<<"Maximum Template Results: "<<endl; 
    cout<<"Maximum Integer: "<<max(intMax1,intMax2)<<endl; 
    cout<<"Maximum Float: "<<max(fltMax1,fltMax2)<<endl; 
    cout<<"Maximum String: "<<max(strMax1,strMax2)<<endl; 
    cout<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}