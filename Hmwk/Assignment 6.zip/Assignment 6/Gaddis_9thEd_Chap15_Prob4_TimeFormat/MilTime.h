/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: MilTime.h 
 * Author: Sarah Shima 
 * Created on June 22, 2021, 9:30 PM
 * Purpose: Time Format Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
#include "Time.h"     
using namespace std;

#ifndef MILTIME_H
#define MILTIME_H
//Class Declarations 
class MilTime : public Time { 
    private: 
        int milHrs, milSec; //military time 
    public: 
        MilTime(int mHrs, int mSec) { //default constructor 
            milHrs=mHrs; 
            milSec=mSec; 
            int temp; 
            (mHrs>=1300) ? 
                temp=mHrs-1200: 
                temp=mHrs; 
            hours=temp/100; 
            min=temp%100; 
            sec=mSec; 
        } 
        void setTime(int mHrs, int mSec) { 
            int temp; 
            (mHrs>=1300) ? 
                temp=mHrs-1200: 
                temp=mHrs; 
            hours=temp/100; 
            min=temp%100; 
            sec=mSec; 
        } 
        virtual int getHour() const //redefined function 
            { return milHrs; } 
        int getHStd() const 
            { return hours; } 
}; 
#endif /* MILTIME_H */

