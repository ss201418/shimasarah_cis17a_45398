/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Time.h 
 * Author: Sarah Shima 
 * Created on June 22, 2021, 9:30 PM
 * Purpose: Time Format Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std;

#ifndef TIME_H
#define TIME_H
//Class Declarations 
class Time { 
    protected: 
        int hours, min, sec; 
    public: 
        Time() //default constructor 
            { hours=0; min=0; sec=0; } 
        Time(int h, int m, int s) //constructor #2 
            { hours=h; min=m; sec=s; } 
        virtual int getHour() const 
            { return hours; } 
        int getMin() const 
            { return min; } 
        int getSec() const 
            { return sec; } 
}; 
#endif /* TIME_H */

