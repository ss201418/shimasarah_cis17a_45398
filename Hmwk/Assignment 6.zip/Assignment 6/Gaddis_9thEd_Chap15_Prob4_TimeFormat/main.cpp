/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on June 22, 2021, 9:30 PM
 * Purpose: Time Format Problem for Assignment 6 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
#include "MilTime.h"  
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants 

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {    
    //Declare and initialize all variables 
    int hrs=0, sec=0; 
    string dayTime=""; //AM/PM 
    //Get input for military time 
    cout<<"Enter a time in military format with "; 
    cout<<"seconds in standard format: "<<endl; 
    cin>>hrs>>sec; 
    //Determine whether time AM or PM 
    (hrs<1300) ? dayTime="AM": dayTime="PM"; 
    //Store the time in a MilTime object 
    MilTime mltry(hrs,sec); 
    //Display the Inputs/Outputs 
    cout<<"Here is the time in both military and "; 
    cout<<"standard format: "<<endl; 
    cout<<"Military: "<<mltry.getHour()<<","<<endl; 
    cout<<"Standard: "<<mltry.getHStd()<<":"; 
    cout<<setw(2)<<mltry.getMin()<<" "<<dayTime<<endl; 
    cout<<"Seconds: "<<mltry.getSec()<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
}