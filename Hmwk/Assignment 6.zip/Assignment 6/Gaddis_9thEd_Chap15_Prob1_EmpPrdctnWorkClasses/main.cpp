/* 
 * File: main.cpp
 * Author: Sarah Shima 
 * Created on June 22, 2021, 9:40 PM
 * Purpose: Employee and Production Problem for Assignment 6 
 */

//System Libraries 
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
#include "PrdWork.h" 
using namespace std; 

//User Libraries 

//Global Constants Only 
//Well known Science, Mathematical and Laboratory Constants 

//Function Prototypes 

//Execution of Code Begins Here 
int main(int argc, char** argv) { 
    //Declare and initialize all variables 
    string nm="", dtHire=""; 
    int num=0, nShift=0; 
    float rate=0.0; 
    PrdWork emp1; 
    //Store values in Emp class variables 
    cout<<"Enter employee's name, date hired, and "; 
    cout<<"work number."<<endl; 
    getline(cin,nm); 
    cin>>dtHire>>num; 
    emp1.setName(nm); 
    emp1.setDate(dtHire); 
    emp1.setNum(num); 
    //Store values in PrdWork class variables 
    cout<<"Enter the employee's shift type and pay rate "; 
    cout<<"(type 1 for day shift and 2 for night shift): "<<endl; 
    cin>>nShift>>rate; 
    emp1.setShft(nShift); 
    emp1.setRate(rate); 
    //Display employee ID and work information 
    cout<<"Here is the employee's recorded information: "<<endl; 
    cout<<"Name: "<<emp1.getName()<<endl; 
    cout<<"Date Hired: "<<emp1.getDate()<<endl; 
    cout<<"Work Number: "<<emp1.getNum()<<endl; 
    cout<<"Shift Type: "<<emp1.getShft()<<endl; 
    cout<<"Pay Rate: "<<setprecision(2)<<fixed; 
    cout<<"$"<<emp1.getRate()<<"/hour"<<endl; 
    //Clean up the code, close files, deallocate memory, etc.... 
    //Exit stage right 
    return 0; 
} 