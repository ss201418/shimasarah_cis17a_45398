/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: PrdWork.h 
 * Author: Sarah Shima 
 * Created on June 22, 2021, 9:40 PM
 * Purpose: Employee and Production Problem for Assignment 6 
 */

//System Libraries 
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
#include "Emp.h"    
using namespace std; 

#ifndef PRDWORK_H
#define PRDWORK_H
//Class Declarations 
class PrdWork : public Emp { 
    private: 
        int shift; //day=1, night=2 
        float payRate; 
    public: 
        PrdWork() //default constructor 
            { shift=0, payRate=0; } 
        void setShft(int n) 
            { shift=n; } 
        void setRate(float r) 
            { payRate=r; } 
        int getShft() 
            { return shift; } 
        float getRate() 
            { return payRate; } 
}; 
#endif /* PRDWORK_H */

