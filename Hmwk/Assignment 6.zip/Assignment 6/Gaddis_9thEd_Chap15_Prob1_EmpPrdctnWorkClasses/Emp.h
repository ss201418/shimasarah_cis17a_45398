/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Emp.h 
 * Author: Sarah Shima 
 * Created on June 22, 2021, 9:40 PM
 * Purpose: Employee and Production Problem for Assignment 6 
 */

//System Libraries 
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
#include <cctype>    //Char Library 
using namespace std; 

#ifndef EMP_H
#define EMP_H
//Class Declarations 
class Emp { 
    protected: 
        string name; 
        string hireDt; 
        int number; 
    public: 
        Emp() //default constructor 
            { name="", hireDt="", number=0; } 
        void setName(string s) 
            { name=s;} 
        void setDate(string d) 
            { hireDt=d; } 
        void setNum(int n) 
            { number=n; } 
        string getName() 
            { return name; } 
        string getDate() 
            { return hireDt; } 
        int getNum() 
            { return number; } 
}; 
#endif /* EMP_H */

