/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 13, 2021, 8:30 PM 
 * Purpose:  Midterm Problem 1 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library 
#include <cstdlib>    //Standard Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 
struct CkgAcct { 
    string Name, 
              Address; 
    int acctNum; 
    float begAmt, 
            ttlCks, 
            ttlDep; 
}; 

//Function Prototypes 
void getInfo(CkgAcct *,float,float); 

//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare all variables 
    CkgAcct *acct=nullptr; //ptr for ckg acct struct 
    int size; //size of ptr for dynamic struct 
    float tmpCks,   //temp check value 
            tmpDeps, //temp deposit value 
            endAmt;   //ending balance for acct 
    
    //Initialize ptr for dynamic struct 
    size=sizeof(tmpCks)*20; 
    acct=new CkgAcct[size]; 
    
    //Input info for checking acct struct 
    getInfo(acct,tmpCks,tmpDeps); 
    
    //Display info for ckg acct struct 
    cout<<"Checking Account Information"<<endl; 
    cout<<"Account Holder: "<<acct->Name<<endl; 
    cout<<"Address: "<<acct->Address<<endl; 
    cout<<"Beginning Balance: $"; 
    cout<<setprecision(2)<<fixed<<acct->begAmt<<endl; 
    cout<<"Total of all Checks Written for the Month: $"; 
    cout<<setprecision(2)<<fixed<<acct->ttlCks<<endl; 
    cout<<"Total of all Deposits Made for the Month: $"; 
    cout<<setprecision(2)<<fixed<<acct->ttlDep<<endl; 
       
    //Calculate and display new balance 
    endAmt=acct->begAmt+acct->ttlDep-acct->ttlCks; 
    cout<<"Your new balance is $"; 
    cout<<setprecision(2)<<fixed<<endAmt<<endl; 
    
    //Debit $20 if acct overdrawn 
    if (endAmt<0) { 
        //Display output for overdraft fee 
        cout<<"Your account is overdrawn."<<endl; 
        cout<<"An overdraft fee of $20 has been"; 
        cout<<"  charged to your account."<<endl; 
        //Charge $20 to checking account 
        endAmt-=20.00; 
        //Display acct balance after fee 
        cout<<"Your updated account balance is $"; 
        cout<<setprecision(2)<<fixed<<endAmt<<endl; 
    } 
    
    //Erase dynamically allocated memory 
    delete [] acct; 
    acct=nullptr; 
    
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
} 

//Function Implementations 

//Function for getting input for ckg acct info 
void getInfo(CkgAcct *person, float cks, float deps) { 
    //Declare and initialize variables 
    string acctID; 
    char option; 
    //Display output for checking acct info input 
    cout<<"Checking Account Information"<<endl; 
    //Get input for account holder name 
    cout<<"Enter name of account holder: "<<endl; 
    getline(cin,person->Name); 
    //Get input for account holder address 
    cout<<"Enter an address: "<<endl; 
    getline(cin,person->Address); 
    //Get acct number with 5-digit input validation 
    while (acctID.length()!=5) { 
    cout<<"Enter a checking account number that"; 
    cout<<" is five digits long: "<<endl; 
    cin>>acctID; 
    } 
    person->acctNum=stoi(acctID); 
    //Get input for beginning balance for the month 
    cout<<"Enter beginning balance for the month: "<<endl; 
    cin>>person->begAmt; 
    //Get input for checks written and calculate sum 
    do { 
    cout<<"Enter values of any checks written"; 
    cout<<" for the month: "<<endl; 
    cin>>cks; 
    person->ttlCks+=cks; 
    cout<<"Enter another value? Type 'Y' for yes or "; 
    cout<<" 'N' for no: "<<endl; 
    cin>>option; 
    } while (toupper(option)=='Y'); 
    //Get input for deposits to acct and calculate sum 
    do { 
    cout<<"Enter values of any deposits made"; 
    cout<<" for the month: "<<endl; 
    cin>>deps; 
    person->ttlDep+=deps; 
    cout<<"Enter another value? Type 'Y' for yes or "; 
    cout<<" 'N' for no: "<<endl; 
    cin>>option; 
    } while (toupper(option)=='Y'); 
} 
