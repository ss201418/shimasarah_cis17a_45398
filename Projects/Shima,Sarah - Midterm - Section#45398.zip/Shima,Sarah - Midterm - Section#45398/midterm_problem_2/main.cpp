/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 14, 2021 at 9:30 AM 
 * Purpose:  Midterm Problem 2 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 
struct EmpPay { 
    string name; //employee name 
    int hrs; //number of hours worked in a week 
    float rate; //normal pay rate 
}; 

//Function Prototypes 
void getInfo(EmpPay *,float &,int); 
void display(EmpPay *,float &,int); 
void toEngN(float &); 

//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare all variables for this function 
    EmpPay *emp=nullptr; //emp pay struct array 
    float grsPay;  //gross paycheck amount 
    int i=0; //struct array subscript counter 
    char option; //'Y' or 'N' input for struct array 
    
    //Initialize all known variables 
    emp=new EmpPay[150]; 
    
    //Use do-while Loop for emp info input 
    do { 
        //Get input for emp info struct array 
        getInfo(emp,grsPay,i); 
        
        //Display employee gross paycheck  
        display(emp,grsPay,i); 

        //Get input for next Loop iteration 
        cout<<"Would you like to calculate the gross"; 
        cout<<" pay for another employee? Type 'Y'"; 
        cout<<" for yes or 'N' for no."<<endl; 
        cin>>option; 
        
        //Update subscript counter 
        i++; 

    //End of do-while Loop 
    } while (toupper(option)=='Y'); 
    
    //Delete dynamically allocated memory 
    delete [] emp; 
    emp=nullptr; 

    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
} 

//Function Prototypes 

//Function to get info for emp pay struct array 
void getInfo(EmpPay *emp,float &grsPay,int i) { 
    //Declare and initialize variables 
    float nrmPay=0, //normal pay amount 
            dblPay=0,  //double pay amount 
            tplPay=0;   //triple pay amount 
    //Get input for employee name 
    cout<<"Enter employee name: "<<endl; 
    getline(cin,emp[i].name); 
    //Get input for hours worked 
    cout<<"Enter number of hours worked: "<<endl; 
    cin>>emp[i].hrs; 
    //Get input for normal pay rate 
    cout<<"Enter the normal pay rate: "<<endl; 
    cin>>emp[i].rate; 
    //Calculate normal pay amount 
    (emp[i].hrs<=40) ? 
        nrmPay=emp[i].hrs*emp[i].rate: 
        nrmPay=40*emp[i].rate; 
    //Calculate double pay amount 
    if (emp[i].hrs>40) { 
        dblPay=(emp[i].hrs-40)*emp[i].rate*2; 
    } 
    //Calculate triple pay amount 
    if (emp[i].hrs>50) { 
        tplPay=(emp[i].hrs-50)*emp[i].rate*3; 
    } 
    //Calculate gross pay amount 
    grsPay=nrmPay+dblPay+tplPay; 
} 

//Function to display employee gross pay check  
void display(EmpPay *emp,float &grsPay,int i) { 
    //Print company name on first line 
    cout<<"Company A"<<endl; 
    //Print company address on second line 
    cout<<"12345 Smith St."<<endl; 
    //Print emp name and payck amt on third line 
    cout<<"Name: "<<setw(15)<<left<<emp->name; 
    //Print English of payck amt on fourth line 
    cout<<"Amount: "; 
    toEngN(grsPay); 
    //Print signature line on fifth and last line 
    cout<<"Signature Line: "<<endl; 
    
} 

//Function to convert payck amt to English 
void toEngN(float &payck) { 
    //Declare and initialize variables 
    int dlrs,n1000s,n100s,n10s,n1s,cents; 
    //Determine values for each digit place 
    dlrs=payck;                    //Get whole nums value 
    n1000s=dlrs/1000;           //Get thsnds digit value 
    n100s=dlrs%1000/100;     //Get hndrds digit value 
    n10s=dlrs%100/10;           //Get tens digit value 
    n1s=dlrs%10;                   //Get ones digit value 
    cents=(payck-dlrs)*100; //Get cents value 
        
    //Output the number of 1000's 
    switch(n1000s){ 
        case 3:cout<<"Three Thousand "; 
        case 2:cout<<"Two Thousand "; 
        case 1:cout<<"One Thousand "; 
    } 

    //Output the number of 100's 
    cout<<(n100s==9?"Nine Hundred ": 
           n100s==8?"Eight Hundred ": 
           n100s==7?"Seven Hundred ": 
           n100s==6?"Six Hundred ": 
           n100s==5?"Five Hundred ": 
           n100s==4?"Four Hundred ": 
           n100s==3?"Three Hundred ": 
           n100s==2?"Two Hundred ": 
           n100s==1?"One Hundred ":""); 

    //Output the number of 10's 
    if(n10s==9) cout<<"Ninety "; 
    if(n10s==8)cout<<"Eighty "; 
    if(n10s==7)cout<<"Seventy "; 
    if(n10s==6)cout<<"Sixty "; 
    if(n10s==5)cout<<"Fifty "; 
    if(n10s==4)cout<<"Forty "; 
    if(n10s==3)cout<<"Thirty "; 
    if(n10s==2) { 
        if(n1s>0) cout<<"Twenty "; 
        if(n1s==0) cout<<"Twelve "; 
    } 
    if(n10s==1) { 
        if(n1s>0) cout<<""; 
        if(n1s==0) cout<<"Ten "; 
    } 

    //Output the number of 1's 
    if(n1s==9) { 
        (n10s==1) ? 
            cout<<"Nineteen": 
            cout<<"Nine "; 
    } 
    if(n1s==8) { 
        (n10s==1) ? 
            cout<<"Eighteen": 
            cout<<"Eight "; 
    } 
    if(n1s==7) { 
        (n10s==1) ? 
            cout<<"Seventeen": 
            cout<<"Seven "; 
    } 
    if(n1s==6) { 
        (n10s==1) ? 
            cout<<"Sixteen": 
            cout<<"Six"; 
    } 
    if(n1s==5) { 
        (n10s==1) ? 
            cout<<"Fifteen ": 
            cout<<"Five "; 
    } 
    if(n1s==4) { 
        (n10s==1) ? 
            cout<<"Fourteen ": 
            cout<<"Four "; 
    } 
    if(n1s==3) { 
        (n10s==1) ? 
            cout<<"Thirteen ": 
            cout<<"Three "; 
    } 
    if(n1s==2)cout<<"Two "; 
    if(n1s==1)cout<<"One "; 
    
    //Print out cents value and new line 
    cout<<"Dollars and "<<cents<<"/100"<<endl; 
} 
