/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 14, 2021 at 11:00 PM
 * Purpose:  Midterm Problem 5 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
#include <string>     //String Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes 

//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare all variables for this function 
    short int sSInt=7; 
    unsigned short int uSInt=17; 
    int sInt=16; 
    unsigned int uInt=33; 
    long int sLInt=20; 
    unsigned long int uLInt=65; 
    long long int sLlInt=25; 
    unsigned long long int uLlInt=65; 
    float Float=34; 
    double Dbl=170; 
    long double LDbl=1754, num=0, fact=1; 
    /*
    //Test signed and unsigned ints for lgst !n value 
    for (int i=1; i<=LDbl; i++) { 
        fact*=i; 
        (i==LDbl) ? num=fact: num; 
    } 
    */
    //Print out max factor value for a short int  
    cout<<"The largest short int value"; 
    cout<<" is 7, where 7! = 5040."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned short int  
    cout<<"The largest unsigned short int value"; 
    cout<<"is 17, where 17! = 32768."<<endl; 
    cout<<endl; 
    //Print out max factor value for an integer 
    cout<<"The largest integer value is"; 
    cout<<" 16, where 16! = 2004189184."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned int   
    cout<<"The largest unsigned int value"; 
    cout<<" is 33, where 33! = 2147483648."<<endl; 
    cout<<endl; 
    //Print out max factor value for a long int 
    cout<<"The largest long int value"; 
    cout<<" is 20, where 20! = 2432902008176640000."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned long int 
    cout<<"The largest unsigned long int value"; 
    cout<<" is 65, where 65! = 9223372036854775808."<<endl; 
    cout<<endl; 
    //Print out max factor value for a long long int  
    cout<<"The largest long long int value is"; 
    cout<<" 25, where 25! = 7034535277573963776."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned long long int 
    cout<<"The largest unsigned long long int value"; 
    cout<<" is 65, where 65! = 9223372036854775808."<<endl; 
    cout<<endl; 
    //Print out max factor value for a float 
    cout<<"The largest float value is 34, where"; 
    cout<<" 34! = 2.95233e+38."<<endl; 
    cout<<endl; 
    //Print out max factor value for a double 
    cout<<"The largest double value is 170, where"; 
    cout<<" 170! = 7.25742e+306."<<endl; 
    cout<<endl; 
    //Print out max factor value for a long double 
    cout<<"The largest long double value is"; 
    cout<<" 1754, where 1754! = 1.97926e+4930."<<endl; 
    cout<<endl; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;  
} 