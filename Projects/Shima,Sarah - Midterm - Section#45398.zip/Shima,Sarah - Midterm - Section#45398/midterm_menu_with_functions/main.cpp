/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 13, 2021 at 9:00 PM 
 * Purpose:  Solutions Menu using Functions 
 *                 for Midterm Problems 
 */

//System Libraries
#include <iostream> //I/O Library
#include <iomanip>  //Format Library
#include <string>     //String Library 
#include <cstdlib>    //Standard Library 
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//2-D Array Dimensions 

//Structure Declarations 
struct CkgAcct { //for Problem 1 
    string Name, 
              Address; 
    int acctNum; 
    float begAmt, 
            ttlCks, 
            ttlDep; 
}; 
struct EmpPay { //for Problem 2 
    string name; 
    int hrs; 
    float rate; 
}; 
struct Prime { //for Problem 7 
    unsigned short prime; 
    unsigned char power; 
}; 
struct Primes { //for Problem 7 
    unsigned char nPrimes; 
    Prime *prime; 
}; 

//Function Prototypes
void menu();
void prblm1();
void prblm2();
void prblm3(); //message output only, no program 
void prblm4();
void prblm5();
void prblm6();
void prblm7();
void getInfo(CkgAcct *,float,float); //for Problem 1 
void getInfo(EmpPay *,float &,int); //for Problem 2 
void display(EmpPay *,float &,int); //for Problem 2 
void toEngN(float &); //for Problem 2 
void encrypt(int &); //for Problem 4 
void decrypt(int &); //for Problem 4 
Primes *factor(int);        //for Problem 7 
void prntPrm(Primes *); //for Problem 7 


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    char choice; 
    //Loop and Display menu 
    do{ 
        menu(); 
        cin>>choice; 
        //Process/Map inputs to outputs 
        switch(choice){ 
            case '1':{prblm1();break;} 
            case '2':{prblm2();break;} 
            case '3':{prblm3();break;} 
            case '4':{prblm4();break;} 
            case '5':{prblm5();break;} 
            case '6':{prblm6();break;} 
            case '7':{prblm7();break;} 
            default: cout<<"Exiting Menu"<<endl; 
        } 
    }while(choice>='1'&&choice<='7'); 
    //Exit stage right! 
    return 0; 
} 

//                         Menu
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void menu(){
    //Display menu
    cout<<endl<<"Choose from the following Menu"<<endl;
    cout<<"Type 1 for Problem 1"<<endl; 
    cout<<"Type 2 for Problem 2"<<endl; 
    cout<<"Type 3 for Problem 3"<<endl; 
    cout<<"Type 4 for Problem 4"<<endl; 
    cout<<"Type 5 for Problem 5"<<endl; 
    cout<<"Type 6 for Problem 6"<<endl; 
    cout<<"Type 7 for Problem 7"<<endl<<endl; 
}

//                         Problem 1
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prblm1(){
    cout<<"Problem 1"<<endl;
    //Declare all variables 
    CkgAcct *acct=nullptr; //ptr for ckg acct struct 
    int size; //size of ptr for dynamic struct 
    float tmpCks,   //temp check value 
            tmpDeps, //temp deposit value 
            endAmt;   //ending balance for acct 
    //Initialize ptr for dynamic struct 
    size=sizeof(tmpCks)*20; 
    acct=new CkgAcct[size]; 
    //Input info for checking acct struct 
    getInfo(acct,tmpCks,tmpDeps); 
    //Display info for ckg acct struct 
    cout<<"Checking Account Information"<<endl; 
    cout<<"Account Holder: "<<acct->Name<<endl; 
    cout<<"Address: "<<acct->Address<<endl; 
    cout<<"Beginning Balance: $"; 
    cout<<setprecision(2)<<fixed<<acct->begAmt<<endl; 
    cout<<"Total of all Checks Written for the Month: $"; 
    cout<<setprecision(2)<<fixed<<acct->ttlCks<<endl; 
    cout<<"Total of all Deposits Made for the Month: $"; 
    cout<<setprecision(2)<<fixed<<acct->ttlDep<<endl; 
    //Calculate and display new balance 
    endAmt=acct->begAmt+acct->ttlDep-acct->ttlCks; 
    cout<<"Your new balance is $"; 
    cout<<setprecision(2)<<fixed<<endAmt<<endl; 
    //Debit $20 if acct overdrawn 
    if (endAmt<0) { 
        //Display output for overdraft fee 
        cout<<"Your account is overdrawn."<<endl; 
        cout<<"An overdraft fee of $20 has been"; 
        cout<<"  charged to your account."<<endl; 
        //Charge $20 to checking account 
        endAmt-=20.00; 
        //Display acct balance after fee 
        cout<<"Your updated account balance is $"; 
        cout<<setprecision(2)<<fixed<<endAmt<<endl; 
    } 
    //Erase dynamically allocated memory 
    delete [] acct; 
    acct=nullptr; 
} 

//             Function for Problem 1 
//Function for getting input for ckg acct info 
void getInfo(CkgAcct *person, float cks, float deps) { 
    //Declare and initialize variables 
    string acctID; 
    char option; 
    //Display output for checking acct info input 
    cout<<"Checking Account Information"<<endl; 
    //Get input for account holder name 
    cout<<"Enter name of account holder: "<<endl; 
    getline(cin,person->Name); 
    //Get input for account holder address 
    cout<<"Enter an address: "<<endl; 
    getline(cin,person->Address); 
    //Get acct number with 5-digit input validation 
    while (acctID.length()!=5) { 
    cout<<"Enter a checking account number that"; 
    cout<<" is five digits long: "<<endl; 
    cin>>acctID; 
    } 
    person->acctNum=stoi(acctID); 
    //Get input for beginning balance for the month 
    cout<<"Enter beginning balance for the month: "<<endl; 
    cin>>person->begAmt; 
    //Get input for checks written and calculate sum 
    do { 
    cout<<"Enter values of any checks written"; 
    cout<<" for the month: "<<endl; 
    cin>>cks; 
    person->ttlCks+=cks; 
    cout<<"Enter another value? Type 'Y' for yes or "; 
    cout<<" 'N' for no: "<<endl; 
    cin>>option; 
    } while (toupper(option)=='Y'); 
    //Get input for deposits to acct and calculate sum 
    do { 
    cout<<"Enter values of any deposits made"; 
    cout<<" for the month: "<<endl; 
    cin>>deps; 
    person->ttlDep+=deps; 
    cout<<"Enter another value? Type 'Y' for yes or "; 
    cout<<" 'N' for no: "<<endl; 
    cin>>option; 
    } while (toupper(option)=='Y'); 
} 

//                         Problem 2
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prblm2(){
    cout<<"Problem 2"<<endl;
    //Declare all variables for this function 
    EmpPay *emp=nullptr; //emp pay struct array 
    float grsPay;  //gross paycheck amount 
    int i=0; //struct array subscript counter 
    char option; //'Y' or 'N' input for struct array 
    
    //Initialize all known variables 
    emp=new EmpPay[150]; 
    
    //Use do-while Loop for emp info input 
    do { 
        //Get input for emp info struct array 
        getInfo(emp,grsPay,i); 
        
        //Display employee gross paycheck  
        display(emp,grsPay,i); 

        //Get input for next Loop iteration 
        cout<<"Would you like to calculate the gross"; 
        cout<<" pay for another employee? Type 'Y'"; 
        cout<<" for yes or 'N' for no."<<endl; 
        cin>>option; 
        
        //Update subscript counter 
        i++; 

    //End of do-while Loop 
    } while (toupper(option)=='Y'); 
    
    //Delete dynamically allocated memory 
    delete [] emp; 
    emp=nullptr; 
} 

//             Function for Problem 2 
//Function to get info for emp pay struct array 
void getInfo(EmpPay *emp,float &grsPay,int i) { 
    //Declare and initialize variables 
    float nrmPay=0, //normal pay amount 
            dblPay=0,  //double pay amount 
            tplPay=0;   //triple pay amount 
    //Get input for employee name 
    cout<<"Enter employee name: "<<endl; 
    getline(cin,emp[i].name); 
    //Get input for hours worked 
    cout<<"Enter number of hours worked: "<<endl; 
    cin>>emp[i].hrs; 
    //Get input for normal pay rate 
    cout<<"Enter the normal pay rate: "<<endl; 
    cin>>emp[i].rate; 
    //Calculate normal pay amount 
    (emp[i].hrs<=40) ? 
        nrmPay=emp[i].hrs*emp[i].rate: 
        nrmPay=40*emp[i].rate; 
    //Calculate double pay amount 
    if (emp[i].hrs>40) dblPay=(emp[i].hrs-40)*emp[i].rate*2; 
    //Calculate triple pay amount 
    if (emp[i].hrs>50) tplPay=(emp[i].hrs-50)*emp[i].rate*3; 
    //Calculate gross pay amount 
    grsPay=nrmPay+dblPay+tplPay; 
} 

//             Function for Problem 2 
//Function to display employee gross pay check  
void display(EmpPay *emp,float &grsPay,int i) { 
    //Print company name on first line 
    cout<<"Company A"<<endl; 
    //Print company address on second line 
    cout<<"12345 Smith St."<<endl; 
    //Print emp name and payck amt on third line 
    cout<<"Name: "<<setw(15)<<left<<emp->name; 
    //Print English of payck amt on fourth line 
    cout<<"Amount: "; 
    toEngN(grsPay); 
    //Print signature line on fifth and last line 
    cout<<"Signature Line: "<<endl; 
    
} 

//             Function for Problem 2 
//Function to convert payck amt to English 
void toEngN(float &payck) { 
    //Declare and initialize variables 
    int dlrs,n1000s,n100s,n10s,n1s,cents; 
    //Determine values for each digit place 
    dlrs=payck;                    //Get whole nums value 
    n1000s=dlrs/1000;           //Get thsnds digit value 
    n100s=dlrs%1000/100;     //Get hndrds digit value 
    n10s=dlrs%100/10;           //Get tens digit value 
    n1s=dlrs%10;                   //Get ones digit value 
    cents=(payck-dlrs)*100; //Get cents value 
    //Output the number of 1000's 
    switch(n1000s){ 
        case 3:cout<<"Three Thousand "; 
        case 2:cout<<"Two Thousand "; 
        case 1:cout<<"One Thousand "; 
    } 
    //Output the number of 100's 
    cout<<(n100s==9?"Nine Hundred ": 
           n100s==8?"Eight Hundred ": 
           n100s==7?"Seven Hundred ": 
           n100s==6?"Six Hundred ": 
           n100s==5?"Five Hundred ": 
           n100s==4?"Four Hundred ": 
           n100s==3?"Three Hundred ": 
           n100s==2?"Two Hundred ": 
           n100s==1?"One Hundred ":""); 
    //Output the number of 10's 
    if(n10s==9) cout<<"Ninety "; 
    if(n10s==8)cout<<"Eighty "; 
    if(n10s==7)cout<<"Seventy "; 
    if(n10s==6)cout<<"Sixty "; 
    if(n10s==5)cout<<"Fifty "; 
    if(n10s==4)cout<<"Forty "; 
    if(n10s==3)cout<<"Thirty "; 
    if(n10s==2) { 
        if(n1s>0) cout<<"Twenty "; 
        if(n1s==0) cout<<"Twelve "; 
    } 
    if(n10s==1) { 
        if(n1s>0) cout<<""; 
        if(n1s==0) cout<<"Ten "; 
    } 
    //Output the number of 1's 
    if(n1s==9) { 
        (n10s==1) ? 
            cout<<"Nineteen": 
            cout<<"Nine "; 
    } 
    if(n1s==8) { 
        (n10s==1) ? 
            cout<<"Eighteen": 
            cout<<"Eight "; 
    } 
    if(n1s==7) { 
        (n10s==1) ? 
            cout<<"Seventeen": 
            cout<<"Seven "; 
    } 
    if(n1s==6) { 
        (n10s==1) ? 
            cout<<"Sixteen": 
            cout<<"Six"; 
    } 
    if(n1s==5) { 
        (n10s==1) ? 
            cout<<"Fifteen ": 
            cout<<"Five "; 
    } 
    if(n1s==4) { 
        (n10s==1) ? 
            cout<<"Fourteen ": 
            cout<<"Four "; 
    } 
    if(n1s==3) { 
        (n10s==1) ? 
            cout<<"Thirteen ": 
            cout<<"Three "; 
    } 
    if(n1s==2)cout<<"Two "; 
    if(n1s==1)cout<<"One "; 
    //Print out cents value and new line 
    cout<<"Dollars and "<<cents<<"/100"<<endl; 
} 

//                         Problem 3
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prblm3(){
    cout<<"Problem 3 is located in another project."<<endl; 
}

//                         Problem 4
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prblm4(){
    cout<<"Problem 4"<<endl; 
    //Declare all variables for this function
    int num, option; 
    
    //Get input on encrypting or decrypting 
    cout<<"Would you like to encrypt or decrypt a number?"<<endl; 
    cout<<"Enter 1 for encrypt or 2 for decrypt."<<endl; 
    cin>>option; 
    
    //Encrypt number with swapping 
    if (option==1) { 
        //Get input for number to encrypt 
        cout<<"Input a 4-digit number with each digit in the"; 
        cout<<" range of 0 to 7: "<<endl; 
        cin>>num; 
        //Swap digits to encrypt number 
        encrypt(num); 
    } 
    
    //Decrypt number with swapping 
    else if (option==2) { 
        //Get input for number to encrypt 
        cout<<"Input a 4-digit number with each digit in the"; 
        cout<<" range of 0 to 7: "<<endl; 
        cin>>num; 
        //Swap digits to decrypt number 
        decrypt(num); 
    } 
} 

//    Function for Problem 4 
//Function to encrypt number 
void encrypt(int &num) { 
    //Declare encryption variables 
    int d1, d2, d3, d4, temp; 
    //Isolate each digit of number 
    d1=num/1000; 
    d2=num%1000/100; 
    d3=num%100/10; 
    d4=num%10; 
    //Replace each with sum of value plus 5 mod 8 
    d1+=5%8; 
    d2+=5%8; 
    d3+=5%8; 
    d4+=5%8; 
    //Output flag if digit values 8 or 9 appear 
    if (d1==8 || d1==9) 
        cout<<"Error: "<<d1<<" is outside 0 to 7 range"<<endl; 
    if (d2==8 || d2==9) 
        cout<<"Error: "<<d2<<" is outside 0 to 7 range"<<endl; 
    if (d3==8 || d3==9) 
        cout<<"Error: "<<d3<<" is outside 0 to 7 range"<<endl; 
    if (d4==8 || d4==9) 
        cout<<"Error: "<<d4<<" is outside 0 to 7 range"<<endl; 
    //Swap first and third digits 
    temp=d1; 
    d1=d3; 
    d3=temp; 
    //Swap second and fourth digits 
    temp=d2; 
    d2=d4; 
    d4=temp; 
    //Return digits to places in number 
    d1*=1000; 
    d2*=100; 
    d3*=10; 
    num=d1+d2+d3+d4; 
    //Print out encrypted number 
    cout<<num<<endl; 
} 

//   Function for Problem 4 
//Function to encrypt number 
void decrypt(int &num) { 
    //Declare decryption variables 
    int d1, d2, d3, d4, temp; 
    //Isolate each digit of number 
    d1=num/1000; 
    d2=num%1000/100; 
    d3=num%100/10; 
    d4=num%10; 
    //Swap second and fourth digits 
    temp=d2; 
    d2=d4; 
    d4=temp; 
    //Swap first and third digits 
    temp=d1; 
    d1=d3; 
    d3=temp; 
    //Replace each with sum of value plus 5 mod 8 
    d1-=5%8; 
    d2-=5%8; 
    d3-=5%8; 
    d4-=5%8; 
    //Return digits to places in number 
    d1*=1000; 
    d2*=100; 
    d3*=10; 
    num=d1+d2+d3+d4; 
    //Print out decrypted number 
    cout<<num<<endl; 
} 

//                         Problem 5
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prblm5(){
    cout<<"Problem 5"<<endl; 
    //Declare all variables for this function 
    short int sSInt=7; 
    unsigned short int uSInt=17; 
    int sInt=16; 
    unsigned int uInt=33; 
    long int sLInt=20; 
    unsigned long int uLInt=65; 
    long long int sLlInt=25; 
    unsigned long long int uLlInt=65; 
    float Float=34; 
    double Dbl=170; 
    long double LDbl=1754, num=0, fact=1; 
    /*
    //Test signed and unsigned ints for lgst !n value 
    for (int i=1; i<=LDbl; i++) { 
        fact*=i; 
        (i==LDbl) ? num=fact: num; 
    } 
    */
    //Print out max factor value for a short int  
    cout<<"The largest short int value"; 
    cout<<" is 7, where 7! = 5040."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned short int  
    cout<<"The largest unsigned short int value"; 
    cout<<"is 17, where 17! = 32768."<<endl; 
    cout<<endl; 
    //Print out max factor value for an integer 
    cout<<"The largest integer value is"; 
    cout<<" 16, where 16! = 2004189184."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned int   
    cout<<"The largest unsigned int value"; 
    cout<<" is 33, where 33! = 2147483648."<<endl; 
    cout<<endl; 
    //Print out max factor value for a long int 
    cout<<"The largest long int value"; 
    cout<<" is 20, where 20! = 2432902008176640000."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned long int 
    cout<<"The largest unsigned long int value"; 
    cout<<" is 65, where 65! = 9223372036854775808."<<endl; 
    cout<<endl; 
    //Print out max factor value for a long long int  
    cout<<"The largest long long int value is"; 
    cout<<" 25, where 25! = 7034535277573963776."<<endl; 
    cout<<endl; 
    //Print out max factor value for an unsigned long long int 
    cout<<"The largest unsigned long long int value"; 
    cout<<" is 65, where 65! = 9223372036854775808."<<endl; 
    cout<<endl; 
    //Print out max factor value for a float 
    cout<<"The largest float value is 34, where"; 
    cout<<" 34! = 2.95233e+38."<<endl; 
    cout<<endl; 
    //Print out max factor value for a double 
    cout<<"The largest double value is 170, where"; 
    cout<<" 170! = 7.25742e+306."<<endl; 
    cout<<endl; 
    //Print out max factor value for a long double 
    cout<<"The largest long double value is"; 
    cout<<" 1754, where 1754! = 1.97926e+4930."<<endl; 
    cout<<endl; 
}

//                         Problem 6
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prblm6(){
    cout<<"Problem 6"<<endl; 
    //Output base conversions for 2.875 
    cout<<"2.875 Base 10 converted to "<<endl; 
    cout<<"Binary = 10.111 Base 2"<<endl; 
    cout<<"Oct = 2.7 Base 8"<<endl; 
    cout<<"Hex = 2.E Base 16"<<endl; 
    cout<<"Float = 5C000002 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for 0.1796875  
    cout<<"0.1796875 Base 10 converted to "<<endl; 
    cout<<"Binary = .0010111 Base 2"<<endl; 
    cout<<"Oct = .134 Base 8"<<endl; 
    cout<<"Hex = .2D Base 16"<<endl; 
    cout<<"Float = 17000000 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for -2.875 
    cout<<"-2.875 Base 10 converted to "<<endl; 
    cout<<"Binary = -10.111 Base 2"<<endl; 
    cout<<"Oct = -2.7 Base 8"<<endl; 
    cout<<"Hex = -2.E Base 16"<<endl; 
    cout<<"Float = DC000002 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for -0.1796875 
    cout<<"-0.1796875 Base 10 converted to "<<endl; 
    cout<<"Binary = -.0010111 Base 2"<<endl; 
    cout<<"Oct = -.134 Base 8"<<endl; 
    cout<<"Hex = -.2D Base 16"<<endl; 
    cout<<"Float = A7000000 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for 59999901  
    cout<<"59999901 Base 16 converted to "<<endl; 
    cout<<"Binary = 1.0110011 Base 2"<<endl; 
    cout<<"Oct = 1.314 Base 8"<<endl; 
    cout<<"Hex = 1.66 Base 16"<<endl; 
    cout<<"Decimal = 1.398 Base 10"<<endl; 
    cout<<endl; 
    
    //Output base conversions for 59999902 
    cout<<"59999902 Base 16 converted to "<<endl; 
    cout<<"Binary = 10.110011 Base 2"<<endl; 
    cout<<"Oct = 2.63 Base 8"<<endl; 
    cout<<"Hex = 2.CD Base 16"<<endl; 
    cout<<"Decimal = 2.844 Base 10"<<endl; 
    cout<<endl; 
    
    //Output base conversions for A66667FE 
    cout<<"A66667FE Base 16 converted to "<<endl; 
    cout<<"Binary = -1.001101 Base 2"<<endl; 
    cout<<"Oct = -1.15 Base 8"<<endl; 
    cout<<"Hex = -1.33 Base 16"<<endl; 
    cout<<"Decimal = -1.203 Base 10"<<endl; 
    cout<<endl; 
}

//                         Problem 7
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
void prblm7(){ 
    cout<<"Problem 7"<<endl; 
    //Declare all variables for this function 
    Primes *arr; 
    int num; 
    //Dynamic memory for primes up to 8 values 
    arr->prime=new Prime[8]; 
    //Get input for number to factor 
    cout<<"Enter an integer value between 2 and"; 
    cout<<" 10,000 to be factored."<<endl; 
    cin>>num; 
    //Find primes of the input value 
    factor(num); 
    //Display factored number 
    cout<<num<<" = "; 
    //Display prime values 
    prntPrm(arr); 
    //Delete allocated memory 
    delete [] arr->prime; 
} 

//Function Implementations

//Function to find integer primes 
Primes *factor(int num) { 
    //Declare and initialize variables 
    Primes *fact; //factored number 
    int value, //dividend value 
         prms[8], //primes array up to 8 values 
         divsr, //divisor value 
         pwrT, pwrTh, pwrF, pwrDef; //prime power values 
    //Dynamic memory for primes up to 4 values 
    fact->prime=new Prime[4]; 
    //Find primes of a given value 
    for (int i=0; i<8; i++) { 
        //Initialize dividend value 
        if (i==0) value=num; 
        //Determine divisor value 
        if (value%2==0) divsr=2; 
        else if (value%3==0) divsr=3; 
        else if (value%5==0) divsr=5; 
        else divsr=1; 
        //Store divisor in prime array 
        if (divsr>1) prms[i]=divsr; 
        //Find new dividend value 
        if (divsr>1) value/=divsr; 
        //If last prime store value in array 
        if (divsr==1) prms[i]=value; 
    } 
    //Find pwr value for each prime number 
    for (int i=0; i<8; i++) { 
        //Use switch to find pwr values 
        switch (prms[i]) { 
            case 0: prms[i]; 
                        break; 
            case 2: pwrT++; 
                        break; 
            case 3: pwrTh++; 
                        break; 
            case 5: pwrF++; 
                        break; 
            default: pwrDef++; 
        } 
    } 
    //Store number primes in Primes struct 
    fact->nPrimes=pwrT+pwrTh+pwrF+pwrDef; 
    //Store prime and pwr values in struct array 
    for (int i=0; i<4; i++) { 
        //Prime two and power value 
        fact->prime[i].prime=2; 
        fact->prime[i].power=pwrT; 
        //Prime three and power value 
        fact->prime[i].prime=3; 
        fact->prime[i].power=pwrTh; 
        //Prime five and power value 
        fact->prime[i].prime=5; 
        fact->prime[i].power=pwrF; 
        //Last prime and power value 
        fact->prime[i].prime=prms[fact->nPrimes-1]; 
        fact->prime[i].power=pwrDef; 
    } 
    //Return value and exit function 
    return fact; 
} 

//Function to output all prime factors 
void prntPrm(Primes *fact) { 
    //Output primes until end of struct array 
    for (int i=0; i<4; i++) { 
        cout<<fact->prime[i].prime<<"^"; 
        cout<<fact->prime[i].power; 
        if (i<3) cout<<" * "; 
    } 
}  



