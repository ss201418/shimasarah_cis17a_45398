/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 14, 2021 at 11:40 PM 
 * Purpose: Midterm Problem 6 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format Library 
using namespace std; 

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Output base conversions for 2.875 
    cout<<"2.875 Base 10 converted to "<<endl; 
    cout<<"Binary = 10.111 Base 2"<<endl; 
    cout<<"Oct = 2.7 Base 8"<<endl; 
    cout<<"Hex = 2.E Base 16"<<endl; 
    cout<<"Float = 5C000002 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for 0.1796875  
    cout<<"0.1796875 Base 10 converted to "<<endl; 
    cout<<"Binary = .0010111 Base 2"<<endl; 
    cout<<"Oct = .134 Base 8"<<endl; 
    cout<<"Hex = .2D Base 16"<<endl; 
    cout<<"Float = 17000000 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for -2.875 
    cout<<"-2.875 Base 10 converted to "<<endl; 
    cout<<"Binary = -10.111 Base 2"<<endl; 
    cout<<"Oct = -2.7 Base 8"<<endl; 
    cout<<"Hex = -2.E Base 16"<<endl; 
    cout<<"Float = DC000002 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for -0.1796875 
    cout<<"-0.1796875 Base 10 converted to "<<endl; 
    cout<<"Binary = -.0010111 Base 2"<<endl; 
    cout<<"Oct = -.134 Base 8"<<endl; 
    cout<<"Hex = -.2D Base 16"<<endl; 
    cout<<"Float = A7000000 Base 16"<<endl; 
    cout<<endl; 
    
    //Output base conversions for 59999901  
    cout<<"59999901 Base 16 converted to "<<endl; 
    cout<<"Binary = 1.0110011 Base 2"<<endl; 
    cout<<"Oct = 1.314 Base 8"<<endl; 
    cout<<"Hex = 1.66 Base 16"<<endl; 
    cout<<"Decimal = 1.398 Base 10"<<endl; 
    cout<<endl; 
    
    //Output base conversions for 59999902 
    cout<<"59999902 Base 16 converted to "<<endl; 
    cout<<"Binary = 10.110011 Base 2"<<endl; 
    cout<<"Oct = 2.63 Base 8"<<endl; 
    cout<<"Hex = 2.CD Base 16"<<endl; 
    cout<<"Decimal = 2.844 Base 10"<<endl; 
    cout<<endl; 
    
    //Output base conversions for A66667FE 
    cout<<"A66667FE Base 16 converted to "<<endl; 
    cout<<"Binary = -1.001101 Base 2"<<endl; 
    cout<<"Oct = -1.15 Base 8"<<endl; 
    cout<<"Hex = -1.33 Base 16"<<endl; 
    cout<<"Decimal = -1.203 Base 10"<<endl; 
    cout<<endl; 
    
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 

//Function Implementations