/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 15, 2021 10:30 AM 
 * Purpose:  Midterm Problem 7 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>   //Format Library 
#include <string>      //String Library 
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 
struct Prime { 
    unsigned short prime; 
    unsigned char power; 
}; 
struct Primes { 
    unsigned char nPrimes; 
    Prime *prime; 
}; 

//Function Prototypes 
Primes *factor(int);        //input int, return primes 
void prntPrm(Primes *); //output prime factors 

//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare all variables for this function 
    Primes *arr; 
    int num; 
    //Dynamic memory for primes up to 8 values 
    arr->prime=new Prime[8]; 
    //Get input for number to factor 
    cout<<"Enter an integer value between 2 and"; 
    cout<<" 10,000 to be factored."<<endl; 
    cin>>num; 
    //Find primes of the input value 
    factor(num); 
    //Display factored number 
    cout<<num<<" = "; 
    //Display prime values 
    prntPrm(arr); 
    //Delete allocated memory 
    delete [] arr->prime; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
} 

//Function Implementations

//Function to find integer primes 
Primes *factor(int num) { 
    //Declare and initialize variables 
    Primes *fact; //factored number 
    int value, //dividend value 
         prms[8], //primes array up to 8 values 
         divsr, //divisor value 
         pwrT, pwrTh, pwrF, pwrDef; //prime power values 
    //Dynamic memory for primes up to 4 values 
    fact->prime=new Prime[4]; 
    //Find primes of a given value 
    for (int i=0; i<8; i++) { 
        //Initialize dividend value 
        if (i==0) value=num; 
        //Determine divisor value 
        if (value%2==0) divsr=2; 
        else if (value%3==0) divsr=3; 
        else if (value%5==0) divsr=5; 
        else divsr=1; 
        //Store divisor in prime array 
        if (divsr>1) prms[i]=divsr; 
        //Find new dividend value 
        if (divsr>1) value/=divsr; 
        //If last prime store value in array 
        if (divsr==1) prms[i]=value; 
    } 
    //Find pwr value for each prime number 
    for (int i=0; i<8; i++) { 
        //Use switch to find pwr values 
        switch (prms[i]) { 
            case 0: prms[i]; 
                        break; 
            case 2: pwrT++; 
                        break; 
            case 3: pwrTh++; 
                        break; 
            case 5: pwrF++; 
                        break; 
            default: pwrDef++; 
        } 
    } 
    //Store number primes in Primes struct 
    fact->nPrimes=pwrT+pwrTh+pwrF+pwrDef; 
    //Store prime and pwr values in struct array 
    for (int i=0; i<4; i++) { 
        //Prime two and power value 
        fact->prime[i].prime=2; 
        fact->prime[i].power=pwrT; 
        //Prime three and power value 
        fact->prime[i].prime=3; 
        fact->prime[i].power=pwrTh; 
        //Prime five and power value 
        fact->prime[i].prime=5; 
        fact->prime[i].power=pwrF; 
        //Last prime and power value 
        fact->prime[i].prime=prms[fact->nPrimes-1]; 
        fact->prime[i].power=pwrDef; 
    } 
    //Return value and exit function 
    return fact; 
} 

//Function to output all prime factors 
void prntPrm(Primes *fact) { 
    //Output primes until end of struct array 
    for (int i=0; i<4; i++) { 
        cout<<fact->prime[i].prime<<"^"; 
        cout<<fact->prime[i].power; 
        if (i<3) cout<<" * "; 
    } 
} 
