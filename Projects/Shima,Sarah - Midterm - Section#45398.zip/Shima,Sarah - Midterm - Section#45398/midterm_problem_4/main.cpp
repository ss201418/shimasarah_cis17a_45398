/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 14, 2021 at 11:30 PM 
 * Purpose:  Midterm Problem 4 
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes 
void encrypt(int &); 
void decrypt(int &); 

//Execution of Code Begins Here
int main(int argc, char** argv) { 
    //Declare all variables for this function
    int num, option; 
    
    //Get input on encrypting or decrypting 
    cout<<"Would you like to encrypt or decrypt a number?"<<endl; 
    cout<<"Enter 1 for encrypt or 2 for decrypt."<<endl; 
    cin>>option; 
    
    //Encrypt number with swapping 
    if (option==1) { 
        //Get input for number to encrypt 
        cout<<"Input a 4-digit number with each digit in the"; 
        cout<<" range of 0 to 7: "<<endl; 
        cin>>num; 
        //Swap digits to encrypt number 
        encrypt(num); 
    } 
    
    //Decrypt number with swapping 
    else if (option==2) { 
        //Get input for number to encrypt 
        cout<<"Input a 4-digit number with each digit in the"; 
        cout<<" range of 0 to 7: "<<endl; 
        cin>>num; 
        //Swap digits to decrypt number 
        decrypt(num); 
    } 

    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0;
} 

//Function Implementations 

//Function to encrypt number 
void encrypt(int &num) { 
    //Declare encryption variables 
    int d1, d2, d3, d4, temp; 
    //Isolate each digit of number 
    d1=num/1000; 
    d2=num%1000/100; 
    d3=num%100/10; 
    d4=num%10; 
    //Replace each with sum of value plus 5 mod 8 
    d1+=5%8; 
    d2+=5%8; 
    d3+=5%8; 
    d4+=5%8; 
    //Output flag if digit values 8 or 9 appear 
    if (d1==8 || d1==9) 
        cout<<"Error: "<<d1<<" is outside 0 to 7 range"<<endl; 
    if (d2==8 || d2==9) 
        cout<<"Error: "<<d2<<" is outside 0 to 7 range"<<endl; 
    if (d3==8 || d3==9) 
        cout<<"Error: "<<d3<<" is outside 0 to 7 range"<<endl; 
    if (d4==8 || d4==9) 
        cout<<"Error: "<<d4<<" is outside 0 to 7 range"<<endl; 
    //Swap first and third digits 
    temp=d1; 
    d1=d3; 
    d3=temp; 
    //Swap second and fourth digits 
    temp=d2; 
    d2=d4; 
    d4=temp; 
    //Return digits to places in number 
    d1*=1000; 
    d2*=100; 
    d3*=10; 
    num=d1+d2+d3+d4; 
    //Print out encrypted number 
    cout<<num<<endl; 
} 

//Function to encrypt number 
void decrypt(int &num) { 
    //Declare decryption variables 
    int d1, d2, d3, d4, temp; 
    //Isolate each digit of number 
    d1=num/1000; 
    d2=num%1000/100; 
    d3=num%100/10; 
    d4=num%10; 
    //Swap second and fourth digits 
    temp=d2; 
    d2=d4; 
    d4=temp; 
    //Swap first and third digits 
    temp=d1; 
    d1=d3; 
    d3=temp; 
    //Replace each with sum of value plus 5 mod 8 
    d1-=5%8; 
    d2-=5%8; 
    d3-=5%8; 
    d4-=5%8; 
    //Return digits to places in number 
    d1*=1000; 
    d2*=100; 
    d3*=10; 
    num=d1+d2+d3+d4; 
    //Print out decrypted number 
    cout<<num<<endl; 
} 
