/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Players.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */ 

#ifndef PLAYERS_H
#define PLAYERS_H 

#include <string> 
#include <iostream> 

//Player Class 
class Players { 
    protected: 
        string name; 
        string hD,hC,hB,hS; 
    public: 
        //Default constructor 
        Players(); 
        void setName(string); 
        void setHiD(string); 
        void setHiC(string); 
        void setHiB(string); 
        void setHiS(string); 
        string setName() const; 
        string setHiD() const; 
        string setHiC() const; 
        string setHiB() const; 
        string setHiS() const; 
}; 
#endif /* PLAYERS_H */ 