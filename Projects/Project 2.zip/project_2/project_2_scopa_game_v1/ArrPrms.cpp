/* 
 * File: ArrPrms.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */

#include "ArrPrms.h" 

//Default constructor 
ArrPrms::ArrPrms() { 
    prmVal=As; 
} 
void ArrPrms::setPrm(int i) { 
    prmVal=prmVals[i]; 
} 
Prm ArrPrms::getPrm() const { 
    return prmVal; 
} 