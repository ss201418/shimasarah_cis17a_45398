/* 
 * File: Cards.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */ 

#ifndef CARDS_H
#define CARDS_H 

#include <ctime> 
#include <string> 
using namespace std; 

//Enumerated Variables 
enum Prm {F=10,D=12,Tr,Qt,Cnq,As,Sei=18,Ste=20}; 

//Cards Class 
class Cards { 
    protected: 
        Prm prmVals[]={As,D,Tr,Qt,Cnq,Sei,Ste,F,F,F}; 
        int regVals[]={1,2,3,4,5,6,7,8,9,10}; 
        char s[]={'D','C','B','S'}; 
        char f[]={'A','2','3','4','5','6','7','F','C','R'}; 
        char suit; 
        char face; 
        string value; 
        int regVal; 
        Prm prmVal; 
    public: 
        //Default constructor 
        Cards(); 
        //Functions to set values 
        void setSuit(int); 
        void setFace(int); 
        void setVal(); 
        void setReg(int); 
        void setPrm(int); 
        //Functions to get values 
        char getSuit() const; 
        char getFace() const; 
        string getVal() const; 
        int getReg() const; 
        Prm getPrm() const; 
}; 
#endif /* CARDS_H */ 