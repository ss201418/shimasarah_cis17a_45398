/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Scores.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */ 

#include <fstream> 
#include "Scores.h" 

//Default constructor 
Scores::Scores() { 
    total=0,scopas=0,nMtchs=0; 
    nCns=0,primes=0,svnD=0; 
} 
//Functions to set values 
void Scores::setFile(string f) { 
    file=f; 
} 
void Scores::setScps(int i) { 
    scopas=i; 
} 
void Scores::setNMtch(int i) { 
    nMtchs=i; 
} 
void Scores::setNCns(int i) { 
    nCns=i; 
} 
void Scores::setPrms(int i) { 
    primes=i; 
} 
void Scores::setSvnD(int i) { 
    (i==1) ? sevenD=true: sevenD=false; 
    (sevenD) ? svnD=1: svnD; 
} 
void Scores::setTtl(int) { 
    total=scopas; 
    total+=nMtchs; 
    total+=nCns; 
    total+=primes; 
    total+=svnD; 
    //Store values in file 
    Scores::ptStore(); 
} 
//Functions to get values 
int Scores::getScps() const { 
    txt.open(file,ios::in|ios::binary); 
    txt.read(scopas,sizeof(int)); 
    txt.close(); 
    return scopas; 
} 
int Scores::getNMtch() const { 
    txt.open(file,ios::in|ios::binary); 
    txt.read(nMtchs,sizeof(int)); 
    txt.close(); 
    return nMtchs; 
} 
int Scores::getNCns() const { 
    txt.open(file,ios::in|ios::binary); 
    txt.read(nCns,sizeof(int)); 
    txt.close(); 
    return nCns; 
} 
int Scores::getPrms() const { 
    txt.open(file,ios::in|ios::binary); 
    txt.read(primes,sizeof(int)); 
    txt.close(); 
    return primes; 
} 
bool Scores::getSvnD() const { 
    txt.open(file,ios::in|ios::binary); 
    txt.read(svnD,sizeof(int)); 
    txt.close(); 
    return svnD; 
} 
int Scores::getTtl() const { 
    txt.open(file,ios::in|ios::binary); 
    txt.read(total,sizeof(int)); 
    txt.close(); 
    return total; 
} 
//Function to store values 
void Scores::ptStore() { 
    txt.open(file,ios::out|ios::binary|ios::trunc); 
    txt.write(reinterpret_cast<char *>(scopas),sizeof(int)); 
    txt.write(reinterpret_cast<char *>(nMtchs),sizeof(int)); 
    txt.write(reinterpret_cast<char *>(nCns),sizeof(int)); 
    txt.write(reinterpret_cast<char *>(primes),sizeof(int)); 
    txt.write(reinterpret_cast<char *>(svnD),sizeof(int)); 
    txt.write(reinterpret_cast<char *>(total),sizeof(int)); 
    txt.close(); 
} 
//Operator Overloading 
Scores::Scores operator + (const Scores &) { 
    
}
Scores::Scores operator - (const Scores &) { 
    
}
Scores::Scores operator ++ (const Scores &) { 
    
}
Scores::Scores operator -- (const Scores &) { 
    
}