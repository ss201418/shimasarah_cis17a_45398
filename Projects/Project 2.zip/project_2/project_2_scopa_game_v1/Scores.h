/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Scores.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */ 

#ifndef SCORES_H
#define SCORES_H 

#include <string> 
#include <iostream> 
#include "Players.h"  

//Scores Class 
class Scores : public Players { 
    private: 
        string file=""; 
        fstream txt; 
        int scopas,nMtchs,nCns; 
        int primes,svnD,total; 
        bool sevenD=false; 
    public: 
        //Default constructor 
        Scores(); 
        //Functions to set values 
        void setFile(string); 
        void setScps(int); 
        void setNMtch(int); 
        void setNCns(int); 
        void setPrms(int); 
        void setSvnD(int); 
        void setTtl(int); 
        //Functions to get values 
        int getScps() const; 
        int getNMtch() const; 
        int getNCns() const; 
        int getPrms() const; 
        bool getSvnD() const; 
        int getTtl() const; 
        //Function to store values 
        void ptStore(); 
        //Operator Overloading 
        Scores operator + (const Scores &); 
        Scores operator - (const Scores &); 
        Scores operator ++ (const Scores &); 
        Scores operator -- (const Scores &); 
}; 
#endif /* SCORES_H */ 