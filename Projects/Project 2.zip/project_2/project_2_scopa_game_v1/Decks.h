/* 
 * File: Decks.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */ 

#ifndef DECKS_H
#define DECKS_H

#include "Cards.h"  

//Decks Class - Derived from Cards 
class Decks : public Cards { 
    private: 
        Cards *arrDyn,*deck; 
        string file="cards.txt"; 
        fstream txt; 
        int nCards=0,max=40; 
    public: 
        //Default constructor 
        Decks(const int); 
        //Destructor 
        Decks::~Decks(); 
        //Function to create deck 
        void deck(); 
        //Function to deal cards 
        void deal(int); 
        //Function to shuffle deck 
        void shuffle(int); 
        //Function to store to file 
        void store(); 
}; 
#endif /* DECKS_H */ 