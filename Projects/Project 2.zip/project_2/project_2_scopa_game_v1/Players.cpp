/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Player.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */ 

#include <fstream> 
#include "Players.h" 

//Default constructor 
Players::Players { 
    name=""; 
    hD=""; 
    hC=""; 
    hB=""; 
    hS=""; 
} 
void Players::setName(string s) { 
    name=s; 
} 
void Players::setHiD(string s) { 
    hD=s; 
} 
void Players::setHiC(string s) { 
    hC=s; 
} 
void Players::setHiB(string s) { 
    hB=s; 
} 
void Players::setHiS(string s) { 
    hS=s; 
} 
string Players::setName() const { 
    return name; 
} 
string Players::setHiD() const { 
    return hD; 
} 
string Players::setHiC() const { 
    return hC; 
} 
string Players::setHiB() const { 
    return hB; 
} 
string Players::setHiS() const { 
    return hS; 
} 