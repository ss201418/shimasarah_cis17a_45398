/* 
 * File: ArrPrms.h 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */ 

#ifndef ARRPRMS_H
#define ARRPRMS_H 

#include <ctime> 
#include <string> 
using namespace std; 

//Enumerated Variables 
enum Prm {F=10,D=12,Tr,Qt,Cnq,As,Sei=18,Ste=20}; 

//Cards Class 
class ArrPrms { 
    protected: 
        static Prm prmVals[]={As,D,Tr,Qt,Cnq,Sei,Ste,F,F,F}; 
        Prm prmVal; 
    public: 
        //Default constructor 
        ArrPrms(); 
        //Function to set prime value 
        void setPrm(int); 
        //Function to get prime value 
        Prm getPrm() const; 
}; 
#endif /* ARRPRMS_H */ 