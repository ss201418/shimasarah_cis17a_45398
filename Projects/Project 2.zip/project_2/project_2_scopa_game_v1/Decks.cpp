/* 
 * File: Decks.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */

#include "Decks.h" 

//Default constructor 
Decks::Decks(const int size) { 
    arrDyn=new Cards[size]; 
    nCards=size; 
    //Initialize all cards in array 
    for (int i=0; i<size; i++) { 
        Cards temp; 
        arrDyn[i]=temp; 
    } 
} 
//Destructor 
Decks::~Decks() { 
    delete [] arrDyn; 
} 
//Function to create deck array 
Decks::deck() { 
    deck=new Cards[max]; 
    int crd=0; 
    for (int i=0; i<4; i++) { 
        for (int j=0; j<10; j++) { 
            Cards temp; 
            temp.setSuit(i); 
            temp.setFace(j); 
            temp.setVal(); 
            temp.setReg(j) 
            temp.setPrm(j); 
            deck[i]=temp; 
        } 
    } 
    //Store values to file 
    Decks::store(); 
} 
//Function to deal cards 
void *Decks::deal(int start) { 
    //Open file 
    txt.open(file,ios::in|ios::binary); 
    //Deal cards to array 
    for (int i=start; i<nCards; i++) { 
        //Read card from file 
        txt.read(deck[i],2); 
        //Store value in card array 
        arrDyn[i]=deck[i]; 
    } 
    //Close file 
    txt.close(); 
} 
//Function to shuffle deck 
void Decks::shuffle(int shuf) { 
    for (int i=0; i<shuf; i++) { 
        for (int j=0; j<max; j++) { 
            int num=rand()%max; 
            Cards temp; 
            temp=deck[j]; 
            deck[j]=deck[num]; 
            deck[num]=temp; 
        } 
    } 
} 
//Function to store to file 
void Decks::store() { 
    //Open file 
    txt.open(file,ios::out|ios::binary|ios::trunc); 
    //Write to file 
    for (int i=0; i<max; i++) { 
        txt.write(reinterpret_cast<char *>(deck[i]),2); 
    } 
    //Close file 
    txt.close(); 
} 