/* 
 * File: Cards.cpp 
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */

#include "Cards.h" 

//Default constructor 
Cards::Cards() { 
    suit=''; 
    face=''; 
    value=""; 
    regVal=0; 
    prmVal=As; 
} 
//Functions to set values 
void Cards::setSuit(int i) { 
    suit=s[i]; 
} 
void Cards::setFace(int i) { 
    face=f[i]; 
}
void Cards::setVal() { 
    value=suit+face; 
} 
void Cards::setReg(int i) { 
    regVal=regVals[i]; 
} 
void Cards::setPrm(int i) { 
    prmVal=prmVals[i]; 
} 
//Functions to get values 
char Cards::getSuit() const { 
    return suit; 
} 
char Cards::getFace() const { 
    return face; 
} 
string Cards::getVal() const { 
    return value; 
} 
int Cards::getReg() const { 
    return regVal; 
} 
Prm Cards::getPrm() const { 
    return prmVal; 
} 