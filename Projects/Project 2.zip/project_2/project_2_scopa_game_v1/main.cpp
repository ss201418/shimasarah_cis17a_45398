/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 27th, 2021, 4:00 PM 
 * Purpose:  Project 2 - Scopa Card Game 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <iomanip>  //Format the output
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <string>     //Strings
#include <cmath>     //Math functions 
#include "Decks.h"  
#include "Scores.h"  
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 
struct Arrays { 
    Decks *deck(40); 
    Decks *stock(30); 
    Decks *table(10); 
}; 
struct Player { 
    string name; 
    string hD,hC,hB,hS; 
    Scores score; 
    Decks *hand(3); 
    Decks *mtch(40); 
}; 

//Enumerated Variables 
enum Prm {F=10,D=12,Tr,Qt,Cnq,As,Sei=18,Ste=20}; 

//Function Prototypes 
void menu(int &); 
bool play(Player &, Player &); 
void deal(Arrays &, Player &, Player &, int &); 
void match(Arrays &, Player &); 
void score(Arrays &, Player &, Player &, int); 
void prime(Arrays &, Player &, int); 
void store(Player &); 

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0))); 
    //Declare and initialize variables 
    int option=0; 
    bool exit=false,win=false; 
    Player p1,p2; 
    //Initialize Player 1 and 2 names 
    p1.name="Player"; 
    p2.name="Computer"; 
    //Display Menu and Start a Game 
    do { 
        //Display Menu Options 
        menu(option); 
        //Start a Game 
        if (option==1) win=play(p1,p2); 
        //Update exit value 
        else if (option==2) exit=true; 
        //Validate option value 
        else cout<<"Invalid input"<<endl; 
    //End of while Loop 
    } while (!exit); 
    //Display game winner 
    if (win) cout<<"Winner is "; 
    (p1.score==11) ? cout<<p1.name: cout<<p2.name; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
}
//*****FUNCTION IMPLEMENTATIONS***** 

//Menu Function 
void menu(int &option) { 
    //Display menu options 
    cout<<"Main Menu"<<endl; 
    cout<<"Choose one of the following: "<<endl; 
    cout<<"Type 1 - Start New Game"<<endl; 
    cout<<"Type 2 - Exit Menu"<<endl; 
    //Get input for menu option 
    cin>>option; 
    //Option 1 - Start New Game 
    if (option==1) 
        { cout<<"Starting new game: "<<endl; } 
    //Option 2 - Exit Menu 
    else if (option==2) 
        { cout<<"Now exiting menu"<<endl; } 
} 

//Play cards for a single round 
bool play(Player &p1, Player &p2) { 
    //Declare and initialize variables 
    Arrays piles; 
    bool win=false; 
    //Continue until a player gets 11 points 
    while (!win) { 
        //Continue round until end of stock pile 
        while (piles.stock) { 
            //Deal cards to players and table 
            deal(piles, p1, p2); 
            //Display table cards 
            cout<<"Table: "<<endl; 
            for (int i=0; i<10; i++) { 
                cout<<piles.table[i].getVal()<<" "; 
            } 
            cout<<endl<<endl; 
            //Match cards for Player 1 turn 
            match(piles, p1, left); 
            //Write Player 1 matches to file 
            store(p1); 
            //Match cards for Player 2 turn 
            match(piles, p2); 
            //Write Player 2 matches to file 
            store(p2); 
            //End of while Loop 
        } 
        //Close files 
        txt1.close();
        txt2.close();
        //Score points for all players 
        score(piles, p1, p2, nCards);
        //Determine if winner with 11 points  
        if (p1.score.getTtl()==11) win=true; 
        else if (p2.score.getTtl()==11) win=true; 
        else win=false; 
    //End of while Loop 
    } 
    //Return value and exit function 
    return win;
} 

//Deal cards to table and player hands 
void deal(Arrays &piles, Player &p1, Player &p2) { 
    //Declare and initialize variables 
    bool kings=true; 
    int nShuf=3,ctr=0; 
    //Initial deal to table 
    do { 
        //Shuffle deck 
        piles.deck->shuffle(nShuf); 
        //Distribute four cards to table 
        for (int i=0; i<4; i++) { 
            piles.table->deal(i); 
            if (piles.table[i]->getVal()=="DR") ctr++; 
            if (piles.table[i]->getVal()=="CR") ctr++; 
            if (piles.table[i]->getVal()=="BR") ctr++; 
            if (piles.table[i]->getVal()=="SR") ctr++; 
            //Redeal if three or four kings on table 
            (ctr>2) ? kings=true: kings=false; 
        //End of for Loop 
        } 
    //End of do-while Loop 
    } while (kings); 
    //Initial deal to hands and stockpile 
    for (int i=4; i<40; i++) { 
        if (i<7) p1.hand->deal(i); 
        else if (i>=7 && i<10) p2.hand->deal(i); 
        else piles.stock->deal(i); 
    } 
} 

//Match player and table card values 
void match(Arrays &piles, Player &plyr) {
    //Declare and initialize variables 
    string file=""; 
    fstream txt; 
    Decks temp(10); 
    Cards playCrd, empty; 
    string card=""; 
    char ch; 
    int player=0, tblVal=0; 
    //Determine player hand to display 
    (plyr.name=="Player 1") ? 
        player=1: player=2; 
    //Determine file to access 
    (player==1) ? 
        file="p1_matches": 
        file="p2_matches"; 
    
    //Output for Player 1 card matching 
    if (player==1) { 
        //Display player card values 
        cout<<"Player "<<player<<" Cards: "<<endl; 
        for (int i=0; i<3; i++) { 
            cout<<plyr.hand[i].getVal()<<" "; 
        } 
        cout<<endl<<endl; 
        //Get input for Player 1 options 
        do { 
            cout<<"Choose a card to play: "<<endl; 
            cin>>card; 
            cout<<"You chose: "<<card; 
            cout<<"Play this card? 'Y' or 'N': "<<endl; 
            cin>>ch; 
        } while (toupper(ch)=='N'); 
        //Store card value in play card variable 
        for (int i=0; i<3; i++) { 
            if (card==plyr.hand[i].getVal()) { 
                playCrd=plyr.hand[i]; 
            } 
        } 
        //Match player card to table card(s) 
        do { 
            //Get input for table card(s) to match 
            do { 
                cout<<"Choose a card from the table: "<<endl; 
                cin>>card; 
                //Store matched card in temp array 
                for (int i=0; i<10; i++) { 
                    //Add card to temp card array 
                    if (card==piles.table[i].getVal()) { 
                        temp[i]=piles.table[i]; 
                    } 
                } 
                cout<<"Choose another card to match?"; 
                cout<<" 'Y' or 'N': "<<endl; 
                cin>>ch; 
            } while (toupper(ch) == 'Y'); 
            //Add up matched card values 
            for (int i=0; i<10; i++) { 
                tblVal+=temp[i].getReg(); 
            } 
            //Match card values to see if equal 
            (playCrd.getReg()==tblVal) ? 
                cout<<"Those cards match!"<<endl: 
                cout<<"Those cards don't match."<<endl; 
        //End of do-while Loop 
        } while (playCrd.getReg()!=tblVal); 
        //Store temp card value in player matches file 
        for (int i=0; i<10; i++) { 
            if (temp[i].getReg>0) { 
                txt.open(file,ios::out|ios::binary|ios::app); 
                txt.write(temp[i].getVal(),(sizeof(char)*2)); 
                txt.close(); 
            } 
        } 
        //Reset and store values in matches array 
        txt.open(file,ios::in|ios::binary); 
        for (int i=0; i<40; i++) { 
            plyr.mtch[i]=empty; 
            txt.read(card,(sizeof(char)*2)); 
            for (int j=0; j<40; j++) { 
                if (card==piles.deck[i].getVal()) { 
                    plyr.mtch[i]=piles.deck[i]; 
                } 
            } 
        } 
        txt.close(); 
        //Display output for cards added to matches pile 
        cout << "Cards added to your pile of matches." << endl;
    //End of for Loop     
    } 
    //Output for Player 2 card matching 
    else if (player==2) { 
        cout<<"Player 2 now matching cards."<<endl; 
        //Display player card values 
        cout<<"Player "<<player<<" Cards: "<<endl; 
        for (int i=0; i<3; i++) { 
            cout<<plyr.hand[i].getVal()<<" "; 
        } 
        cout<<endl<<endl; 
        //Get input for Player 2 options 
        do { 
            card=plyr.hand[rand[]%10].getVal(); 
        } while (card==""); 
        //Store matched card in temp array 
        for (int i=0; i<3; i++) { 
            //Add card to temp card array 
            if (card==plyr.hand[i].getVal()) { 
                temp[i]=plyr.hand[i]; 
            } 
        } 
        //Store card value in play card variable 
        for (int i=0; i<3; i++) { 
            if (card==plyr.hand[i].getVal()) { 
                playCrd=plyr.hand[i]; 
            } 
        } 
        //Match player card to table card(s) 
        do { 
            //Get input for table card(s) to match 
            do { 
                do { 
                    card=piles.table[rand[]%10].getVal(); 
                } while (card==""); 
                //Store matched card in temp array 
                for (int i=0; i<10; i++) { 
                    //Add card to temp card array 
                    if (card==piles.table[i].getVal()) { 
                        temp[i]=piles.table[i]; 
                    } 
                } 
                cout<<"Choose another card to match?"; 
                cout<<" 'Y' or 'N': "<<endl; 
                cin>>ch; 
            } while (toupper(ch) == 'Y'); 
            //Add up matched card values 
            for (int i=0; i<10; i++) { 
                tblVal+=temp[i].getReg(); 
            } 
            //Match card values to see if equal 
            (playCrd.getReg()==tblVal) ? 
                cout<<"Those cards match!"<<endl: 
                cout<<"Those cards don't match."<<endl; 
        //End of do-while Loop 
        } while (playCrd.getReg()!=tblVal); 
        //Store temp card value in player matches file 
        for (int i=0; i<10; i++) { 
            if (temp[i].getReg>0) { 
                txt.open(file,ios::out|ios::binary|ios::app); 
                txt.write(temp[i].getVal(),(sizeof(char)*2)); 
                txt.close(); 
            } 
        } 
        //Reset and store values in matches array 
        txt.open(file,ios::in|ios::binary); 
        for (int i=0; i<40; i++) { 
            plyr.mtch[i]=empty; 
            txt.read(card,(sizeof(char)*2)); 
            for (int j=0; j<40; j++) { 
                if (card==piles.deck[i].getVal()) { 
                    plyr.mtch[i]=piles.deck[i]; 
                } 
            } 
        } 
        txt.close(); 
    //End of for Loop 
    } 
    //Delete allocated memory 
    delete [] temp;
} 
//Score player cards at end of a round 
void score(Arrays &piles, Player &p1, Player &p2, int nCards) { 
    //Declare and initialize variables 
    int left=nCards, i=0;
    //Count scopas for each player 
    for (int i=0; i<40; i++) { 
        if (p1.mtch[i].get) 
    } 
    p1.score.all = p1.score.Scopas;
    p2.score.all = p2.score.Scopas;
    //Determine player with seven of coins 
    for (int i=0; i<40; i++) { 
        if (p1.mtch[i].getVal()=="SD") { 
            p1.score.setSvnD(1); 
        } 
        if (p2.mtch[i].getVal()=="SD") { 
            p2.score.setSvnD(1); 
        } 
    } 
    while (p2.mtch) { 
        p2.score.nMtchs++;
        (p2.mtch[i].val == svnD.val) ?
                p2.score.svnD = true : 
                p2.score.svnD = false;
        i++;
    } 
    i = 0; //reset counter 
    //Determine lgst num matched cards 
    if (p1.score.nMtchs != p2.score.nMtchs) { 
        (p1.score.nMtchs > p2.score.nMtchs) ?
                p1.score.all++ : p2.score.all++;
    } 
    //Determine lgst num Denari (Coins) cards 
    if (p1.score.nCoins != p2.score.nCoins) { 
        (p1.score.nCoins > p2.score.nCoins) ?
                p1.score.all++ : p2.score.all++;
    } 
    //Add point for seven of coins (sette bello) 
    if (p1.score.svnD == true) p1.score.all++;
    else if (p2.score.svnD == true) p2.score.all++;
    //Find prime value for each player 
    prime(piles, p1, left);
    prime(piles, p2, left);
    //Highest prime value btwn. players 
    if (p1.score.prm != p2.score.prm) { 
        (p1.score.prm > p2.score.prm) ?
                p1.score.all++ : p2.score.all;
    } 
} 

//Find prime value for each player's matched cards 
void prime(Arrays &piles, Player &plyr, int left) {
    //Declare and initialize variables 
    int i = 0;
    //Prime suits for matched cards 
    while (plyr.c) {
        if (plyr.c[i].s == 'D')
            if (plyr.c[i].n > plyr.hD.n)
                plyr.hD = plyr.c[i];
        if (plyr.c[i].s == 'C')
            if (plyr.c[i].n > plyr.hC.n)
                plyr.hC = plyr.c[i];
        if (plyr.c[i].s == 'B')
            if (plyr.c[i].n > plyr.hB.n)
                plyr.hB = plyr.c[i];
        if (plyr.c[i].s == 'S')
            if (plyr.c[i].n > plyr.hS.n)
                plyr.hS = plyr.c[i];
    }
    i = 0; //reset counter 
    //->Prime Scale 
    //Seven-21, Six-18, Ace-16, Five-15, Four-14 
    //Tre-13, Two-12, Face cards-10 
    //Prime suit nums for matched cards 
    (plyr.hD.f == '7') ? plyr.hD.n = 21 :
            (plyr.hD.f == '6') ? plyr.hD.n = 18 :
            (plyr.hD.f == 'A') ? plyr.hD.n = 16 :
            (plyr.hD.f == '5') ? plyr.hD.n = 15 :
            (plyr.hD.f == '4') ? plyr.hD.n = 14 :
            (plyr.hD.f == '3') ? plyr.hD.n = 13 :
            (plyr.hD.f == '2') ? plyr.hD.n = 12 :
            plyr.hD.n = 10;
    (plyr.hC.f == '7') ? plyr.hC.n = 21 :
            (plyr.hC.f == '6') ? plyr.hC.n = 18 :
            (plyr.hC.f == 'A') ? plyr.hC.n = 16 :
            (plyr.hC.f == '5') ? plyr.hC.n = 15 :
            (plyr.hC.f == '4') ? plyr.hC.n = 14 :
            (plyr.hC.f == '3') ? plyr.hC.n = 13 :
            (plyr.hC.f == '2') ? plyr.hC.n = 12 :
            plyr.hC.n = 10;
    (plyr.hB.f == '7') ? plyr.hB.n = 21 :
            (plyr.hB.f == '6') ? plyr.hB.n = 18 :
            (plyr.hB.f == 'A') ? plyr.hB.n = 16 :
            (plyr.hB.f == '5') ? plyr.hB.n = 15 :
            (plyr.hB.f == '4') ? plyr.hB.n = 14 :
            (plyr.hB.f == '3') ? plyr.hB.n = 13 :
            (plyr.hB.f == '2') ? plyr.hB.n = 12 :
            plyr.hB.n = 10;
    (plyr.hS.f == '7') ? plyr.hS.n = 21 :
            (plyr.hS.f == '6') ? plyr.hS.n = 18 :
            (plyr.hS.f == 'A') ? plyr.hS.n = 16 :
            (plyr.hS.f == '5') ? plyr.hS.n = 15 :
            (plyr.hS.f == '4') ? plyr.hS.n = 14 :
            (plyr.hS.f == '3') ? plyr.hS.n = 13 :
            (plyr.hS.f == '2') ? plyr.hS.n = 12 :
            plyr.hS.n = 10;
    //Prime value for matched cards 
    plyr.score.prm = plyr.hD.n + plyr.hC.n + plyr.hB.n + plyr.hS.n;
} 

void store(Player &plyr) { 
    //Declare and initialize variables 
    string fileP1="p1_bin.txt"; 
    string fileP2="p2_bin.txt"; 
    string file=""; 
    fstream txt; 
    //Determine file to access 
    (plyr.name=="Player") ? 
        file=fileP1: file=fileP2; 
    //Open file 
    txt1.open(file, ios::in|ios::out|ios::binary); 
    //Write player matches to file 
    txt.write(plyr.mtch[i],(sizeof(char)*2)); 
    //Close file 
    txt.close(); 
} 