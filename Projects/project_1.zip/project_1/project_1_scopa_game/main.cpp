/* 
 * File:   main.cpp
 * Author: Sarah Shima 
 * Created on July 7th, 2021, 2:00 PM 
 * Purpose:  Project 1 - Scopa Card Game 
 */

//System Libraries
#include <iostream> //I/O Library 
#include <ctime>      //Time for rand
#include <cstdlib>    //Srand to set the seed
#include <fstream>  //File I/O
#include <iomanip>  //Format the output
#include <string>     //Strings
#include <cmath>     //Math functions
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Structure Declarations 

struct Card {
    int n = 0;
    string val;
    char f, s;
};

struct Arrays {
    Card *deck;
    Card *table;
    Card *stock;
};

struct Scores {
    int all = 0;
    int Scopas = 0;
    int nMtchs = 0;
    int nCoins = 0;
    int prm = 0;
    bool svnD = false;
};

struct Playr {
    int id = 0;
    Card *c;
    Card *mtch;
    Card hD, hC, hB, hS;
    Scores pts;
};

//Function Prototypes 
void genCrds(Arrays &, string, int); //Generate Cards 
void shuffle(Arrays &, int, int); //Shuffle the Deck 
void deal(Arrays &, Playr &, Playr &, int &); //Deal the Cards 
bool play(Arrays &, Playr &, Playr &, int); //Play Cards 
void match(Arrays &, Playr *, int); //Match Cards 
void score(Arrays &, Playr &, Playr &, int); //Score Cards 
void prime(Arrays &, Playr &, int); //Find Prime Value 

//Enumerated Data Types 

enum Prm {
    Fce = 10, Due = 12, Tre, Qtro, //prms 10,12,13,14 
    Cinq, Asso, Sei = 18, Stte = 20
}; //prms 15,16,18,20 

enum FceVals {
    A = 1, T, Thr, Fr, Fv, Six,
    Svn, Fnte, Cvllo, Re
};

//*****START OF FUNCTION MAIN***** 
//Execution of Code Begins Here

int main(int argc, char** argv) {
    //Set the random number seed here
    srand(static_cast<unsigned int> (time(0)));
    //Declare and initialize variables 
    const int NCARDS = 40, //number cards in Scopa deck 
            HAND = 3; //number cards in player hand 
    Playr p1, p2; //player 1 and 2 structs 
    Arrays piles; //card piles deck, table, stock pile 
    string file = "card_deck.txt", //file to hold cards 
            winner; //game winner 
    int option = 0, i = 1; //menu option and ctr 
    bool win = false; //game win bool value 
    //Dynamically allocate memory 
    piles.deck = new Card[NCARDS];
    piles.stock = new Card[NCARDS];
    piles.table = new Card[NCARDS];
    p1.c = new Card[HAND];
    p1.mtch = new Card[NCARDS];
    p2.c = new Card[HAND];
    p2.mtch = new Card[NCARDS];
    //Assign player numbers to structs 
    p1.id = 1;
    p2.id = 2;
    //Generate cards and store in file 
    genCrds(piles, file, NCARDS);
    //Use a do-while Loop for menu selections 
    do {
        //Display player main menu 
        cout << "Main Menu" << endl;
        cout << "Type 1 to start a new game." << endl;
        cout << "Type 2 to exit the menu." << endl;
        cin>>option;
        //Option 1 - New Game 
        if (option == 1) { 
            //Display start of new game 
            cout << "New Game" << endl << endl;
            //Continue game until a player has 11 points 
            while (!win) { 
                cout << "Round " << i << endl << endl;
                //Match player cards to table cards 
                win = play(piles, p1, p2, NCARDS);
                //Update bool variable and game winner 
                if (win==true) { 
                    if (p1.pts.all == 11) winner = "Player 1"; 
                    else if (p2.pts.all == 11) winner = "Player 2"; 
                } 
                //Update round counter 
                (!win) ? i++ : i = 0; 
            //End of while Loop 
            } 
            //Display game winner and return to main menu 
            cout << "The winner is " << winner << "! " << endl << endl;
            cout << "Now returning to main menu." << endl << endl;
        } 
            //Option 2 - Quit Menu 
        else if (option == 2) cout << "Now exiting the menu." << endl;
            //Input Validation 
        else cout << "Please Type 1 for New Game or 2 to exit menu." << endl;
        //End of do-while Loop 
    } while (option != 2); 
    //Delete allocated memory 
    delete [] piles.deck; 
    delete [] piles.stock; 
    delete [] piles.table; 
    delete [] p1.c; 
    delete [] p1.mtch; 
    delete [] p2.c; 
    delete [] p2.mtch; 
    //Clean up the code, close files, deallocate memory, etc....
    //Exit stage right
    return 0; 
}
//*****FUNCTION IMPLEMENTATIONS***** 
//Generate Cards and Write to File 

void genCrds(Arrays &piles, string file1, int nCards) {
    //Declare and initialize deck 
    char f[] = "A234567FCR"; //face values A-7, Fante, Cavallo, Re 
    char s[] = "DCBS"; //suits denari, coppe, bastoni, spade 
    //Declare fstream to write to file 
    fstream txt; 
    //Open file to store cards 
    txt.open(file1, ios::out); 
    //Generate cards and write to file 
    for (int i = 0, j = 0, k = 0; i < nCards; i++) {
        //Add a face and suit value to card 
        piles.deck[i].f = f[j];
        piles.deck[i].s = s[k];
        piles.deck[i].val = f[j] + s[k];
        //Add number value to card 
        switch (f[j]) {
            case 0: piles.deck->n = 1;
                break;
            case 1: piles.deck->n = 2;
                break;
            case 2: piles.deck->n = 3;
                break;
            case 3: piles.deck->n = 4;
                break;
            case 4: piles.deck->n = 5;
                break;
            case 5: piles.deck->n = 6;
                break;
            case 6: piles.deck->n = 7;
                break;
            case 7: piles.deck->n = 8;
                break;
            case 8: piles.deck->n = 9;
                break;
            case 9: piles.deck->n = 10;
        }
        //Write card values to file 
        txt << &piles.deck[i].f;
        txt << &piles.deck[i].s;
        //Start new line for write to file 
        (j == 9) ? txt << endl : txt << " ";
        //Update or reset counters  
        (j == 9) ? j = 0, k++ : j++;
    }
    //Close file and exit function 
    txt.close();
}
//Shuffle cards 

void shuffle(Arrays &piles, int left, int nShuf) {
    //Declare and initialize variables 
    Card temp;
    //Use random card gen and swap values 
    for (int shuf = 1; shuf <= nShuf; shuf++) {
        for (int i = 0; i < left; i++) {
            //Use random card generator 
            int indx = rand() % left;
            //Swap card values 
            temp = piles.deck[i];
            piles.deck[i] = piles.deck[indx];
            piles.deck[indx] = temp;
        }
    }
}
//Deal cards to players and table 

void deal(Arrays &piles, Playr &p1, Playr &p2, int &left) {
    //Declare and initialize variables 
    Card temp;
    int ctr = 0;
    bool noShuf = false;
    //Reshuffle if 3-4 kings in first 4 cards 
    while (!noShuf) {
        //Shuffle cards 
        shuffle(piles, left, 3);
        //Reset king cards ctr 
        ctr = 0;
        //Count number of kings 
        for (int i = 0; i < 4; i++) {
            if (piles.deck[i].val == "DR") ctr++;
            if (piles.deck[i].val == "CR") ctr++;
            if (piles.deck[i].val == "BR") ctr++;
            if (piles.deck[i].val == "SR") ctr++;
        }
        //Update shuffle bool value 
        (ctr > 0) ? noShuf = false : noShuf = true;
    }
    //Reset king cards ctr 
    ctr = 0;
    //Deal cards and stock pile 
    for (int i = 0; i < left; i++) {
        //Deal four cards for the table 
        if (i < 3) piles.table[i] = piles.deck[i];
        //Deal three cards for Player 1 
        if (i >= 3 && i < 6) p1.c[i] = piles.deck[i];
        //Deal three cards for Player 2 
        if (i >= 6 && i < 9) p2.c[i] = piles.deck[i];
        //Place rest of cards in stock pile 
        if (i >= 9) piles.stock[i] = piles.deck[i];
    }
    cout << endl;
    //Update number leftover cards 
    left -= 10;
}
//Play cards for a single round 

bool play(Arrays &piles, Playr &p1, Playr &p2, int nCards) {
    //Declare and initialize variables 
    Card temp;
    bool endStck = false, win = false;
    int left = nCards, i = 0;
    string fileP1 = "playr1_pts_bin.txt", //file to hold cards 
            fileP2 = "playr2_pts_bin.txt"; //file to hold cards 
    fstream txt1, txt2;
    //Open text files for writing player scores 
    txt1.open(fileP1, ios::in | ios::out | ios::binary);
    txt2.open(fileP2, ios::in | ios::out | ios::binary);
    //Continue round until end of stock pile 
    while (piles.stock) {
        //Deal cards to players and table 
        deal(piles, p1, p2, left);
        //Display Table card values 
        while (piles.table) {
            if (i = 0) cout << "Table: " << endl;
            cout << i + 1 << " - " << piles.table[i].val << " ";
            i++;
        }
        //Output line spacing 
        cout << endl << endl;
        //Reset counter 
        i = 0;
        //Match cards for Player 1 turn 
        match(piles, &p1, left);
        //Write Player 1 matches to fileP1 
        while (p1.mtch) {
            txt1.write(&p1.mtch[i].f, 2);
            txt1.write(&p1.mtch[i].s, 2);
            i++;
        }
        //Reset counter 
        i = 0;
        //Match cards for Player 2 turn 
        match(piles, &p2, left);
        //Write Player 2 matches to fileP2 
        while (p2.mtch) {
            txt2.write(&p2.mtch[i].f, 2);
            txt2.write(&p2.mtch[i].s, 2);
            i++;
        }
        //Reset counter 
        i = 0;
        //End of while Loop 
    }
    //Close files 
    txt1.close();
    txt2.close();
    //Score points for all players 
    score(piles, p1, p2, nCards);
    //Determine if winner with 11 pts 
    if (p1.pts.all == 11 || p2.pts.all == 11) win = true;
    //Return value and exit function 
    return win;
}
//Match player and table card values 

void match(Arrays &piles, Playr *plyr, int left) {
    //Declare and initialize variables 
    Card playCrd, *temp;
    char ch;
    int i = 0, option = 0, add = 0;
    //Dynamically allocate temp card array 
    temp = new Card[10];
    //Display player card values 
    while (plyr->c) {
        if (i = 0) cout << "Player " << plyr->id << " cards: ";
        cout << i + 1 << " - " << plyr->c[i].val;
        i++;
    }
    cout << endl << endl;
    //Reset counter 
    i = 0;
    //Get input for Player 1 options 
    do {
        cout << "Choose a card to play: " << endl;
        cin>>option;
        cout << "You chose: " << plyr->c->val[option - 1];
        cout << "? 'Y' or 'N': " << endl;
    } while (toupper(ch) == 'N');
    //Place card value in temp placeholder 
    playCrd = plyr->c[option - 1];
    //Match player card to table card(s) 
    do {
        //Get input for table card(s) to match 
        do {
            cout << "Choose a card from the table: " << endl;
            cin>>option;
            (i == 0) ? add = piles.table[option - 1].n :
                    add += piles.table[option - 1].n;
            //Add card to temp card array 
            temp[i] = piles.table[option - 1];
            cout << "Choose another card to match? 'Y' or 'N': " << endl;
            cin>>ch;
            i++;
        } while (toupper(ch) == 'Y');
        //Reset counter 
        i = 0;
        //Match card values to see if equal 
        (playCrd.n == add) ?
                cout << "Those cards match!" << endl :
                cout << "Those cards don't match." << endl;
    } while (playCrd.n != add);
    //Add temp card array to player matched cards 
    while (temp) {
        plyr->mtch[i] = temp[i];
        i++;
    }
    //Reset counter 
    i = 0;
    //Display output for cards added to matches pile 
    cout << "Cards added to your pile of matches." << endl;
    //Delete allocated memory 
    delete [] temp;
}
//Score player cards at end of a round 

void score(Arrays &piles, Playr &p1, Playr &p2, int nCards) {
    //Declare and initialize variables 
    Card svnD = {7, "SD", 'S', 'D'};
    int left = nCards, i = 0;
    //Add up points for Scopas 
    p1.pts.all = p1.pts.Scopas;
    p2.pts.all = p2.pts.Scopas;
    //Count matches and find seven of coins 
    while (p1.mtch) {
        p1.pts.nMtchs++;
        (p1.mtch[i].val == svnD.val) ?
                p1.pts.svnD = true : p1.pts.svnD = false;
        i++;
    }
    i = 0; //reset counter 
    while (p2.mtch) {
        p2.pts.nMtchs++;
        (p2.mtch[i].val == svnD.val) ?
                p2.pts.svnD = true : p2.pts.svnD = false;
        i++;
    }
    i = 0; //reset counter 
    //Determine lgst num matched cards 
    if (p1.pts.nMtchs != p2.pts.nMtchs) {
        (p1.pts.nMtchs > p2.pts.nMtchs) ?
                p1.pts.all++ : p2.pts.all++;
    }
    //Determine lgst num Denari (Coins) cards 
    if (p1.pts.nCoins != p2.pts.nCoins) {
        (p1.pts.nCoins > p2.pts.nCoins) ?
                p1.pts.all++ : p2.pts.all++;
    }
    //Add point for seven of coins (sette bello) 
    if (p1.pts.svnD == true) p1.pts.all++;
    else if (p2.pts.svnD == true) p2.pts.all++;
    //Find prime value for each player 
    prime(piles, p1, left);
    prime(piles, p2, left);
    //Highest prime value btwn. players 
    if (p1.pts.prm != p2.pts.prm) {
        (p1.pts.prm > p2.pts.prm) ?
                p1.pts.all++ : p2.pts.all;
    }
}

//Find prime value for each player's matched cards 

void prime(Arrays &piles, Playr &plyr, int left) {
    //Declare and initialize variables 
    int i = 0;
    //Prime suits for matched cards 
    while (plyr.c) {
        if (plyr.c[i].s == 'D')
            if (plyr.c[i].n > plyr.hD.n)
                plyr.hD = plyr.c[i];
        if (plyr.c[i].s == 'C')
            if (plyr.c[i].n > plyr.hC.n)
                plyr.hC = plyr.c[i];
        if (plyr.c[i].s == 'B')
            if (plyr.c[i].n > plyr.hB.n)
                plyr.hB = plyr.c[i];
        if (plyr.c[i].s == 'S')
            if (plyr.c[i].n > plyr.hS.n)
                plyr.hS = plyr.c[i];
    }
    i = 0; //reset counter 
    //->Prime Scale 
    //Seven-21, Six-18, Ace-16, Five-15, Four-14 
    //Tre-13, Two-12, Face cards-10 
    //Prime suit nums for matched cards 
    (plyr.hD.f == '7') ? plyr.hD.n = 21 :
            (plyr.hD.f == '6') ? plyr.hD.n = 18 :
            (plyr.hD.f == 'A') ? plyr.hD.n = 16 :
            (plyr.hD.f == '5') ? plyr.hD.n = 15 :
            (plyr.hD.f == '4') ? plyr.hD.n = 14 :
            (plyr.hD.f == '3') ? plyr.hD.n = 13 :
            (plyr.hD.f == '2') ? plyr.hD.n = 12 :
            plyr.hD.n = 10;
    (plyr.hC.f == '7') ? plyr.hC.n = 21 :
            (plyr.hC.f == '6') ? plyr.hC.n = 18 :
            (plyr.hC.f == 'A') ? plyr.hC.n = 16 :
            (plyr.hC.f == '5') ? plyr.hC.n = 15 :
            (plyr.hC.f == '4') ? plyr.hC.n = 14 :
            (plyr.hC.f == '3') ? plyr.hC.n = 13 :
            (plyr.hC.f == '2') ? plyr.hC.n = 12 :
            plyr.hC.n = 10;
    (plyr.hB.f == '7') ? plyr.hB.n = 21 :
            (plyr.hB.f == '6') ? plyr.hB.n = 18 :
            (plyr.hB.f == 'A') ? plyr.hB.n = 16 :
            (plyr.hB.f == '5') ? plyr.hB.n = 15 :
            (plyr.hB.f == '4') ? plyr.hB.n = 14 :
            (plyr.hB.f == '3') ? plyr.hB.n = 13 :
            (plyr.hB.f == '2') ? plyr.hB.n = 12 :
            plyr.hB.n = 10;
    (plyr.hS.f == '7') ? plyr.hS.n = 21 :
            (plyr.hS.f == '6') ? plyr.hS.n = 18 :
            (plyr.hS.f == 'A') ? plyr.hS.n = 16 :
            (plyr.hS.f == '5') ? plyr.hS.n = 15 :
            (plyr.hS.f == '4') ? plyr.hS.n = 14 :
            (plyr.hS.f == '3') ? plyr.hS.n = 13 :
            (plyr.hS.f == '2') ? plyr.hS.n = 12 :
            plyr.hS.n = 10;
    //Prime value for matched cards 
    plyr.pts.prm = plyr.hD.n + plyr.hC.n + plyr.hB.n + plyr.hS.n;
}
