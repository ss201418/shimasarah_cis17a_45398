/* 
 * File: A2 More Test Output Format 
 * Author: Sarah Shima 
 * Date: June 22, 2021, 5:00 PM 
 * Purpose: Matching expected and actual output formats using iomanip 
 * Version:
 */

//System Libraries - Post Here
#include <iostream> 
#include <iomanip> 
using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.

//Function Prototypes - Post Here

//Execution Begins Here
int main(int argc, char** argv) {
    
    //Declare variables or constants here
    //7 characters or less
    float valuOne, valuTwo, valuThr, valuFor; 
    
    //Initialize or input data here
    cin>>valuOne>>valuTwo>>valuThr>>valuFor; 
    
    //Process inputs  - map to outputs here
    cout<<fixed; 
   
    cout<<setw(9)<<setprecision(0)<<valuOne; 
    cout<<setw(10)<<setprecision(1)<<valuOne; 
    cout<<setw(10)<<setprecision(2)<<valuOne<<endl; 
    
    cout<<setw(9)<<setprecision(0)<<valuTwo; 
    cout<<setw(10)<<setprecision(1)<<valuTwo; 
    cout<<setw(10)<<setprecision(2)<<valuTwo<<endl; 
    
    cout<<setw(9)<<setprecision(0)<<valuThr; 
    cout<<setw(10)<<setprecision(1)<<valuThr; 
    cout<<setw(10)<<setprecision(2)<<valuThr<<endl; 
    
    cout<<setw(9)<<setprecision(0)<<valuFor; 
    cout<<setw(10)<<setprecision(1)<<valuFor; 
    cout<<setw(10)<<setprecision(2)<<valuFor; 
    
    //Exit stage left
    return 0;
}