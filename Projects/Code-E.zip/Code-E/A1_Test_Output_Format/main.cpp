/* 
 * File: A1 Test Output Format 
 * Author: Sarah Shima 
 * Date: June 22, 2021, 4:00 PM 
 * Purpose: Matching expected output format to actual output format 
 * Version: 
 */

//System Libraries - Post Here
#include <iostream>
using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.

//Function Prototypes - Post Here

//Execution Begins Here

int main(int argc, char** argv) {
    //Set random number seed here when needed

    //Declare variables or constants here
    //7 characters or less
    string intValu;
    string fltValu;

    //Initialize or input data here

    //Display initial conditions, headings here

    //Process inputs  - map to outputs here
    getline(cin, intValu);
    getline(cin, fltValu);

    //Format and display outputs here
    cout << intValu << endl;
    cout << fltValu << endl;
    cout << "Hello World     " << endl;
    cout << "\tTab it!" << endl;
    cout << "Compare . . . to space   ";

    //Clean up allocated memory here

    //Exit stage left
    return 0;
}